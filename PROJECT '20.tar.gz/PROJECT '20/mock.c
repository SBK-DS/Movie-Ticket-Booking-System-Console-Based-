#include<stdio.h>

typedef struct{
	int i;
}hello;

void hell(hello)
{
	printf("s");
}

main()
{
	hello he;
	hell(he);
	printf("s");
}
