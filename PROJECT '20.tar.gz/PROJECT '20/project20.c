#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <time.h>

// customer's detail

typedef struct 
{
	char name[20];
	int ticket, movieNo;
	int parking;
	int regno;
	float amount;
	
}customer;
void Booking();
void Hollywood();
void Book_Holly_mon_movies();
void BookInHollyMon();
void Book_Holly_tue_movies();
void BookInHollyTue();
void Book_Holly_wed_movies();
void BookInHollyWed();
void Book_Holly_thu_movies();
void BookInHollyThu();
void Book_Holly_fri_movies();
void BookInHollyFri();
void Book_Holly_sat_movies();
void BookInHollySat();
void Book_Holly_sun_movies();
void BookInHollySun();
void Bollywood();
void Book_Bolly_mon_movies();
void BookInBollyMon();
void Book_Bolly_tue_movies();
void BookInBollyTue();
void Book_Bolly_wed_movies();
void BookInBollyWed();
void Book_Bolly_thu_movies();
void BookInBollyThu();
void Book_Bolly_fri_movies();
void BookInBollyFri();
void Book_Bolly_sat_movies();
void BookInBollySat();
void Book_Bolly_sun_movies();
void BookInBollySun();
void Services();
void Checking();
void Delete();
void Rating();
void Management();
void Analytics();
void CheckAdmin();
void DelAdmin();
void gotoxy(int a, int b)
{
	COORD c;
	c.X = a;
	c.Y = b;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),c);
}
void delay(unsigned int mseconds)
{
    clock_t goal = mseconds + clock();
    while (goal > clock());
}
void starter()
{
	Beep(300,500);
	Beep(400,500);
	Beep(500,500);
	Beep(600,500);
	Beep(700,500);
	Beep(600,500);
	Beep(500,1200);	
	int i, j;
	gotoxy(42,12);
	printf("WELCOME TO BPLEX");
	gotoxy(10,2);
	for(i=0; i<82; i++)
	{
		printf("*");
		delay(3);	
	}
	printf("\n");
	gotoxy(12,3);
	for(i=0; i<78; i++)
	{
		printf("*");
		delay(3);	
	}
	
	for(i=0; i<20; i++)
	{
		gotoxy(10,3+i);
		printf("*\n");
		delay(3);
	}
	
	for(i=0; i<17; i++)
	{
		gotoxy(12,4+i);
		printf("*\n");
		delay(3);
	}

	gotoxy(12,21);
	for(i=0; i<78; i++)
	{
		printf("*");
		delay(3);	
	}
	printf("\n");
	gotoxy(10,22);
	for(i=0; i<82; i++)
	{
		printf("*");
		delay(3);	
	}
	
	for(i=0; i<17; i++)
	{
		gotoxy(89,4+i);
		printf("*\n");
		delay(3);
	}	
	
	for(i=0; i<20; i++)
	{
		gotoxy(91,3+i);
		printf("*\n");
		delay(3);
	}
	printf("\n\n\n");	
}
int carslot;
main ()
{
	starter();
	system("cls");
	
	void (*ptr[3])() = {Booking, Services, Management};
	
	
	int enter;
	printf(" What do you want to do \n 1)Book a Ticket \n 2)Services \n 3)Management");
	printf("\n Enter your selection : ");
	scanf("%d", &enter);
	
	(*ptr[enter-1])();
	
	printf("\n");
	system("pause");
	return 0;
}

void Booking()
{
	system("cls");
	printf(" Welcome to booking");
	
	void (*ptr[2])() = {Hollywood, Bollywood};
	printf("\n Select category of the movie \n 1)Hollywood \n 2)Bollywood");
	
	int book;
	printf("\n Enter your selection : ");
	scanf("%d", &book);
	
	(*ptr[book-1])();
}

void Hollywood()
{
			
		system("cls");
		printf("You entered in Hollywood");
		
		void (*ptr[7])() = {BookInHollyMon, BookInHollyTue, BookInHollyWed, BookInHollyThu, BookInHollyFri, BookInHollySat, BookInHollySun};
		printf("\n Select the day \n 1) Monday \n 2) Tuesday \n 3) Wednesday \n 4) Thursday \n 5) Friday \n 6) Saturday \n 7) Sunday");
		
		int day;
		printf("\n Enter your selection : ");
		scanf("%d", &day);
		
		(*ptr[day-1])();
}

void Book_Holly_mon_movies()
{
   FILE *fp;
   char ch;
   fp = fopen("Book_Holly_mon_movies.txt","r");
   if(fp==NULL)
   {
   	 exit(1);
   }
   while(!feof(fp))
   {
   	 ch = fgetc(fp);
   	 printf("%c", ch);
   }
   fclose(fp);
}

void BookInHollyMon()
{
	system("cls");
		customer CUST;
		printf("\nMovie -> Tickets -> Price -> Ratings -> No.of ratings\n\n");
	    Book_Holly_mon_movies();
		printf("\nNOTE : Booking of parking slot will cost RS 100. only one slot will be booked at per registeration\n");	
      	int wish;
      	printf("\nWould you like to get booked!!!! kindly press 1 for yes and 0 for no : ");
      	scanf("%d", &wish);
      	if(wish!=1)
      	{
      	    exit(0);	
		}
		system("cls");
        Book_Holly_mon_movies();
		
		// details input //
		
		fflush(stdin);
		printf("\nEnter your name : ");
		gets(CUST.name);
		
		printf("Enter the no of movie you want to watch : ");
		scanf("%d", &CUST.movieNo);
		
		printf("Enter no of tickets : ");
		scanf("%d", &CUST.ticket);
		
		printf("Do you want to avail parking 1)yes OR 0)no : ");
		scanf("%d", &CUST.parking);

		char file1[] = "Book_Holly_mon_movies.txt";
				
		FILE *fp = fopen(file1, "r");
		if(fp==NULL)
		{exit(1);}
		
		// REWRITING THE FILE //
		
		rewind(fp);
		char file_new[] = "new.txt";
		char str3[55], str4[55];
		FILE *fp_new = fopen(file_new, "w");
		if(fp_new==NULL)
		{exit(1);}
		int line = 0, num;
		while(fgets(str3, sizeof(str3), fp) != NULL)
		{
			line++;
			if(line==CUST.movieNo+3)
			{
				num = atoi(&str3);
				if(num == 0)
				{
					printf("\n\nSorry All tickets have been sold!!!");
					exit(1);
				}
				num = num - CUST.ticket;
				fprintf(fp_new,"%d\n", num);
			}
			else
			{
				strcpy(str4, str3);
				fprintf(fp_new, "%s", str4);
			}
		}		
		
		// REGISTRATION //
		system("cls");
		char registration[] = "RegistrationNo.txt";
		char registration1[] = "newregistration.txt";
		int reg;
		FILE *REG, *REG1;
		REG = fopen(registration, "r");
		fscanf(REG, "%d", &reg);
		   reg++;
		   CUST.regno = reg;
		REG1 = fopen(registration1, "w");
		fprintf(REG1, "%d", reg);
		fclose(REG1);
		fclose(REG);
		remove(registration);
		rename(registration1, registration);
		
		// copying the movie name //
		rewind(fp);
		printf("\n\n\n");
		printf("Registration No : REG%d", CUST.regno);
		printf("\nname : %s", CUST.name);			
		printf("\nMovie :");
		char str1[55],str2[55];
		int counter = 0;
		while(fgets(str1, sizeof(str1), fp)!=NULL)
		{
			++counter;
			if(counter == CUST.movieNo && counter<=3)
			{
		          printf("%s", str1);
				  break;	
			}
		}
		strcpy(str2,str1);
		printf("Tickets : %d", CUST.ticket);
		
		// PARKING SLOT //
		
		FILE *PAR, *PAR1;
		int slot;
		char park[] = "PARKING.txt";
		char park1[] = "parknew.txt";		
		if (CUST.parking == 1)
		{
				PAR = fopen(park, "r");
				fscanf(PAR, "%d", &slot);
				if(slot == 500)
				{
					int take, take1;
					char string[] = "Remaining_parking_slot.txt";
					char string1[] = "Remaining.txt";
					FILE *WE = fopen(string,"r");
					if(WE == NULL)
					{
						carslot = 0;
					}
					else
					{						
						fscanf(WE,"%d", &take);
						carslot = take;
						rewind(WE);
						FILE *WE1 = fopen(string1,"w");
						char str[10];
						printf("%d", take);
						while(fgets(str, sizeof(str), WE) != NULL)
						{
							take1 = atoi(&str);
							printf("%d", take1);
							if(take1 != take)
							{
								fprintf(WE1,"%d\n", take1);
							}
						}
						fclose(WE1);
						fclose(WE);
						remove(string);
						rename(string1,string);
					}
				}
				else
				{
					slot++;
					carslot = slot;
				}
				PAR1 = fopen(park1, "w");
				fprintf(PAR1, "%d", slot);
				fclose(PAR1);
				fclose(PAR);
				remove(park);
				rename(park1, park);
		}
		printf("\nYour parking slot no is : %d", carslot);
		
		// AMOUNT CALCULATION //
		
		char read[55];
		int select = 0;
		float price;
		rewind(fp);
		while(fgets(read, sizeof(read), fp))
		{
			select++;
			if(select == CUST.movieNo+6)
			{
				price = atoi(&read);
				CUST.amount = price * CUST.ticket;
				if(CUST.parking == 1)
				{
					CUST.amount += 100;
				}
		 }
		}
		printf("\nTotal Amount : %.2f", CUST.amount);
		
		fclose(fp_new);
		fclose(fp);
		remove(file1);
		rename(file_new, file1);
		
		// calculating revenue //
		
		char rev[] = "HollywoodRevenue.txt";
		char rev1[] = "newhollyrev.txt";
		FILE *REV, *REV1;
		float revenue;
		char extract[10], extract1[10];
		int check = 0;
		
		
		REV = fopen(rev, "r");
		if(REV == NULL)
		{exit(1);}
		
		REV1 = fopen(rev1, "w");
		if(REV1 == NULL)
		{exit(1);}
		while(fgets(extract, sizeof(extract), REV) != NULL)
		{
			check++;
			if(check==1)
			{
				revenue = atoi(&extract);
				revenue += CUST.amount;				
				fprintf(REV1,"%.2f\n", revenue);
			}
			else
			{
				strcpy(extract1, extract);
				fprintf(REV1, "%s", extract1);
			}
		}
		fclose(REV1);
		fclose(REV);
		remove(rev);
		rename(rev1, rev);
		
		FILE *fp1 = fopen("Booking_Holly_mon_movies.txt","a+");
		if(fp1==NULL)
		{
			exit(1);
		}
		
		// PRINTING TO FILE //
		
        fprintf(fp1, "\t%-10d%-20s%-10d%-10d%-10.2f%-20s", CUST.regno, CUST.name, CUST.ticket, carslot, CUST.amount, str2);
        
		fclose(fp1);		
		gotoxy(15,10);
		printf("*************** THANKS FOR REGISTERATION :) ***************");
			
}


void Book_Holly_tue_movies()
{
   FILE *fp;
   char ch;
   fp = fopen("Book_Holly_tue_movies.txt","r");
   if(fp==NULL)
   {
   	 exit(1);
   }
   while(!feof(fp))
   {
   	 ch = fgetc(fp);
   	 printf("%c", ch);
   }
   fclose(fp);
}

void BookInHollyTue()
{
	system("cls");
		customer CUST;
		printf("\nMovie -> Tickets -> Price -> Ratings -> No.of ratings\n\n");
	    Book_Holly_tue_movies();
		printf("\nNOTE : Booking of parking slot will cost RS 100. only one slot will be booked at per registeration\n");	
      	int wish;
      	printf("\nWould you like to get booked!!!! kindly press 1 for yes and 0 for no : ");
      	scanf("%d", &wish);
      	if(wish!=1)
      	{
      	    exit(0);	
		}
		system("cls");
        Book_Holly_tue_movies();
		
		// details input //
		
		fflush(stdin);
		printf("\nEnter your name : ");
		gets(CUST.name);
		
		printf("Enter the no of movie you want to watch : ");
		scanf("%d", &CUST.movieNo);
		
		printf("Enter no of tickets : ");
		scanf("%d", &CUST.ticket);
		
		printf("Do you want to avail parking 1)yes OR 0)no : ");
		scanf("%d", &CUST.parking);
		
		char file1[] = "Book_Holly_tue_movies.txt";
				
		FILE *fp = fopen(file1, "r");
		if(fp==NULL)
		{exit(1);}
		
		
		// REWRITING THE FILE //
		
		rewind(fp);
		char file_new[] = "new.txt";
		char str3[55], str4[55];
		FILE *fp_new = fopen(file_new, "w");
		if(fp_new==NULL)
		{exit(1);}
		int line = 0, num;
		while(fgets(str3, sizeof(str3), fp) != NULL)
		{
			line++;
			if(line==CUST.movieNo+3)
			{
				num = atoi(&str3);
				if(num == 0)
				{
					printf("\n\nSorry All tickets have been sold!!!");
					exit(1);
				}				
				num = num - CUST.ticket;
				fprintf(fp_new,"%d\n", num);
			}
			else
			{
				strcpy(str4, str3);
				fprintf(fp_new, "%s", str4);
			}
		}				
		
		system("cls");
		// REGISTRATION //
		
		char registration[] = "RegistrationNo.txt";
		char registration1[] = "newregistration.txt";
		int reg;
		FILE *REG, *REG1;
		REG = fopen(registration, "r");
		fscanf(REG, "%d", &reg);
		   reg++;
		   CUST.regno = reg;
		REG1 = fopen(registration1, "w");
		fprintf(REG1, "%d", reg);
		fclose(REG1);
		fclose(REG);
		remove(registration);
		rename(registration1, registration);
		
		// copying the movie name //
	
		rewind(fp);
		printf("\n\n\n");
		printf("Registration No : REG%d", CUST.regno);
		printf("\nname : %s", CUST.name);			
		printf("\nMovie :");
		char str1[55],str2[55];
		int counter = 0;
		while(fgets(str1, sizeof(str1), fp)!=NULL)
		{
			++counter;
			if(counter == CUST.movieNo && counter<=3)
			{
		          printf("%s", str1);
				  break;	
			}
		}
		strcpy(str2,str1);
		printf("Tickets : %d", CUST.ticket);
		
		// PARKING SLOT //
		
		FILE *PAR, *PAR1;
		int slot;
		char park[] = "PARKING.txt";
		char park1[] = "parknew.txt";		
		if (CUST.parking == 1)
		{
				PAR = fopen(park, "r");
				fscanf(PAR, "%d", &slot);
				if(slot == 500)
				{
					int take, take1;
					char string[] = "Remaining_parking_slot.txt";
					char string1[] = "Remaining.txt";
					FILE *WE = fopen(string,"r");
					if(WE == NULL)
					{
						carslot = 0;
					}
					else
					{						
						fscanf(WE,"%d", &take);
						carslot = take;
						rewind(WE);
						FILE *WE1 = fopen(string1,"w");
						char str[10];
						printf("%d", take);
						while(fgets(str, sizeof(str), WE) != NULL)
						{
							take1 = atoi(&str);
							printf("%d", take1);
							if(take1 != take)
							{
								fprintf(WE1,"%d\n", take1);
							}
						}
						fclose(WE1);
						fclose(WE);
						remove(string);
						rename(string1,string);
					}
				}
				else
				{
					slot++;
					carslot = slot;
				}
				PAR1 = fopen(park1, "w");
				fprintf(PAR1, "%d", slot);
				fclose(PAR1);
				fclose(PAR);
				remove(park);
				rename(park1, park);
		}
		printf("\nYour parking slot no is : %d", carslot);
		
		// AMOUNT CALCULATION //
		
		char read[55];
		int select = 0;
		float price;
		rewind(fp);
		while(fgets(read, sizeof(read), fp))
		{
			select++;
			if(select == CUST.movieNo+6)
			{
				price = atoi(&read);
				CUST.amount = price * CUST.ticket;
				if(CUST.parking == 1)
				{
					CUST.amount += 100;
				}
			}
		}
		printf("\nTotal Amount : %.2f", CUST.amount);
		fclose(fp_new);
		fclose(fp);
		remove(file1);
		rename(file_new, file1);
		
		// calculating revenue //
		
		char rev[] = "HollywoodRevenue.txt";
		char rev1[] = "newhollyrev.txt";
		FILE *REV, *REV1;
		float revenue;
		char extract[10], extract1[10];
		int check = 0;
		
		
		REV = fopen(rev, "r");
		if(REV == NULL)
		{exit(1);}
		
		REV1 = fopen(rev1, "w");
		if(REV1 == NULL)
		{exit(1);}
		while(fgets(extract, sizeof(extract), REV) != NULL)
		{
			check++;
			if(check==2)
			{
				revenue = atoi(&extract);
				revenue += CUST.amount;				
				fprintf(REV1,"%.2f\n", revenue);
			}
			else
			{
				strcpy(extract1, extract);
				fprintf(REV1, "%s", extract1);
			}
		}
		fclose(REV1);
		fclose(REV);
		remove(rev);
		rename(rev1, rev);
		
		FILE *fp1 = fopen("Booking_Holly_tue_movies.txt","a+");
		if(fp1==NULL)
		{
			exit(1);
		}
		
		// PRINTING TO FILE //
		
        fprintf(fp1, "\t%-10d%-20s%-10d%-10d%-10.2f%-20s", CUST.regno, CUST.name, CUST.ticket, carslot, CUST.amount, str2);
        
		fclose(fp1);		
		
		gotoxy(15,10);
		printf("*************** THANKS FOR REGISTERATION :) ***************");			
}


void Book_Holly_wed_movies()
{
   FILE *fp;
   char ch;
   fp = fopen("Book_Holly_wed_movies.txt","r");
   if(fp==NULL)
   {
   	 exit(1);
   }
   while(!feof(fp))
   {
   	 ch = fgetc(fp);
   	 printf("%c", ch);
   }
   fclose(fp);
}

void BookInHollyWed()
{
	system("cls");
		customer CUST;
		printf("\nMovie -> Tickets -> Price -> Ratings -> No.of ratings\n\n");
	    Book_Holly_wed_movies();
		printf("\nNOTE : Booking of parking slot will cost RS 100. only one slot will be booked at per registeration\n");	
      	int wish;
      	printf("\nWould you like to get booked!!!! kindly press 1 for yes and 0 for no : ");
      	scanf("%d", &wish);
      	if(wish!=1)
      	{
      	    exit(0);	
		}
		system("cls");
        Book_Holly_wed_movies();
		
		// details input //
		
		fflush(stdin);
		printf("\nEnter your name : ");
		gets(CUST.name);
		
		printf("Enter the no of movie you want to watch : ");
		scanf("%d", &CUST.movieNo);
		
		printf("Enter no of tickets : ");
		scanf("%d", &CUST.ticket);
		
		printf("Do you want to avail parking 1)yes OR 0)no : ");
		scanf("%d", &CUST.parking);
		
		char file1[] = "Book_Holly_wed_movies.txt";
				
		FILE *fp = fopen(file1, "r");
		if(fp==NULL)
		{exit(1);}
		
		// REWRITING THE FILE //
		
		rewind(fp);
		char file_new[] = "new.txt";
		char str3[55], str4[55];
		FILE *fp_new = fopen(file_new, "w");
		if(fp_new==NULL)
		{exit(1);}
		int line = 0, num;
		while(fgets(str3, sizeof(str3), fp) != NULL)
		{
			line++;
			if(line==CUST.movieNo+3)
			{
				num = atoi(&str3);
				if(num == 0)
				{
					printf("\n\nSorry All tickets have been sold!!!");
					exit(1);
				}				
				num = num - CUST.ticket;
				fprintf(fp_new,"%d\n", num);
			}
			else
			{
				strcpy(str4, str3);
				fprintf(fp_new, "%s", str4);
			}
		}				
		
		system("cls");
		// REGISTRATION //
		
		char registration[] = "RegistrationNo.txt";
		char registration1[] = "newregistration.txt";
		int reg;
		FILE *REG, *REG1;
		REG = fopen(registration, "r");
		fscanf(REG, "%d", &reg);
		   reg++;
		   CUST.regno = reg;
		REG1 = fopen(registration1, "w");
		fprintf(REG1, "%d", reg);
		fclose(REG1);
		fclose(REG);
		remove(registration);
		rename(registration1, registration);
		
		// copying the movie name //
	
		rewind(fp);
		printf("\n\n\n");
		printf("Registration No : REG%d", CUST.regno);
		printf("\nname : %s", CUST.name);			
		printf("\nMovie :");
		char str1[55],str2[55];
		int counter = 0;
		while(fgets(str1, sizeof(str1), fp)!=NULL)
		{
			++counter;
			if(counter == CUST.movieNo && counter<=3)
			{
		          printf("%s", str1);
				  break;	
			}
		}
		strcpy(str2,str1);
		printf("Tickets : %d", CUST.ticket);
		
		// PARKING SLOT //
		
		FILE *PAR, *PAR1;
		int slot;
		char park[] = "PARKING.txt";
		char park1[] = "parknew.txt";		
		if (CUST.parking == 1)
		{
				PAR = fopen(park, "r");
				fscanf(PAR, "%d", &slot);
				if(slot == 500)
				{
					int take, take1;
					char string[] = "Remaining_parking_slot.txt";
					char string1[] = "Remaining.txt";
					FILE *WE = fopen(string,"r");
					if(WE == NULL)
					{
						carslot = 0;
					}
					else
					{						
						fscanf(WE,"%d", &take);
						carslot = take;
						rewind(WE);
						FILE *WE1 = fopen(string1,"w");
						char str[10];
						printf("%d", take);
						while(fgets(str, sizeof(str), WE) != NULL)
						{
							take1 = atoi(&str);
							printf("%d", take1);
							if(take1 != take)
							{
								fprintf(WE1,"%d\n", take1);
							}
						}
						fclose(WE1);
						fclose(WE);
						remove(string);
						rename(string1,string);
					}
				}
				else
				{
					slot++;
					carslot = slot;
				}
				PAR1 = fopen(park1, "w");
				fprintf(PAR1, "%d", slot);
				fclose(PAR1);
				fclose(PAR);
				remove(park);
				rename(park1, park);
		}
		printf("\nYour parking slot no is : %d", carslot);
		
		// AMOUNT CALCULATION //
		
		char read[55];
		int select = 0;
		float price;
		rewind(fp);
		while(fgets(read, sizeof(read), fp))
		{
			select++;
			if(select == CUST.movieNo+6)
			{
				price = atoi(&read);
				CUST.amount = price * CUST.ticket;
				if(CUST.parking == 1)
				{
					CUST.amount += 100;
				}
			}
		}
		printf("\nTotal Amount : %.2f", CUST.amount);
		fclose(fp_new);
		fclose(fp);
		remove(file1);
		rename(file_new, file1);
		
		// calculating revenue //
		
		char rev[] = "HollywoodRevenue.txt";
		char rev1[] = "newhollyrev.txt";
		FILE *REV, *REV1;
		float revenue;
		char extract[10], extract1[10];
		int check = 0;
		
		
		REV = fopen(rev, "r");
		if(REV == NULL)
		{exit(1);}
		
		REV1 = fopen(rev1, "w");
		if(REV1 == NULL)
		{exit(1);}
		while(fgets(extract, sizeof(extract), REV) != NULL)
		{
			check++;
			if(check==3)
			{
				revenue = atoi(&extract);
				revenue += CUST.amount;				
				fprintf(REV1,"%.2f\n", revenue);
			}
			else
			{
				strcpy(extract1, extract);
				fprintf(REV1, "%s", extract1);
			}
		}
		fclose(REV1);
		fclose(REV);
		remove(rev);
		rename(rev1, rev);
		
		FILE *fp1 = fopen("Booking_Holly_wed_movies.txt","a+");
		if(fp1==NULL)
		{
			exit(1);
		}
		
		// PRINTING TO FILE //
		
        fprintf(fp1, "\t%-10d%-20s%-10d%-10d%-10.2f%-20s", CUST.regno, CUST.name, CUST.ticket, carslot, CUST.amount, str2);
        
		fclose(fp1);		
		
		gotoxy(15,10);
		printf("*************** THANKS FOR REGISTERATION :) ***************");			
}


void Book_Holly_thu_movies()
{
   FILE *fp;
   char ch;
   fp = fopen("Book_Holly_thu_movies.txt","r");
   if(fp==NULL)
   {
   	 exit(1);
   }
   while(!feof(fp))
   {
   	 ch = fgetc(fp);
   	 printf("%c", ch);
   }
   fclose(fp);
}

void BookInHollyThu()
{
	system("cls");
		customer CUST;
		printf("\nMovie -> Tickets -> Price -> Ratings -> No.of ratings\n\n");
	    Book_Holly_thu_movies();
		printf("\nNOTE : Booking of parking slot will cost RS 100. only one slot will be booked at per registeration\n");	
      	int wish;
      	printf("\nWould you like to get booked!!!! kindly press 1 for yes and 0 for no : ");
      	scanf("%d", &wish);
      	if(wish!=1)
      	{
      	    exit(0);	
		}
		system("cls");
        Book_Holly_thu_movies();
		
		// details input //
		
		fflush(stdin);
		printf("\nEnter your name : ");
		gets(CUST.name);
		
		printf("Enter the no of movie you want to watch : ");
		scanf("%d", &CUST.movieNo);
		
		printf("Enter no of tickets : ");
		scanf("%d", &CUST.ticket);
		
		printf("Do you want to avail parking 1)yes OR 0)no : ");
		scanf("%d", &CUST.parking);
		
		char file1[] = "Book_Holly_thu_movies.txt";
				
		FILE *fp = fopen(file1, "r");
		if(fp==NULL)
		{exit(1);}
		
		rewind(fp);
		char file_new[] = "new.txt";
		char str3[55], str4[55];
		FILE *fp_new = fopen(file_new, "w");
		if(fp_new==NULL)
		{exit(1);}
		int line = 0, num;
		while(fgets(str3, sizeof(str3), fp) != NULL)
		{
			line++;
			if(line==CUST.movieNo+3)
			{
				num = atoi(&str3);
				if(num == 0)
				{
					printf("\n\nSorry All tickets have been sold!!!");
					exit(1);
				}				
				num = num - CUST.ticket;
				fprintf(fp_new,"%d\n", num);
			}
			else
			{
				strcpy(str4, str3);
				fprintf(fp_new, "%s", str4);
			}
		}				
		
		system("cls");
		// REGISTRATION //
		
		char registration[] = "RegistrationNo.txt";
		char registration1[] = "newregistration.txt";
		int reg;
		FILE *REG, *REG1;
		REG = fopen(registration, "r");
		fscanf(REG, "%d", &reg);
		   reg++;
		   CUST.regno = reg;
		REG1 = fopen(registration1, "w");
		fprintf(REG1, "%d", reg);
		fclose(REG1);
		fclose(REG);
		remove(registration);
		rename(registration1, registration);
		
		// copying the movie name //
		rewind(fp);
		printf("\n\n\n");
		printf("Registration No : REG%d", CUST.regno);
		printf("\nname : %s", CUST.name);			
		printf("\nMovie :");
		char str1[55],str2[55];
		int counter = 0;
		while(fgets(str1, sizeof(str1), fp)!=NULL)
		{
			++counter;
			if(counter == CUST.movieNo && counter<=3)
			{
		          printf("%s", str1);
				  break;	
			}
		}
		strcpy(str2,str1);
		printf("Tickets : %d", CUST.ticket);
		
		// PARKING SLOT //
		
		FILE *PAR, *PAR1;
		int slot;
		char park[] = "PARKING.txt";
		char park1[] = "parknew.txt";		
		if (CUST.parking == 1)
		{
				PAR = fopen(park, "r");
				fscanf(PAR, "%d", &slot);
				if(slot == 500)
				{
					int take, take1;
					char string[] = "Remaining_parking_slot.txt";
					char string1[] = "Remaining.txt";
					FILE *WE = fopen(string,"r");
					if(WE == NULL)
					{
						carslot = 0;
					}
					else
					{						
						fscanf(WE,"%d", &take);
						carslot = take;
						rewind(WE);
						FILE *WE1 = fopen(string1,"w");
						char str[10];
						printf("%d", take);
						while(fgets(str, sizeof(str), WE) != NULL)
						{
							take1 = atoi(&str);
							printf("%d", take1);
							if(take1 != take)
							{
								fprintf(WE1,"%d\n", take1);
							}
						}
						fclose(WE1);
						fclose(WE);
						remove(string);
						rename(string1,string);
					}
				}
				else
				{
					slot++;
					carslot = slot;
				}
				PAR1 = fopen(park1, "w");
				fprintf(PAR1, "%d", slot);
				fclose(PAR1);
				fclose(PAR);
				remove(park);
				rename(park1, park);
		}
		printf("\nYour parking slot no is : %d", carslot);
		
		// AMOUNT CALCULATION //
		
		char read[55];
		int select = 0;
		float price;
		rewind(fp);
		while(fgets(read, sizeof(read), fp))
		{
			select++;
			if(select == CUST.movieNo+6)
			{
				price = atoi(&read);
				CUST.amount = price * CUST.ticket;
				if(CUST.parking == 1)
				{
					CUST.amount += 100;
				}
			}
		}
		printf("\nTotal Amount : %.2f", CUST.amount);
		
		// REWRITING THE FILE //
		
		fclose(fp_new);
		fclose(fp);
		remove(file1);
		rename(file_new, file1);
		
		// calculating revenue //
		
		char rev[] = "HollywoodRevenue.txt";
		char rev1[] = "newhollyrev.txt";
		FILE *REV, *REV1;
		float revenue;
		char extract[10], extract1[10];
		int check = 0;
		
		
		REV = fopen(rev, "r");
		if(REV == NULL)
		{exit(1);}
		
		REV1 = fopen(rev1, "w");
		if(REV1 == NULL)
		{exit(1);}
		while(fgets(extract, sizeof(extract), REV) != NULL)
		{
			check++;
			if(check==4)
			{
				revenue = atoi(&extract);
				revenue += CUST.amount;				
				fprintf(REV1,"%.2f\n", revenue);
			}
			else
			{
				strcpy(extract1, extract);
				fprintf(REV1, "%s", extract1);
			}
		}
		fclose(REV1);
		fclose(REV);
		remove(rev);
		rename(rev1, rev);
		
		FILE *fp1 = fopen("Booking_Holly_thu_movies.txt","a+");
		if(fp1==NULL)
		{
			exit(1);
		}
		
		// PRINTING TO FILE //
		
        fprintf(fp1, "\t%-10d%-20s%-10d%-10d%-10.2f%-20s", CUST.regno, CUST.name, CUST.ticket, carslot, CUST.amount, str2);
        
		fclose(fp1);		
		
		gotoxy(15,10);
		printf("*************** THANKS FOR REGISTERATION :) ***************");		
			
}


void Book_Holly_fri_movies()
{
   FILE *fp;
   char ch;
   fp = fopen("Book_Holly_fri_movies.txt","r");
   if(fp==NULL)
   {
   	 exit(1);
   }
   while(!feof(fp))
   {
   	 ch = fgetc(fp);
   	 printf("%c", ch);
   }
   fclose(fp);
}

void BookInHollyFri()
{
	system("cls");
		customer CUST;
		printf("\nMovie -> Tickets -> Price -> Ratings -> No.of ratings\n\n");
	    Book_Holly_fri_movies();
		printf("\nNOTE : Booking of parking slot will cost RS 100. only one slot will be booked at per registeration\n");	
      	int wish;
      	printf("\nWould you like to get booked!!!! kindly press 1 for yes and 0 for no : ");
      	scanf("%d", &wish);
      	if(wish!=1)
      	{
      	    exit(0);	
		}
		system("cls");
        Book_Holly_fri_movies();
		
		// details input //
		
		fflush(stdin);
		printf("\nEnter your name : ");
		gets(CUST.name);
		
		printf("Enter the no of movie you want to watch : ");
		scanf("%d", &CUST.movieNo);
		
		printf("Enter no of tickets : ");
		scanf("%d", &CUST.ticket);
		
		printf("Do you want to avail parking 1)yes OR 0)no : ");
		scanf("%d", &CUST.parking);
		
		char file1[] = "Book_Holly_fri_movies.txt";
				
		FILE *fp = fopen(file1, "r");
		if(fp==NULL)
		{exit(1);}	
		
		// REWRITING THE FILE //
		
		rewind(fp);
		char file_new[] = "new.txt";
		char str3[55], str4[55];
		FILE *fp_new = fopen(file_new, "w");
		if(fp_new==NULL)
		{exit(1);}
		int line = 0, num;
		while(fgets(str3, sizeof(str3), fp) != NULL)
		{
			line++;
			if(line==CUST.movieNo+3)
			{
				num = atoi(&str3);
				if(num == 0)
				{
					printf("\n\nSorry All tickets have been sold!!!");
					exit(1);
				}				
				num = num - CUST.ticket;
				fprintf(fp_new,"%d\n", num);
			}
			else
			{
				strcpy(str4, str3);
				fprintf(fp_new, "%s", str4);
			}
		}			
		
		system("cls");
		// REGISTRATION //
		
		char registration[] = "RegistrationNo.txt";
		char registration1[] = "newregistration.txt";
		int reg;
		FILE *REG, *REG1;
		REG = fopen(registration, "r");
		fscanf(REG, "%d", &reg);
		   reg++;
		   CUST.regno = reg;
		REG1 = fopen(registration1, "w");
		fprintf(REG1, "%d", reg);
		fclose(REG1);
		fclose(REG);
		remove(registration);
		rename(registration1, registration);
		
		// copying the movie name //
		rewind(fp);
		printf("\n\n\n");
		printf("Registration No : REG%d", CUST.regno);
		printf("\nname : %s", CUST.name);			
		printf("\nMovie :");
		char str1[55],str2[55];
		int counter = 0;
		while(fgets(str1, sizeof(str1), fp)!=NULL)
		{
			++counter;
			if(counter == CUST.movieNo && counter<=3)
			{
		          printf("%s", str1);
				  break;	
			}
		}
		strcpy(str2,str1);
		printf("Tickets : %d", CUST.ticket);
		
		// PARKING SLOT //
		
		FILE *PAR, *PAR1;
		int slot;
		char park[] = "PARKING.txt";
		char park1[] = "parknew.txt";		
		if (CUST.parking == 1)
		{
				PAR = fopen(park, "r");
				fscanf(PAR, "%d", &slot);
				if(slot == 500)
				{
					int take, take1;
					char string[] = "Remaining_parking_slot.txt";
					char string1[] = "Remaining.txt";
					FILE *WE = fopen(string,"r");
					if(WE == NULL)
					{
						carslot = 0;
					}
					else
					{						
						fscanf(WE,"%d", &take);
						carslot = take;
						rewind(WE);
						FILE *WE1 = fopen(string1,"w");
						char str[10];
						printf("%d", take);
						while(fgets(str, sizeof(str), WE) != NULL)
						{
							take1 = atoi(&str);
							printf("%d", take1);
							if(take1 != take)
							{
								fprintf(WE1,"%d\n", take1);
							}
						}
						fclose(WE1);
						fclose(WE);
						remove(string);
						rename(string1,string);
					}
				}
				else
				{
					slot++;
					carslot = slot;
				}
				PAR1 = fopen(park1, "w");
				fprintf(PAR1, "%d", slot);
				fclose(PAR1);
				fclose(PAR);
				remove(park);
				rename(park1, park);
		}
		printf("\nYour parking slot no is : %d", carslot);
		
		// AMOUNT CALCULATION //
		
		char read[55];
		int select = 0;
		float price;
		rewind(fp);
		while(fgets(read, sizeof(read), fp))
		{
			select++;
			if(select == CUST.movieNo+6)
			{
				price = atoi(&read);
				CUST.amount = price * CUST.ticket;
				if(CUST.parking == 1)
				{
					CUST.amount += 100;
				}
			}
		}
		printf("\nTotal Amount : %.2f", CUST.amount);
		fclose(fp_new);
		fclose(fp);
		remove(file1);
		rename(file_new, file1);
		
		// calculating revenue //
		
		char rev[] = "HollywoodRevenue.txt";
		char rev1[] = "newhollyrev.txt";
		FILE *REV, *REV1;
		float revenue;
		char extract[10], extract1[10];
		int check = 0;
		
		
		REV = fopen(rev, "r");
		if(REV == NULL)
		{exit(1);}
		
		REV1 = fopen(rev1, "w");
		if(REV1 == NULL)
		{exit(1);}
		while(fgets(extract, sizeof(extract), REV) != NULL)
		{
			check++;
			if(check==5)
			{
				revenue = atoi(&extract);
				revenue += CUST.amount;				
				fprintf(REV1,"%.2f\n", revenue);
			}
			else
			{
				strcpy(extract1, extract);
				fprintf(REV1, "%s", extract1);
			}
		}
		fclose(REV1);
		fclose(REV);
		remove(rev);
		rename(rev1, rev);

		FILE *fp1 = fopen("Booking_Holly_fri_movies.txt","a+");
		if(fp1==NULL)
		{
			exit(1);
		}
		
		// PRINTING TO FILE //
		
        fprintf(fp1, "\t%-10d%-20s%-10d%-10d%-10.2f%-20s", CUST.regno, CUST.name, CUST.ticket, carslot, CUST.amount, str2);
        
		fclose(fp1);

		gotoxy(15,10);
		printf("*************** THANKS FOR REGISTERATION :) ***************");			
}


void Book_Holly_sat_movies()
{
   FILE *fp;
   char ch;
   fp = fopen("Book_Holly_sat_movies.txt","r");
   if(fp==NULL)
   {
   	 exit(1);
   }
   while(!feof(fp))
   {
   	 ch = fgetc(fp);
   	 printf("%c", ch);
   }
   fclose(fp);
}

void BookInHollySat()
{
	system("cls");
		customer CUST;
		printf("\nMovie -> Tickets -> Price -> Ratings -> No.of ratings\n\n");
	    Book_Holly_sat_movies();
		printf("\nNOTE : Booking of parking slot will cost RS 100. only one slot will be booked at per registeration\n");	
      	int wish;
      	printf("\nWould you like to get booked!!!! kindly press 1 for yes and 0 for no : ");
      	scanf("%d", &wish);
      	if(wish!=1)
      	{
      	    exit(0);	
		}
		system("cls");
        Book_Holly_sat_movies();
		
		// details input //
		
		fflush(stdin);
		printf("\nEnter your name : ");
		gets(CUST.name);
		
		printf("Enter the no of movie you want to watch : ");
		scanf("%d", &CUST.movieNo);
		
		printf("Enter no of tickets : ");
		scanf("%d", &CUST.ticket);
		
		printf("Do you want to avail parking 1)yes OR 0)no : ");
		scanf("%d", &CUST.parking);
		
		char file1[] = "Book_Holly_sat_movies.txt";
				
		FILE *fp = fopen(file1, "r");
		if(fp==NULL)
		{exit(1);}

		
		// REWRITING THE FILE //
		
		rewind(fp);
		char file_new[] = "new.txt";
		char str3[55], str4[55];
		FILE *fp_new = fopen(file_new, "w");
		if(fp_new==NULL)
		{exit(1);}
		int line = 0, num;
		while(fgets(str3, sizeof(str3), fp) != NULL)
		{
			line++;
			if(line==CUST.movieNo+3)
			{
				num = atoi(&str3);
				if(num == 0)
				{
					printf("\n\nSorry All tickets have been sold!!!");
					exit(1);
				}				
				num = num - CUST.ticket;
				fprintf(fp_new,"%d\n", num);
			}
			else
			{
				strcpy(str4, str3);
				fprintf(fp_new, "%s", str4);
			}
		}				
		
		
		system("cls");
		// REGISTRATION //
		
		char registration[] = "RegistrationNo.txt";
		char registration1[] = "newregistration.txt";
		int reg;
		FILE *REG, *REG1;
		REG = fopen(registration, "r");
		fscanf(REG, "%d", &reg);
		   reg++;
		   CUST.regno = reg;
		REG1 = fopen(registration1, "w");
		fprintf(REG1, "%d", reg);
		fclose(REG1);
		fclose(REG);
		remove(registration);
		rename(registration1, registration);
		
		// copying the movie name //
		rewind(fp);
		printf("\n\n\n");
		printf("Registration No : REG%d", CUST.regno);
		printf("\nname : %s", CUST.name);			
		printf("\nMovie :");
		char str1[55],str2[55];
		int counter = 0;
		while(fgets(str1, sizeof(str1), fp)!=NULL)
		{
			++counter;
			if(counter == CUST.movieNo && counter<=3)
			{
		          printf("%s", str1);
				  break;	
			}
		}
		strcpy(str2,str1);
		printf("Tickets : %d", CUST.ticket);
		
		// PARKING SLOT //
		
		FILE *PAR, *PAR1;
		int slot;
		char park[] = "PARKING.txt";
		char park1[] = "parknew.txt";		
		if (CUST.parking == 1)
		{
				PAR = fopen(park, "r");
				fscanf(PAR, "%d", &slot);
				if(slot == 500)
				{
					int take, take1;
					char string[] = "Remaining_parking_slot.txt";
					char string1[] = "Remaining.txt";
					FILE *WE = fopen(string,"r");
					if(WE == NULL)
					{
						carslot = 0;
					}
					else
					{						
						fscanf(WE,"%d", &take);
						carslot = take;
						rewind(WE);
						FILE *WE1 = fopen(string1,"w");
						char str[10];
						printf("%d", take);
						while(fgets(str, sizeof(str), WE) != NULL)
						{
							take1 = atoi(&str);
							printf("%d", take1);
							if(take1 != take)
							{
								fprintf(WE1,"%d\n", take1);
							}
						}
						fclose(WE1);
						fclose(WE);
						remove(string);
						rename(string1,string);
					}
				}
				else
				{
					slot++;
					carslot = slot;
				}
				PAR1 = fopen(park1, "w");
				fprintf(PAR1, "%d", slot);
				fclose(PAR1);
				fclose(PAR);
				remove(park);
				rename(park1, park);
		}
		printf("\nYour parking slot no is : %d", carslot);
		
		// AMOUNT CALCULATION //
		
		char read[55];
		int select = 0;
		float price;
		rewind(fp);
		while(fgets(read, sizeof(read), fp))
		{
			select++;
			if(select == CUST.movieNo+6)
			{
				price = atoi(&read);
				CUST.amount = price * CUST.ticket;
				if(CUST.parking == 1)
				{
					CUST.amount += 100;
				}
			}
		}
		printf("\nTotal Amount : %.2f", CUST.amount);

		fclose(fp_new);
		fclose(fp);
		remove(file1);
		rename(file_new, file1);
		
		// calculating revenue //
		
		char rev[] = "HollywoodRevenue.txt";
		char rev1[] = "newhollyrev.txt";
		FILE *REV, *REV1;
		float revenue;
		char extract[10], extract1[10];
		int check = 0;
		
		
		REV = fopen(rev, "r");
		if(REV == NULL)
		{exit(1);}
		
		REV1 = fopen(rev1, "w");
		if(REV1 == NULL)
		{exit(1);}
		while(fgets(extract, sizeof(extract), REV) != NULL)
		{
			check++;
			if(check==6)
			{
				revenue = atoi(&extract);
				revenue += CUST.amount;				
				fprintf(REV1,"%.2f\n", revenue);
			}
			else
			{
				strcpy(extract1, extract);
				fprintf(REV1, "%s", extract1);
			}
		}
		fclose(REV1);
		fclose(REV);
		remove(rev);
		rename(rev1, rev);

		FILE *fp1 = fopen("Booking_Holly_sat_movies.txt","a+");
		if(fp1==NULL)
		{
			exit(1);
		}
		
		// PRINTING TO FILE //
		
        fprintf(fp1, "\t%-10d%-20s%-10d%-10d%-10.2f%-20s", CUST.regno, CUST.name, CUST.ticket, carslot, CUST.amount, str2);
        
		fclose(fp1);

		gotoxy(15,10);
		printf("*************** THANKS FOR REGISTERATION :) ***************");			
}


void Book_Holly_sun_movies()
{
   FILE *fp;
   char ch;
   fp = fopen("Book_Holly_sun_movies.txt","r");
   if(fp==NULL)
   {
   	 exit(1);
   }
   while(!feof(fp))
   {
   	 ch = fgetc(fp);
   	 printf("%c", ch);
   }
   fclose(fp);
}

void BookInHollySun()
{
	system("cls");
		customer CUST;
		printf("\nMovie -> Tickets -> Price -> Ratings -> No.of ratings\n\n");
	    Book_Holly_sun_movies();
		printf("\nNOTE : Booking of parking slot will cost RS 100. only one slot will be booked at per registeration\n");	
      	int wish;
      	printf("\nWould you like to get booked!!!! kindly press 1 for yes and 0 for no : ");
      	scanf("%d", &wish);
      	if(wish!=1)
      	{
      	    exit(0);	
		}
		system("cls");
        Book_Holly_sun_movies();
		
		// details input //
		
		fflush(stdin);
		printf("\nEnter your name : ");
		gets(CUST.name);
		
		printf("Enter the no of movie you want to watch : ");
		scanf("%d", &CUST.movieNo);
		
		printf("Enter no of tickets : ");
		scanf("%d", &CUST.ticket);
		
		printf("Do you want to avail parking 1)yes OR 0)no : ");
		scanf("%d", &CUST.parking);
		
		
		char file1[] = "Book_Holly_sun_movies.txt";
				
		FILE *fp = fopen(file1, "r");
		if(fp==NULL)
		{exit(1);}
		
		// REWRITING THE FILE //
		
		rewind(fp);
		char file_new[] = "new.txt";
		char str3[55], str4[55];
		FILE *fp_new = fopen(file_new, "w");
		if(fp_new==NULL)
		{exit(1);}
		int line = 0, num;
		while(fgets(str3, sizeof(str3), fp) != NULL)
		{
			line++;
			if(line==CUST.movieNo+3)
			{
				num = atoi(&str3);
				if(num == 0)
				{
					printf("\n\nSorry All tickets have been sold!!!");
					exit(1);
				}				
				num = num - CUST.ticket;
				fprintf(fp_new,"%d\n", num);
			}
			else
			{
				strcpy(str4, str3);
				fprintf(fp_new, "%s", str4);
			}
		}				
		
		system("cls");
		// REGISTRATION //
		
		char registration[] = "RegistrationNo.txt";
		char registration1[] = "newregistration.txt";
		int reg;
		FILE *REG, *REG1;
		REG = fopen(registration, "r");
		fscanf(REG, "%d", &reg);
		   reg++;
		   CUST.regno = reg;
		REG1 = fopen(registration1, "w");
		fprintf(REG1, "%d", reg);
		fclose(REG1);
		fclose(REG);
		remove(registration);
		rename(registration1, registration);
		
		// copying the movie name //

		rewind(fp);
		printf("\n\n\n");
		printf("Registration No : REG%d", CUST.regno);
		printf("\nname : %s", CUST.name);			
		printf("\nMovie :");
		char str1[55],str2[55];
		int counter = 0;
		while(fgets(str1, sizeof(str1), fp)!=NULL)
		{
			++counter;
			if(counter == CUST.movieNo && counter<=3)
			{
		          printf("%s", str1);
				  break;	
			}
		}
		strcpy(str2,str1);
		printf("Tickets : %d", CUST.ticket);
		
		// PARKING SLOT //
		
		FILE *PAR, *PAR1;
		int slot;
		char park[] = "PARKING.txt";
		char park1[] = "parknew.txt";		
		if (CUST.parking == 1)
		{
				PAR = fopen(park, "r");
				fscanf(PAR, "%d", &slot);
				if(slot == 500)
				{
					int take, take1;
					char string[] = "Remaining_parking_slot.txt";
					char string1[] = "Remaining.txt";
					FILE *WE = fopen(string,"r");
					if(WE == NULL)
					{
						carslot = 0;
					}
					else
					{						
						fscanf(WE,"%d", &take);
						carslot = take;
						rewind(WE);
						FILE *WE1 = fopen(string1,"w");
						char str[10];
						printf("%d", take);
						while(fgets(str, sizeof(str), WE) != NULL)
						{
							take1 = atoi(&str);
							printf("%d", take1);
							if(take1 != take)
							{
								fprintf(WE1,"%d\n", take1);
							}
						}
						fclose(WE1);
						fclose(WE);
						remove(string);
						rename(string1,string);
					}
				}
				else
				{
					slot++;
					carslot = slot;
				}
				PAR1 = fopen(park1, "w");
				fprintf(PAR1, "%d", slot);
				fclose(PAR1);
				fclose(PAR);
				remove(park);
				rename(park1, park);
		}
		printf("\nYour parking slot no is : %d", carslot);
		
		// AMOUNT CALCULATION //
		
		char read[55];
		int select = 0;
		float price;
		rewind(fp);
		while(fgets(read, sizeof(read), fp))
		{
			select++;
			if(select == CUST.movieNo+6)
			{
				price = atoi(&read);
				CUST.amount = price * CUST.ticket;
				if(CUST.parking == 1)
				{
					CUST.amount += 100;
				}
			}
		}
		printf("\nTotal Amount : %.2f", CUST.amount);
		fclose(fp_new);
		fclose(fp);
		remove(file1);
		rename(file_new, file1);
		
		// calculating revenue //
		
		char rev[] = "HollywoodRevenue.txt";
		char rev1[] = "newhollyrev.txt";
		FILE *REV, *REV1;
		float revenue;
		char extract[10], extract1[10];
		int check = 0;
		
		
		REV = fopen(rev, "r");
		if(REV == NULL)
		{exit(1);}
		
		REV1 = fopen(rev1, "w");
		if(REV1 == NULL)
		{exit(1);}
		while(fgets(extract, sizeof(extract), REV) != NULL)
		{
			check++;
			if(check==7)
			{
				revenue = atoi(&extract);
				revenue += CUST.amount;				
				fprintf(REV1,"%.2f\n", revenue);
			}
			else
			{
				strcpy(extract1, extract);
				fprintf(REV1, "%s", extract1);
			}
		}
		fclose(REV1);
		fclose(REV);
		remove(rev);
		rename(rev1, rev);

		FILE *fp1 = fopen("Booking_Holly_sun_movies.txt","a+");
		if(fp1==NULL)
		{
			exit(1);
		}
		
		// PRINTING TO FILE //
		
        fprintf(fp1, "\t%-10d%-20s%-10d%-10d%-10.2f%-20s", CUST.regno, CUST.name, CUST.ticket, carslot, CUST.amount, str2);
        
		fclose(fp1);

		gotoxy(15,10);
		printf("*************** THANKS FOR REGISTERATION :) ***************");			
}


void Bollywood()
{
			
		system("cls");
		printf("You entered in Bollywood");
		
		void (*ptr[7])() = {BookInBollyMon, BookInBollyTue, BookInBollyWed, BookInBollyThu, BookInBollyFri, BookInBollySat, BookInBollySun};
		printf("\n Select the day \n 1) Monday \n 2) Tuesday \n 3) Wednesday \n 4) Thursday \n 5) Friday \n 6) Saturday \n 7) Sunday");
		
		int day;
		printf("\n Enter your selection : ");
		scanf("%d", &day);
		
		(*ptr[day-1])();
}


void Book_Bolly_mon_movies()
{
   FILE *fp;
   char ch;
   fp = fopen("Book_Bolly_mon_movies.txt","r");
   if(fp==NULL)
   {
   	 exit(1);
   }
   while(!feof(fp))
   {
   	 ch = fgetc(fp);
   	 printf("%c", ch);
   }
   fclose(fp);
}

void BookInBollyMon()
{
	system("cls");
		customer CUST;
		printf("\nMovie -> Tickets -> Price -> Ratings -> No.of ratings\n\n");
	    Book_Bolly_mon_movies();
		printf("\nNOTE : Booking of parking slot will cost RS 100. only one slot will be booked at per registeration\n");	
      	int wish;
      	printf("\nWould you like to get booked!!!! kindly press 1 for yes and 0 for no : ");
      	scanf("%d", &wish);
      	if(wish!=1)
      	{
      	    exit(0);	
		}
		system("cls");
        Book_Bolly_mon_movies();
		
		// details input //
		
		fflush(stdin);
		printf("\nEnter your name : ");
		gets(CUST.name);
		
		printf("Enter the no of movie you want to watch : ");
		scanf("%d", &CUST.movieNo);
		
		printf("Enter no of tickets : ");
		scanf("%d", &CUST.ticket);
		
		printf("Do you want to avail parking 1)yes OR 0)no : ");
		scanf("%d", &CUST.parking);
		
		char file1[] = "Book_Bolly_mon_movies.txt";
				
		FILE *fp = fopen(file1, "r");
		if(fp==NULL)
		{exit(1);}	
		
		// REWRITING THE FILE //
		
		rewind(fp);
		char file_new[] = "new.txt";
		char str3[55], str4[55];
		FILE *fp_new = fopen(file_new, "w");
		if(fp_new==NULL)
		{exit(1);}
		int line = 0, num;
		while(fgets(str3, sizeof(str3), fp) != NULL)
		{
			line++;
			if(line==CUST.movieNo+3)
			{
				num = atoi(&str3);
				if(num == 0)
				{
					printf("\n\nSorry All tickets have been sold!!!");
					exit(1);
				}				
				num = num - CUST.ticket;
				fprintf(fp_new,"%d\n", num);
			}
			else
			{
				strcpy(str4, str3);
				fprintf(fp_new, "%s", str4);
			}
		}			
		
		system("cls");
		// REGISTRATION //
		
		char registration[] = "RegistrationNo.txt";
		char registration1[] = "newregistration.txt";
		int reg;
		FILE *REG, *REG1;
		REG = fopen(registration, "r");
		fscanf(REG, "%d", &reg);
		   reg++;
		   CUST.regno = reg;
		REG1 = fopen(registration1, "w");
		fprintf(REG1, "%d", reg);
		fclose(REG1);
		fclose(REG);
		remove(registration);
		rename(registration1, registration);
		
		// copying the movie name //
		rewind(fp);
		printf("\n\n\n");
		printf("Registration No : REG%d", CUST.regno);
		printf("\nname : %s", CUST.name);			
		printf("\nMovie :");
		char str1[55],str2[55];
		int counter = 0;
		while(fgets(str1, sizeof(str1), fp)!=NULL)
		{
			++counter;
			if(counter == CUST.movieNo && counter<=3)
			{
		          printf("%s", str1);
				  break;	
			}
		}
		strcpy(str2,str1);
		printf("Tickets : %d", CUST.ticket);
		
		// PARKING SLOT //
		
		FILE *PAR, *PAR1;
		int slot;
		char park[] = "PARKING.txt";
		char park1[] = "parknew.txt";		
		if (CUST.parking == 1)
		{
				PAR = fopen(park, "r");
				fscanf(PAR, "%d", &slot);
				if(slot == 500)
				{
					int take, take1;
					char string[] = "Remaining_parking_slot.txt";
					char string1[] = "Remaining.txt";
					FILE *WE = fopen(string,"r");
					if(WE == NULL)
					{
						carslot = 0;
					}
					else
					{						
						fscanf(WE,"%d", &take);
						carslot = take;
						rewind(WE);
						FILE *WE1 = fopen(string1,"w");
						char str[10];
						printf("%d", take);
						while(fgets(str, sizeof(str), WE) != NULL)
						{
							take1 = atoi(&str);
							printf("%d", take1);
							if(take1 != take)
							{
								fprintf(WE1,"%d\n", take1);
							}
						}
						fclose(WE1);
						fclose(WE);
						remove(string);
						rename(string1,string);
					}
				}
				else
				{
					slot++;
					carslot = slot;
				}
				PAR1 = fopen(park1, "w");
				fprintf(PAR1, "%d", slot);
				fclose(PAR1);
				fclose(PAR);
				remove(park);
				rename(park1, park);
		}
		printf("\nYour parking slot no is : %d", carslot);
		
		// AMOUNT CALCULATION //
		
		char read[55];
		int select = 0;
		float price;
		rewind(fp);
		while(fgets(read, sizeof(read), fp))
		{
			select++;
			if(select == CUST.movieNo+6)
			{
				price = atoi(&read);
				CUST.amount = price * CUST.ticket;
				if(CUST.parking == 1)
				{
					CUST.amount += 100;
				}
			}
		}
		printf("\nTotal Amount : %.2f", CUST.amount);

		fclose(fp_new);
		fclose(fp);
		remove(file1);
		rename(file_new, file1);
		
		// calculating revenue //
		
		char rev[] = "BollywoodRevenue.txt";
		char rev1[] = "newhollyrev.txt";
		FILE *REV, *REV1;
		float revenue;
		char extract[10], extract1[10];
		int check = 0;
		
		
		REV = fopen(rev, "r");
		if(REV == NULL)
		{exit(1);}
		
		REV1 = fopen(rev1, "w");
		if(REV1 == NULL)
		{exit(1);}
		while(fgets(extract, sizeof(extract), REV) != NULL)
		{
			check++;
			if(check==1)
			{
				revenue = atoi(&extract);
				revenue += CUST.amount;				
				fprintf(REV1,"%.2f\n", revenue);
			}
			else
			{
				strcpy(extract1, extract);
				fprintf(REV1, "%s", extract1);
			}
		}
		fclose(REV1);
		fclose(REV);
		remove(rev);
		rename(rev1, rev);

		FILE *fp1 = fopen("Booking_Bolly_mon_movies.txt","a+");
		if(fp1==NULL)
		{
			exit(1);
		}
		
		// PRINTING TO FILE //
		
        fprintf(fp1, "\t%-10d%-20s%-10d%-10d%-10.2f%-20s", CUST.regno, CUST.name, CUST.ticket, carslot, CUST.amount, str2);
        
		fclose(fp1);

		gotoxy(15,10);
		printf("*************** THANKS FOR REGISTERATION :) ***************");			
}


void Book_Bolly_tue_movies()
{
   FILE *fp;
   char ch;
   fp = fopen("Book_Bolly_tue_movies.txt","r");
   if(fp==NULL)
   {
   	 exit(1);
   }
   while(!feof(fp))
   {
   	 ch = fgetc(fp);
   	 printf("%c", ch);
   }
   fclose(fp);
}

void BookInBollyTue()
{
	system("cls");
		customer CUST;
		printf("\nMovie -> Tickets -> Price -> Ratings -> No.of ratings\n\n");
	    Book_Bolly_tue_movies();
		printf("\nNOTE : Booking of parking slot will cost RS 100. only one slot will be booked at per registeration\n");	
      	int wish;
      	printf("\nWould you like to get booked!!!! kindly press 1 for yes and 0 for no : ");
      	scanf("%d", &wish);
      	if(wish!=1)
      	{
      	    exit(0);	
		}
		system("cls");
        Book_Bolly_tue_movies();
		
		// details input //
		
		fflush(stdin);
		printf("\nEnter your name : ");
		gets(CUST.name);
		
		printf("Enter the no of movie you want to watch : ");
		scanf("%d", &CUST.movieNo);
		
		printf("Enter no of tickets : ");
		scanf("%d", &CUST.ticket);
		
		printf("Do you want to avail parking 1)yes OR 0)no : ");
		scanf("%d", &CUST.parking);

		char file1[] = "Book_Bolly_tue_movies.txt";
				
		FILE *fp = fopen(file1, "r");
		if(fp==NULL)
		{exit(1);}	
		
		// REWRITING THE FILE //
		
		rewind(fp);
		char file_new[] = "new.txt";
		char str3[55], str4[55];
		FILE *fp_new = fopen(file_new, "w");
		if(fp_new==NULL)
		{exit(1);}
		int line = 0, num;
		while(fgets(str3, sizeof(str3), fp) != NULL)
		{
			line++;
			if(line==CUST.movieNo+3)
			{
				num = atoi(&str3);
				if(num == 0)
				{
					printf("\n\n Sorry All Tickets have been sold!!!");
					exit(1);
				}
				num = num - CUST.ticket;
				fprintf(fp_new,"%d\n", num);
			}
			else
			{
				strcpy(str4, str3);
				fprintf(fp_new, "%s", str4);
			}
		}			
		
		system("cls");
		// REGISTRATION //
		
		char registration[] = "RegistrationNo.txt";
		char registration1[] = "newregistration.txt";
		int reg;
		FILE *REG, *REG1;
		REG = fopen(registration, "r");
		fscanf(REG, "%d", &reg);
		   reg++;
		   CUST.regno = reg;
		REG1 = fopen(registration1, "w");
		fprintf(REG1, "%d", reg);
		fclose(REG1);
		fclose(REG);
		remove(registration);
		rename(registration1, registration);
		
		// copying the movie name //
		
		rewind(fp);
		printf("\n\n\n");
		printf("Registration No : REG%d", CUST.regno);
		printf("\nname : %s", CUST.name);			
		printf("\nMovie :");
		char str1[55],str2[55];
		int counter = 0;
		while(fgets(str1, sizeof(str1), fp)!=NULL)
		{
			++counter;
			if(counter == CUST.movieNo && counter<=3)
			{
		          printf("%s", str1);
				  break;	
			}
		}
		strcpy(str2,str1);
		printf("Tickets : %d", CUST.ticket);
		
		// PARKING SLOT //
		
		FILE *PAR, *PAR1;
		int slot;
		char park[] = "PARKING.txt";
		char park1[] = "parknew.txt";		
		if (CUST.parking == 1)
		{
				PAR = fopen(park, "r");
				fscanf(PAR, "%d", &slot);
				if(slot == 500)
				{
					int take, take1;
					char string[] = "Remaining_parking_slot.txt";
					char string1[] = "Remaining.txt";
					FILE *WE = fopen(string,"r");
					if(WE == NULL)
					{
						carslot = 0;
					}
					else
					{						
						fscanf(WE,"%d", &take);
						carslot = take;
						rewind(WE);
						FILE *WE1 = fopen(string1,"w");
						char str[10];
						printf("%d", take);
						while(fgets(str, sizeof(str), WE) != NULL)
						{
							take1 = atoi(&str);
							printf("%d", take1);
							if(take1 != take)
							{
								fprintf(WE1,"%d\n", take1);
							}
						}
						fclose(WE1);
						fclose(WE);
						remove(string);
						rename(string1,string);
					}
				}
				else
				{
					slot++;
					carslot = slot;
				}
				PAR1 = fopen(park1, "w");
				fprintf(PAR1, "%d", slot);
				fclose(PAR1);
				fclose(PAR);
				remove(park);
				rename(park1, park);
		}
		printf("\nYour parking slot no is : %d", carslot);
		
		// AMOUNT CALCULATION //
		
		char read[55];
		int select = 0;
		float price;
		rewind(fp);
		while(fgets(read, sizeof(read), fp))
		{
			select++;
			if(select == CUST.movieNo+6)
			{
				price = atoi(&read);
				CUST.amount = price * CUST.ticket;
				if(CUST.parking == 1)
				{
					CUST.amount += 100;
				}
			}
		}
		printf("\nTotal Amount : %.2f", CUST.amount);

		fclose(fp_new);
		fclose(fp);
		remove(file1);
		rename(file_new, file1);
		
		// calculating revenue //
		
		char rev[] = "BollywoodRevenue.txt";
		char rev1[] = "newhollyrev.txt";
		FILE *REV, *REV1;
		float revenue;
		char extract[10], extract1[10];
		int check = 0;
		
		
		REV = fopen(rev, "r");
		if(REV == NULL)
		{exit(1);}
		
		REV1 = fopen(rev1, "w");
		if(REV1 == NULL)
		{exit(1);}
		while(fgets(extract, sizeof(extract), REV) != NULL)
		{
			check++;
			if(check==2)
			{
				revenue = atoi(&extract);
				revenue += CUST.amount;				
				fprintf(REV1,"%.2f\n", revenue);
			}
			else
			{
				strcpy(extract1, extract);
				fprintf(REV1, "%s", extract1);
			}
		}
		fclose(REV1);
		fclose(REV);
		remove(rev);
		rename(rev1, rev);
		
		FILE *fp1 = fopen("Booking_Bolly_tue_movies.txt","a+");
		if(fp1==NULL)
		{
			exit(1);
		}
		
		// PRINTING TO FILE //
		
        fprintf(fp1, "\t%-10d%-20s%-10d%-10d%-10.2f%-20s", CUST.regno, CUST.name, CUST.ticket, carslot, CUST.amount, str2);
        
		fclose(fp1);		
		
		gotoxy(15,10);
		printf("*************** THANKS FOR REGISTERATION :) ***************");			
}


void Book_Bolly_wed_movies()
{
   FILE *fp;
   char ch;
   fp = fopen("Book_Bolly_wed_movies.txt","r");
   if(fp==NULL)
   {
   	 exit(1);
   }
   while(!feof(fp))
   {
   	 ch = fgetc(fp);
   	 printf("%c", ch);
   }
   fclose(fp);
}

void BookInBollyWed()
{
	system("cls");
		customer CUST;
		printf("\nMovie -> Tickets -> Price -> Ratings -> No.of ratings\n\n");
	    Book_Bolly_wed_movies();
		printf("\nNOTE : Booking of parking slot will cost RS 100. only one slot will be booked at per registeration\n");	
      	int wish;
      	printf("\nWould you like to get booked!!!! kindly press 1 for yes and 0 for no : ");
      	scanf("%d", &wish);
      	if(wish!=1)
      	{
      	    exit(0);	
		}
		system("cls");
        Book_Bolly_wed_movies();
		
		// details input //
		
		fflush(stdin);
		printf("\nEnter your name : ");
		gets(CUST.name);
		
		printf("Enter the no of movie you want to watch : ");
		scanf("%d", &CUST.movieNo);
		
		printf("Enter no of tickets : ");
		scanf("%d", &CUST.ticket);
		
		printf("Do you want to avail parking 1)yes OR 0)no : ");
		scanf("%d", &CUST.parking);
		
		char file1[] = "Book_Bolly_wed_movies.txt";
				
		FILE *fp = fopen(file1, "r");
		if(fp==NULL)
		{exit(1);}	
		
		// REWRITING THE FILE //
		
		rewind(fp);
		char file_new[] = "new.txt";
		char str3[55], str4[55];
		FILE *fp_new = fopen(file_new, "w");
		if(fp_new==NULL)
		{exit(1);}
		int line = 0, num;
		while(fgets(str3, sizeof(str3), fp) != NULL)
		{
			line++;
			if(line==CUST.movieNo+3)
			{
				num = atoi(&str3);
				if(num == 0)
				{
					printf("\n\n Sorry All tickets have been sold !!!");
					exit(1);
				}
				num = num - CUST.ticket;
				fprintf(fp_new,"%d\n", num);
			}
			else
			{
				strcpy(str4, str3);
				fprintf(fp_new, "%s", str4);
			}
		}			
		
		system("cls");
		// REGISTRATION //
		
		char registration[] = "RegistrationNo.txt";
		char registration1[] = "newregistration.txt";
		int reg;
		FILE *REG, *REG1;
		REG = fopen(registration, "r");
		fscanf(REG, "%d", &reg);
		   reg++;
		   CUST.regno = reg;
		REG1 = fopen(registration1, "w");
		fprintf(REG1, "%d", reg);
		fclose(REG1);
		fclose(REG);
		remove(registration);
		rename(registration1, registration);
		
		// copying the movie name //
		rewind(fp);
		printf("\n\n\n");
		printf("Registration No : REG%d", CUST.regno);
		printf("\nname : %s", CUST.name);			
		printf("\nMovie :");
		char str1[55],str2[55];
		int counter = 0;
		while(fgets(str1, sizeof(str1), fp)!=NULL)
		{
			++counter;
			if(counter == CUST.movieNo && counter<=3)
			{
		          printf("%s", str1);
				  break;	
			}
		}
		strcpy(str2,str1);
		printf("Tickets : %d", CUST.ticket);
		
		// PARKING SLOT //
		
		FILE *PAR, *PAR1;
		int slot;
		char park[] = "PARKING.txt";
		char park1[] = "parknew.txt";		
		if (CUST.parking == 1)
		{
				PAR = fopen(park, "r");
				fscanf(PAR, "%d", &slot);
				if(slot == 500)
				{
					int take, take1;
					char string[] = "Remaining_parking_slot.txt";
					char string1[] = "Remaining.txt";
					FILE *WE = fopen(string,"r");
					if(WE == NULL)
					{
						carslot = 0;
					}
					else
					{						
						fscanf(WE,"%d", &take);
						carslot = take;
						rewind(WE);
						FILE *WE1 = fopen(string1,"w");
						char str[10];
						printf("%d", take);
						while(fgets(str, sizeof(str), WE) != NULL)
						{
							take1 = atoi(&str);
							printf("%d", take1);
							if(take1 != take)
							{
								fprintf(WE1,"%d\n", take1);
							}
						}
						fclose(WE1);
						fclose(WE);
						remove(string);
						rename(string1,string);
					}
				}
				else
				{
					slot++;
					carslot = slot;
				}
				PAR1 = fopen(park1, "w");
				fprintf(PAR1, "%d", slot);
				fclose(PAR1);
				fclose(PAR);
				remove(park);
				rename(park1, park);
		}
		printf("\nYour parking slot no is : %d", carslot);
		
		// AMOUNT CALCULATION //
		
		char read[55];
		int select = 0;
		float price;
		rewind(fp);
		while(fgets(read, sizeof(read), fp))
		{
			select++;
			if(select == CUST.movieNo+6)
			{
				price = atoi(&read);
				CUST.amount = price * CUST.ticket;
				if(CUST.parking == 1)
				{
					CUST.amount += 100;
				}
			}
		}
		printf("\nTotal Amount : %.2f", CUST.amount);
		fclose(fp_new);
		fclose(fp);
		remove(file1);
		rename(file_new, file1);
		
		// calculating revenue //
		
		char rev[] = "BollywoodRevenue.txt";
		char rev1[] = "newhollyrev.txt";
		FILE *REV, *REV1;
		float revenue;
		char extract[10], extract1[10];
		int check = 0;
		
		
		REV = fopen(rev, "r");
		if(REV == NULL)
		{exit(1);}
		
		REV1 = fopen(rev1, "w");
		if(REV1 == NULL)
		{exit(1);}
		while(fgets(extract, sizeof(extract), REV) != NULL)
		{
			check++;
			if(check==3)
			{
				revenue = atoi(&extract);
				revenue += CUST.amount;				
				fprintf(REV1,"%.2f\n", revenue);
			}
			else
			{
				strcpy(extract1, extract);
				fprintf(REV1, "%s", extract1);
			}
		}
		fclose(REV1);
		fclose(REV);
		remove(rev);
		rename(rev1, rev);

		FILE *fp1 = fopen("Booking_Bolly_wed_movies.txt","a+");
		if(fp1==NULL)
		{
			exit(1);
		}
		
		// PRINTING TO FILE //
		
        fprintf(fp1, "\t%-10d%-20s%-10d%-10d%-10.2f%-20s", CUST.regno, CUST.name, CUST.ticket, carslot, CUST.amount, str2);
        
		fclose(fp1);

		gotoxy(15,10);
		printf("*************** THANKS FOR REGISTERATION :) ***************");			
}


void Book_Bolly_thu_movies()
{
   FILE *fp;
   char ch;
   fp = fopen("Book_Bolly_thu_movies.txt","r");
   if(fp==NULL)
   {
   	 exit(1);
   }
   while(!feof(fp))
   {
   	 ch = fgetc(fp);
   	 printf("%c", ch);
   }
   fclose(fp);
}

void BookInBollyThu()
{
	system("cls");
		customer CUST;
		printf("\nMovie -> Tickets -> Price -> Ratings -> No.of ratings\n\n");
	    Book_Bolly_thu_movies();
		printf("\nNOTE : Booking of parking slot will cost RS 100. only one slot will be booked at per registeration\n");	
      	int wish;
      	printf("\nWould you like to get booked!!!! kindly press 1 for yes and 0 for no : ");
      	scanf("%d", &wish);
      	if(wish!=1)
      	{
      	    exit(0);	
		}
		system("cls");
        Book_Bolly_thu_movies();
		
		// details input //
		
		fflush(stdin);
		printf("\nEnter your name : ");
		gets(CUST.name);
		
		printf("Enter the no of movie you want to watch : ");
		scanf("%d", &CUST.movieNo);
		
		printf("Enter no of tickets : ");
		scanf("%d", &CUST.ticket);
		
		printf("Do you want to avail parking 1)yes OR 0)no : ");
		scanf("%d", &CUST.parking);
		
		char file1[] = "Book_Bolly_thu_movies.txt";
				
		FILE *fp = fopen(file1, "r");
		if(fp==NULL)
		{exit(1);}		
		
		// REWRITING THE FILE //
		
		rewind(fp);
		char file_new[] = "new.txt";
		char str3[55], str4[55];
		FILE *fp_new = fopen(file_new, "w");
		if(fp_new==NULL)
		{exit(1);}
		int line = 0, num;
		while(fgets(str3, sizeof(str3), fp) != NULL)
		{
			line++;
			if(line==CUST.movieNo+3)
			{
				num = atoi(&str3);
				if(num == 0)
				{
					printf("\n\n Sorry All tickets have been sold!!!");
					exit(1);
				}
				num = num - CUST.ticket;
				fprintf(fp_new,"%d\n", num);
			}
			else
			{
				strcpy(str4, str3);
				fprintf(fp_new, "%s", str4);
			}
		}		
		system("cls");
		// REGISTRATION //
		
		char registration[] = "RegistrationNo.txt";
		char registration1[] = "newregistration.txt";
		int reg;
		FILE *REG, *REG1;
		REG = fopen(registration, "r");
		fscanf(REG, "%d", &reg);
		   reg++;
		   CUST.regno = reg;
		REG1 = fopen(registration1, "w");
		fprintf(REG1, "%d", reg);
		fclose(REG1);
		fclose(REG);
		remove(registration);
		rename(registration1, registration);
		
		// copying the movie name //
		rewind(fp);
		printf("\n\n\n");
		printf("Registration No : REG%d", CUST.regno);
		printf("\nname : %s", CUST.name);			
		printf("\nMovie :");
		char str1[55],str2[55];
		int counter = 0;
		while(fgets(str1, sizeof(str1), fp)!=NULL)
		{
			++counter;
			if(counter == CUST.movieNo && counter<=3)
			{
		          printf("%s", str1);
				  break;	
			}
		}
		strcpy(str2,str1);
		printf("Tickets : %d", CUST.ticket);
		
		// PARKING SLOT //
		
		FILE *PAR, *PAR1;
		int slot;
		char park[] = "PARKING.txt";
		char park1[] = "parknew.txt";		
		if (CUST.parking == 1)
		{
				PAR = fopen(park, "r");
				fscanf(PAR, "%d", &slot);
				if(slot == 500)
				{
					int take, take1;
					char string[] = "Remaining_parking_slot.txt";
					char string1[] = "Remaining.txt";
					FILE *WE = fopen(string,"r");
					if(WE == NULL)
					{
						carslot = 0;
					}
					else
					{						
						fscanf(WE,"%d", &take);
						carslot = take;
						rewind(WE);
						FILE *WE1 = fopen(string1,"w");
						char str[10];
						printf("%d", take);
						while(fgets(str, sizeof(str), WE) != NULL)
						{
							take1 = atoi(&str);
							printf("%d", take1);
							if(take1 != take)
							{
								fprintf(WE1,"%d\n", take1);
							}
						}
						fclose(WE1);
						fclose(WE);
						remove(string);
						rename(string1,string);
					}
				}
				else
				{
					slot++;
					carslot = slot;
				}
				PAR1 = fopen(park1, "w");
				fprintf(PAR1, "%d", slot);
				fclose(PAR1);
				fclose(PAR);
				remove(park);
				rename(park1, park);
		}
		printf("\nYour parking slot no is : %d", carslot);
		
		// AMOUNT CALCULATION //
		
		char read[55];
		int select = 0;
		float price;
		rewind(fp);
		while(fgets(read, sizeof(read), fp))
		{
			select++;
			if(select == CUST.movieNo+6)
			{
				price = atoi(&read);
				CUST.amount = price * CUST.ticket;
				if(CUST.parking == 1)
				{
					CUST.amount += 100;
				}
			}
		}
		printf("\nTotal Amount : %.2f", CUST.amount);
		
		fclose(fp_new);
		fclose(fp);
		remove(file1);
		rename(file_new, file1);
		
		// calculating revenue //
		
		char rev[] = "BollywoodRevenue.txt";
		char rev1[] = "newhollyrev.txt";
		FILE *REV, *REV1;
		float revenue;
		char extract[10], extract1[10];
		int check = 0;
		
		
		REV = fopen(rev, "r");
		if(REV == NULL)
		{exit(1);}
		
		REV1 = fopen(rev1, "w");
		if(REV1 == NULL)
		{exit(1);}
		while(fgets(extract, sizeof(extract), REV) != NULL)
		{
			check++;
			if(check==4)
			{
				revenue = atoi(&extract);
				revenue += CUST.amount;				
				fprintf(REV1,"%.2f\n", revenue);
			}
			else
			{
				strcpy(extract1, extract);
				fprintf(REV1, "%s", extract1);
			}
		}
		fclose(REV1);
		fclose(REV);
		remove(rev);
		rename(rev1, rev);
		
		FILE *fp1 = fopen("Booking_Bolly_thu_movies.txt","a+");
		if(fp1==NULL)
		{
			exit(1);
		}
		
		// PRINTING TO FILE //
		
        fprintf(fp1, "\t%-10d%-20s%-10d%-10d%-10.2f%-20s", CUST.regno, CUST.name, CUST.ticket, carslot, CUST.amount, str2);
        
		fclose(fp1);		
		
		gotoxy(15,10);
		printf("*************** THANKS FOR REGISTERATION :) ***************");		
			
}


void Book_Bolly_fri_movies()
{
   FILE *fp;
   char ch;
   fp = fopen("Book_Bolly_fri_movies.txt","r");
   if(fp==NULL)
   {
   	 exit(1);
   }
   while(!feof(fp))
   {
   	 ch = fgetc(fp);
   	 printf("%c", ch);
   }
   fclose(fp);
}

void BookInBollyFri()
{
	system("cls");
		customer CUST;
		printf("\nMovie -> Tickets -> Price -> Ratings -> No.of ratings\n\n");
	    Book_Bolly_fri_movies();
		printf("\nNOTE : Booking of parking slot will cost RS 100. only one slot will be booked at per registeration\n");	
      	int wish;
      	printf("\nWould you like to get booked!!!! kindly press 1 for yes and 0 for no : ");
      	scanf("%d", &wish);
      	if(wish!=1)
      	{
      	    exit(0);	
		}
		system("cls");
        Book_Bolly_fri_movies();
		
		// details input //
		
		fflush(stdin);
		printf("\nEnter your name : ");
		gets(CUST.name);
		
		printf("Enter the no of movie you want to watch : ");
		scanf("%d", &CUST.movieNo);
		
		printf("Enter no of tickets : ");
		scanf("%d", &CUST.ticket);
		
		printf("Do you want to avail parking 1)yes OR 0)no : ");
		scanf("%d", &CUST.parking);
		
		char file1[] = "Book_Bolly_fri_movies.txt";
				
		FILE *fp = fopen(file1, "r");
		if(fp==NULL)
		{exit(1);}	
		
		
		// REWRITING THE FILE //
		
		rewind(fp);
		char file_new[] = "new.txt";
		char str3[55], str4[55];
		FILE *fp_new = fopen(file_new, "w");
		if(fp_new==NULL)
		{exit(1);}
		int line = 0, num;
		while(fgets(str3, sizeof(str3), fp) != NULL)
		{
			line++;
			if(line==CUST.movieNo+3)
			{
				num = atoi(&str3);
				num = num - CUST.ticket;
				fprintf(fp_new,"%d\n", num);
			}
			else
			{
				strcpy(str4, str3);
				fprintf(fp_new, "%s", str4);
			}
		}			
		
		
		system("cls");
		// REGISTRATION //
		
		char registration[] = "RegistrationNo.txt";
		char registration1[] = "newregistration.txt";
		int reg;
		FILE *REG, *REG1;
		REG = fopen(registration, "r");
		fscanf(REG, "%d", &reg);
		   reg++;
		   CUST.regno = reg;
		REG1 = fopen(registration1, "w");
		fprintf(REG1, "%d", reg);
		fclose(REG1);
		fclose(REG);
		remove(registration);
		rename(registration1, registration);
		
		// copying the movie name //
		
		rewind(fp);
		printf("\n\n\n");
		printf("Registration No : REG%d", CUST.regno);
		printf("\nname : %s", CUST.name);			
		printf("\nMovie :");
		char str1[55],str2[55];
		int counter = 0;
		while(fgets(str1, sizeof(str1), fp)!=NULL)
		{
			++counter;
			if(counter == CUST.movieNo && counter<=3)
			{
		          printf("%s", str1);
				  break;	
			}
		}
		strcpy(str2,str1);
		printf("Tickets : %d", CUST.ticket);
		
		// PARKING SLOT //
		
		FILE *PAR, *PAR1;
		int slot;
		char park[] = "PARKING.txt";
		char park1[] = "parknew.txt";		
		if (CUST.parking == 1)
		{
				PAR = fopen(park, "r");
				fscanf(PAR, "%d", &slot);
				if(slot == 500)
				{
					int take, take1;
					char string[] = "Remaining_parking_slot.txt";
					char string1[] = "Remaining.txt";
					FILE *WE = fopen(string,"r");
					if(WE == NULL)
					{
						carslot = 0;
					}
					else
					{						
						fscanf(WE,"%d", &take);
						carslot = take;
						rewind(WE);
						FILE *WE1 = fopen(string1,"w");
						char str[10];
						printf("%d", take);
						while(fgets(str, sizeof(str), WE) != NULL)
						{
							take1 = atoi(&str);
							printf("%d", take1);
							if(take1 != take)
							{
								fprintf(WE1,"%d\n", take1);
							}
						}
						fclose(WE1);
						fclose(WE);
						remove(string);
						rename(string1,string);
					}
				}
				else
				{
					slot++;
					carslot = slot;
				}
				PAR1 = fopen(park1, "w");
				fprintf(PAR1, "%d", slot);
				fclose(PAR1);
				fclose(PAR);
				remove(park);
				rename(park1, park);
		}
		printf("\nYour parking slot no is : %d", carslot);
		
		// AMOUNT CALCULATION //
		
		char read[55];
		int select = 0;
		float price;
		rewind(fp);
		while(fgets(read, sizeof(read), fp))
		{
			select++;
			if(select == CUST.movieNo+6)
			{
				price = atoi(&read);
				CUST.amount = price * CUST.ticket;
				if(CUST.parking == 1)
				{
					CUST.amount += 100;
				}
			}
		}
		printf("\nTotal Amount : %.2f", CUST.amount);
		fclose(fp_new);
		fclose(fp);
		remove(file1);
		rename(file_new, file1);
		
		// calculating revenue //
		
		char rev[] = "BollywoodRevenue.txt";
		char rev1[] = "newhollyrev.txt";
		FILE *REV, *REV1;
		float revenue;
		char extract[10], extract1[10];
		int check = 0;
		
		
		REV = fopen(rev, "r");
		if(REV == NULL)
		{exit(1);}
		
		REV1 = fopen(rev1, "w");
		if(REV1 == NULL)
		{exit(1);}
		while(fgets(extract, sizeof(extract), REV) != NULL)
		{
			check++;
			if(check==5)
			{
				revenue = atoi(&extract);
				revenue += CUST.amount;				
				fprintf(REV1,"%.2f\n", revenue);
			}
			else
			{
				strcpy(extract1, extract);
				fprintf(REV1, "%s", extract1);
			}
		}
		fclose(REV1);
		fclose(REV);
		remove(rev);
		rename(rev1, rev);
		
		FILE *fp1 = fopen("Booking_Bolly_fri_movies.txt","a+");
		if(fp1==NULL)
		{
			exit(1);
		}
		
		// PRINTING TO FILE //
		
        fprintf(fp1, "\t%-10d%-20s%-10d%-10d%-10.2f%-20s", CUST.regno, CUST.name, CUST.ticket, carslot, CUST.amount, str2);
        
		fclose(fp1);		
		
		gotoxy(15,10);
		printf("*************** THANKS FOR REGISTERATION :) ***************");		
			
}


void Book_Bolly_sat_movies()
{
   FILE *fp;
   char ch;
   fp = fopen("Book_Bolly_sat_movies.txt","r");
   if(fp==NULL)
   {
   	 exit(1);
   }
   while(!feof(fp))
   {
   	 ch = fgetc(fp);
   	 printf("%c", ch);
   }
   fclose(fp);
}

void BookInBollySat()
{
	system("cls");
		customer CUST;
		printf("\nMovie -> Tickets -> Price -> Ratings -> No.of ratings\n\n");
	    Book_Bolly_sat_movies();
		printf("\nNOTE : Booking of parking slot will cost RS 100. only one slot will be booked at per registeration\n");	
      	int wish;
      	printf("\nWould you like to get booked!!!! kindly press 1 for yes and 0 for no : ");
      	scanf("%d", &wish);
      	if(wish!=1)
      	{
      	    exit(0);	
		}
		system("cls");
        Book_Bolly_sat_movies();
		
		// details input //
		
		fflush(stdin);
		printf("\nEnter your name : ");
		gets(CUST.name);
		
		printf("Enter the no of movie you want to watch : ");
		scanf("%d", &CUST.movieNo);
		
		printf("Enter no of tickets : ");
		scanf("%d", &CUST.ticket);
		
		printf("Do you want to avail parking 1)yes OR 0)no : ");
		scanf("%d", &CUST.parking);
		
		char file1[] = "Book_Bolly_sat_movies.txt";
				
		FILE *fp = fopen(file1, "r");
		if(fp==NULL)
		{exit(1);}	
		
		
		// REWRITING THE FILE //
		
		rewind(fp);
		char file_new[] = "new.txt";
		char str3[55], str4[55];
		FILE *fp_new = fopen(file_new, "w");
		if(fp_new==NULL)
		{exit(1);}
		int line = 0, num;
		while(fgets(str3, sizeof(str3), fp) != NULL)
		{
			line++;
			if(line==CUST.movieNo+3)
			{
				num = atoi(&str3);
				if(num == 0)
				{
					printf("\n\n Sorry all tickets have been sold !!!");
					exit(1);
				}
				num = num - CUST.ticket;
				fprintf(fp_new,"%d\n", num);
			}
			else
			{
				strcpy(str4, str3);
				fprintf(fp_new, "%s", str4);
			}
		}			
		
		system("cls");
		// REGISTRATION //
		
		char registration[] = "RegistrationNo.txt";
		char registration1[] = "newregistration.txt";
		int reg;
		FILE *REG, *REG1;
		REG = fopen(registration, "r");
		fscanf(REG, "%d", &reg);
		   reg++;
		   CUST.regno = reg;
		REG1 = fopen(registration1, "w");
		fprintf(REG1, "%d", reg);
		fclose(REG1);
		fclose(REG);
		remove(registration);
		rename(registration1, registration);
		
		// copying the movie name //
		rewind(fp);
		printf("\n\n\n");
		printf("Registration No : REG%d", CUST.regno);
		printf("\nname : %s", CUST.name);			
		printf("\nMovie :");
		char str1[55],str2[55];
		int counter = 0;
		while(fgets(str1, sizeof(str1), fp)!=NULL)
		{
			++counter;
			if(counter == CUST.movieNo && counter<=3)
			{
		          printf("%s", str1);
				  break;	
			}
		}
		strcpy(str2,str1);
		printf("Tickets : %d", CUST.ticket);
		
		// PARKING SLOT //
		
		FILE *PAR, *PAR1;
		int slot;
		char park[] = "PARKING.txt";
		char park1[] = "parknew.txt";		
		if (CUST.parking == 1)
		{
				PAR = fopen(park, "r");
				fscanf(PAR, "%d", &slot);
				if(slot == 500)
				{
					int take, take1;
					char string[] = "Remaining_parking_slot.txt";
					char string1[] = "Remaining.txt";
					FILE *WE = fopen(string,"r");
					if(WE == NULL)
					{
						carslot = 0;
					}
					else
					{						
						fscanf(WE,"%d", &take);
						carslot = take;
						rewind(WE);
						FILE *WE1 = fopen(string1,"w");
						char str[10];
						printf("%d", take);
						while(fgets(str, sizeof(str), WE) != NULL)
						{
							take1 = atoi(&str);
							printf("%d", take1);
							if(take1 != take)
							{
								fprintf(WE1,"%d\n", take1);
							}
						}
						fclose(WE1);
						fclose(WE);
						remove(string);
						rename(string1,string);
					}
				}
				else
				{
					slot++;
					carslot = slot;
				}
				PAR1 = fopen(park1, "w");
				fprintf(PAR1, "%d", slot);
				fclose(PAR1);
				fclose(PAR);
				remove(park);
				rename(park1, park);
		}
		printf("\nYour parking slot no is : %d", carslot);
		
		// AMOUNT CALCULATION //
		
		char read[55];
		int select = 0;
		float price;
		rewind(fp);
		while(fgets(read, sizeof(read), fp))
		{
			select++;
			if(select == CUST.movieNo+6)
			{
				price = atoi(&read);
				CUST.amount = price * CUST.ticket;
				if(CUST.parking == 1)
				{
					CUST.amount += 100;
				}
			}
		}
		printf("\nTotal Amount : %.2f", CUST.amount);
		fclose(fp_new);
		fclose(fp);
		remove(file1);
		rename(file_new, file1);
		
		// calculating revenue //
		
		char rev[] = "BollywoodRevenue.txt";
		char rev1[] = "newhollyrev.txt";
		FILE *REV, *REV1;
		float revenue;
		char extract[10], extract1[10];
		int check = 0;
		
		
		REV = fopen(rev, "r");
		if(REV == NULL)
		{exit(1);}
		
		REV1 = fopen(rev1, "w");
		if(REV1 == NULL)
		{exit(1);}
		while(fgets(extract, sizeof(extract), REV) != NULL)
		{
			check++;
			if(check==6)
			{
				revenue = atoi(&extract);
				revenue += CUST.amount;				
				fprintf(REV1,"%.2f\n", revenue);
			}
			else
			{
				strcpy(extract1, extract);
				fprintf(REV1, "%s", extract1);
			}
		}
		fclose(REV1);
		fclose(REV);
		remove(rev);
		rename(rev1, rev);
		
		FILE *fp1 = fopen("Booking_Bolly_sat_movies.txt","a+");
		if(fp1==NULL)
		{
			exit(1);
		}
		
		// PRINTING TO FILE //
		
        fprintf(fp1, "\t%-10d%-20s%-10d%-10d%-10.2f%-20s", CUST.regno, CUST.name, CUST.ticket, carslot, CUST.amount, str2);
        
		fclose(fp1);		
		
		gotoxy(15,10);
		printf("*************** THANKS FOR REGISTERATION :) ***************");		
			
}


void Book_Bolly_sun_movies()
{
   FILE *fp;
   char ch;
   fp = fopen("Book_Bolly_sun_movies.txt","r");
   if(fp==NULL)
   {
   	 exit(1);
   }
   while(!feof(fp))
   {
   	 ch = fgetc(fp);
   	 printf("%c", ch);
   }
   fclose(fp);
}

void BookInBollySun()
{
	system("cls");
		customer CUST;
		printf("\nMovie -> Tickets -> Price -> Ratings -> No.of ratings\n\n");
	    Book_Bolly_sun_movies();
		printf("\nNOTE : Booking of parking slot will cost RS 100. only one slot will be booked at per registeration\n");	
      	int wish;
      	printf("\nWould you like to get booked!!!! kindly press 1 for yes and 0 for no : ");
      	scanf("%d", &wish);
      	if(wish!=1)
      	{
      	    exit(0);	
		}
		system("cls");
        Book_Bolly_sun_movies();
		
		// details input //
		
		fflush(stdin);
		printf("\nEnter your name : ");
		gets(CUST.name);
		
		printf("Enter the no of movie you want to watch : ");
		scanf("%d", &CUST.movieNo);
		
		printf("Enter no of tickets : ");
		scanf("%d", &CUST.ticket);
		
		printf("Do you want to avail parking 1)yes OR 0)no : ");
		scanf("%d", &CUST.parking);
		
		
		char file1[] = "Book_Bolly_sun_movies.txt";
				
		FILE *fp = fopen(file1, "r");
		if(fp==NULL)
		{exit(1);}		
		
		// REWRITING THE FILE //
		
		rewind(fp);
		char file_new[] = "new.txt";
		char str3[55], str4[55];
		FILE *fp_new = fopen(file_new, "w");
		if(fp_new==NULL)
		{exit(1);}
		int line = 0, num;
		while(fgets(str3, sizeof(str3), fp) != NULL)
		{
			line++;
			if(line==CUST.movieNo+3)
			{
				num = atoi(&str3);
				if(num == 0)
				{
					printf("\n\n Sorry All tickets have been sold !!!");
					exit(1);
				}
				num = num - CUST.ticket;
				fprintf(fp_new,"%d\n", num);
			}
			else
			{
				strcpy(str4, str3);
				fprintf(fp_new, "%s", str4);
			}
		}		
		
		system("cls");
		// REGISTRATION //
		
		char registration[] = "RegistrationNo.txt";
		char registration1[] = "newregistration.txt";
		int reg;
		FILE *REG, *REG1;
		REG = fopen(registration, "r");
		fscanf(REG, "%d", &reg);
		   reg++;
		   CUST.regno = reg;
		REG1 = fopen(registration1, "w");
		fprintf(REG1, "%d", reg);
		fclose(REG1);
		fclose(REG);
		remove(registration);
		rename(registration1, registration);
		
		// copying the movie name //

		rewind(fp);
		printf("\n\n\n");
		printf("Registration No : REG%d", CUST.regno);
		printf("\nname : %s", CUST.name);			
		printf("\nMovie :");
		char str1[55],str2[55];
		int counter = 0;
		while(fgets(str1, sizeof(str1), fp)!=NULL)
		{
			++counter;
			if(counter == CUST.movieNo && counter<=3)
			{
		          printf("%s", str1);
				  break;	
			}
		}
		strcpy(str2,str1);
		printf("Tickets : %d", CUST.ticket);
		
		// PARKING SLOT //
		
		FILE *PAR, *PAR1;
		int slot;
		char park[] = "PARKING.txt";
		char park1[] = "parknew.txt";		
		if (CUST.parking == 1)
		{
				PAR = fopen(park, "r");
				fscanf(PAR, "%d", &slot);
				if(slot == 500)
				{
					int take, take1;
					char string[] = "Remaining_parking_slot.txt";
					char string1[] = "Remaining.txt";
					FILE *WE = fopen(string,"r");
					if(WE == NULL)
					{
						carslot = 0;
					}
					else
					{						
						fscanf(WE,"%d", &take);
						carslot = take;
						rewind(WE);
						FILE *WE1 = fopen(string1,"w");
						char str[10];
						printf("%d", take);
						while(fgets(str, sizeof(str), WE) != NULL)
						{
							take1 = atoi(&str);
							printf("%d", take1);
							if(take1 != take)
							{
								fprintf(WE1,"%d\n", take1);
							}
						}
						fclose(WE1);
						fclose(WE);
						remove(string);
						rename(string1,string);
					}
				}
				else
				{
					slot++;
					carslot = slot;
				}
				PAR1 = fopen(park1, "w");
				fprintf(PAR1, "%d", slot);
				fclose(PAR1);
				fclose(PAR);
				remove(park);
				rename(park1, park);
		}
		printf("\nYour parking slot no is : %d", carslot);
		
		// AMOUNT CALCULATION //
		
		char read[55];
		int select = 0;
		float price;
		rewind(fp);
		while(fgets(read, sizeof(read), fp))
		{
			select++;
			if(select == CUST.movieNo+6)
			{
				price = atoi(&read);
				CUST.amount = price * CUST.ticket;
				if(CUST.parking == 1)
				{
					CUST.amount += 100;
				}
			}
		}
		printf("\nTotal Amount : %.2f", CUST.amount);
		
		fclose(fp_new);
		fclose(fp);
		remove(file1);
		rename(file_new, file1);
		
		// calculating revenue //
		
		char rev[] = "BollywoodRevenue.txt";
		char rev1[] = "newhollyrev.txt";
		FILE *REV, *REV1;
		float revenue;
		char extract[10], extract1[10];
		int check = 0;
		
		
		REV = fopen(rev, "r");
		if(REV == NULL)
		{exit(1);}
		
		REV1 = fopen(rev1, "w");
		if(REV1 == NULL)
		{exit(1);}
		while(fgets(extract, sizeof(extract), REV) != NULL)
		{
			check++;
			if(check==7)
			{
				revenue = atoi(&extract);
				revenue += CUST.amount;				
				fprintf(REV1,"%.2f\n", revenue);
			}
			else
			{
				strcpy(extract1, extract);
				fprintf(REV1, "%s", extract1);
			}
		}
		fclose(REV1);
		fclose(REV);
		remove(rev);
		rename(rev1, rev);
		
		FILE *fp1 = fopen("Booking_Bolly_sun_movies.txt","a+");
		if(fp1==NULL)
		{
			exit(1);
		}
		
		// PRINTING TO FILE //
		
        fprintf(fp1, "\t%-10d%-20s%-10d%-10d%-10.2f%-20s", CUST.regno, CUST.name, CUST.ticket, carslot, CUST.amount, str2);
        
		fclose(fp1);		
		
		gotoxy(15,10);
		printf("*************** THANKS FOR REGISTERATION :) ***************");		
			
}

void Services()
{
	system("cls");
	printf("Welcome to Services");
	
	void (*ptr[3])() = {Checking, Delete, Rating}; // CheckBollywood};
	printf("\nWhat you want to do \n1)Check booking \n2)Cancel Booking \n3)Rate a Movie");
	
	int book;
	printf("\nEnter your selection : ");
	scanf("%d", &book);
	
	(*ptr[book-1])();	
}

void Checking()
{
	system("cls");
	printf("You entered in checking");
	printf("\nSelect your category \n1)Hollywood \n2)Bollywood");
	
	int select;
	printf("\nEnter your selection : ");
	scanf("%d", &select);
	
	
	switch(select)
	{
		case 1:
			{
				system("cls");
				printf("You entered in hollywood");
				printf("\nmake your slection \n1)Monday \n2)Tuesday \n3)Wednesday \n4)Thursday \n5)Friday \n6)Saturday \n7)Sunday");
				
				int make;
				printf("\nenter your selection : ");
				scanf("%d", &make);
				
				switch(make)
				{
					case 1:
						{
							int REG;
							printf("Enter your registeration no : ");
							scanf("%d", &REG);
							int registration, num1, num2;
							float amount;
							char name[25], movie[35], str1[110], str2[110];
							FILE *fp;

   							fp = fopen("Booking_Holly_mon_movies.txt","r");
   							if(fp==NULL)
   							{
   	 							exit(1);
   							}
   							int line = 1;
   							while(fgets(str1, sizeof(str1), fp)!=NULL)
   							{
   								++line;
   								fscanf(fp, "%10d%20s%10d%10d%10.2f%20s", &registration, name, &num1, &num2, &amount, movie);
   								if(registration == REG)
   								{
   									break;
								}
   							}
   							rewind(fp);
   							int check = 0;
   							printf("------------------------------------------------------------------------------------------------------------------\n");
   							printf("      REG NO	     NAME	   TICKETS    PARKING	  AMOUNT		MOVIE\n");
   							printf("------------------------------------------------------------------------------------------------------------------");
   							while(fgets(str2, sizeof(str2), fp) != NULL)
   							{
   								check++;
   								if(check == line)
   								{
   								printf("\n%s", str2);	
								}
							}	
							fclose(fp);
							break;
						}
					case 2:
						{
							int REG;
							printf("Enter your registeration no : ");
							scanf("%d", &REG);
							int registration, num1, num2;
							float amount;
							char name[25], movie[35], str1[110], str2[110];
							FILE *fp;

   							fp = fopen("Booking_Holly_tue_movies.txt","r");
   							if(fp==NULL)
   							{
   	 							exit(1);
   							}
   							int line = 1;
   							while(fgets(str1, sizeof(str1), fp)!=NULL)
   							{
   								++line;
   								fscanf(fp, "%10d%20s%10d%10d%10.2f%20s", &registration, name, &num1, &num2, &amount, movie);
   								if(registration == REG)
   								{
   									break;
								}
   							}
   							rewind(fp);
   							int check = 0;
   							printf("------------------------------------------------------------------------------------------------------------------\n");
   							printf("      REG NO	     NAME	   TICKETS    PARKING	  AMOUNT		MOVIE\n");
   							printf("------------------------------------------------------------------------------------------------------------------");
   							while(fgets(str2, sizeof(str2), fp) != NULL)
   							{
   								check++;
   								if(check == line)
   								{
   								printf("\n%s", str2);	
								}
							}	
							fclose(fp);
							break;						
						}
					case 3:
					    {
							int REG;
							printf("Enter your registeration no : ");
							scanf("%d", &REG);
							int registration, num1, num2;
							float amount;
							char name[25], movie[35], str1[110], str2[110];
							FILE *fp;

   							fp = fopen("Booking_Holly_wed_movies.txt","r");
   							if(fp==NULL)
   							{
   	 							exit(1);
   							}
   							int line = 1;
   							while(fgets(str1, sizeof(str1), fp)!=NULL)
   							{
   								++line;
   								fscanf(fp, "%10d%20s%10d%10d%10.2f%20s", &registration, name, &num1, &num2, &amount, movie);
   								if(registration == REG)
   								{
   									break;
								}
   							}
   							rewind(fp);
   							int check = 0;
   							printf("------------------------------------------------------------------------------------------------------------------\n");
   							printf("      REG NO	     NAME	   TICKETS    PARKING	  AMOUNT		MOVIE\n");
   							printf("------------------------------------------------------------------------------------------------------------------");
   							while(fgets(str2, sizeof(str2), fp) != NULL)
   							{
   								check++;
   								if(check == line)
   								{
   								printf("\n%s", str2);	
								}
							}	
							fclose(fp);
							break;					    	
						}
					case 4:
						{
							int REG;
							printf("Enter your registeration no : ");
							scanf("%d", &REG);
							int registration, num1, num2;
							float amount;
							char name[25], movie[35], str1[110], str2[110];
							FILE *fp;

   							fp = fopen("Booking_Holly_thu_movies.txt","r");
   							if(fp==NULL)
   							{
   	 							exit(1);
   							}
   							int line = 1;
   							while(fgets(str1, sizeof(str1), fp)!=NULL)
   							{
   								++line;
   								fscanf(fp, "%10d%20s%10d%10d%10.2f%20s", &registration, name, &num1, &num2, &amount, movie);
   								if(registration == REG)
   								{
   									break;
								}
   							}
   							rewind(fp);
   							int check = 0;
   							printf("------------------------------------------------------------------------------------------------------------------\n");
   							printf("      REG NO	     NAME	   TICKETS    PARKING	  AMOUNT		MOVIE\n");
   							printf("------------------------------------------------------------------------------------------------------------------");
   							while(fgets(str2, sizeof(str2), fp) != NULL)
   							{
   								check++;
   								if(check == line)
   								{
   								printf("\n%s", str2);	
								}
							}	
							fclose(fp);
							break;							
						}
					case 5:
						{
							int REG;
							printf("Enter your registeration no : ");
							scanf("%d", &REG);
							int registration, num1, num2;
							float amount;
							char name[25], movie[35], str1[110], str2[110];
							FILE *fp;

   							fp = fopen("Booking_Holly_fri_movies.txt","r");
   							if(fp==NULL)
   							{
   	 							exit(1);
   							}
   							int line = 1;
   							while(fgets(str1, sizeof(str1), fp)!=NULL)
   							{
   								++line;
   								fscanf(fp, "%10d%20s%10d%10d%10.2f%20s", &registration, name, &num1, &num2, &amount, movie);
   								if(registration == REG)
   								{
   									break;
								}
   							}
   							rewind(fp);
   							int check = 0;
   							printf("------------------------------------------------------------------------------------------------------------------\n");
   							printf("      REG NO	     NAME	   TICKETS    PARKING	  AMOUNT		MOVIE\n");
   							printf("------------------------------------------------------------------------------------------------------------------");
   							while(fgets(str2, sizeof(str2), fp) != NULL)
   							{
   								check++;
   								if(check == line)
   								{
   								printf("\n%s", str2);	
								}
							}	
							fclose(fp);
							break;							
						}
					case 6:
						{
							int REG;
							printf("Enter your registeration no : ");
							scanf("%d", &REG);
							int registration, num1, num2;
							float amount;
							char name[25], movie[35], str1[110], str2[110];
							FILE *fp;

   							fp = fopen("Booking_Holly_sat_movies.txt","r");
   							if(fp==NULL)
   							{
   	 							exit(1);
   							}
   							int line = 1;
   							while(fgets(str1, sizeof(str1), fp)!=NULL)
   							{
   								++line;
   								fscanf(fp, "%10d%20s%10d%10d%10.2f%20s", &registration, name, &num1, &num2, &amount, movie);
   								if(registration == REG)
   								{
   									break;
								}
   							}
   							rewind(fp);
   							int check = 0;
   							printf("------------------------------------------------------------------------------------------------------------------\n");
   							printf("      REG NO	     NAME	   TICKETS    PARKING	  AMOUNT		MOVIE\n");
   							printf("------------------------------------------------------------------------------------------------------------------");
   							while(fgets(str2, sizeof(str2), fp) != NULL)
   							{
   								check++;
   								if(check == line)
   								{
   								printf("\n%s", str2);	
								}
							}	
							fclose(fp);
							break;							
						}
					case 7:
						{
							int REG;
							printf("Enter your registeration no : ");
							scanf("%d", &REG);
							int registration, num1, num2;
							float amount;
							char name[25], movie[35], str1[110], str2[110];
							FILE *fp;

   							fp = fopen("Booking_Holly_sun_movies.txt","r");
   							if(fp==NULL)
   							{
   	 							exit(1);
   							}
   							int line = 1;
   							while(fgets(str1, sizeof(str1), fp)!=NULL)
   							{
   								++line;
   								fscanf(fp, "%10d%20s%10d%10d%10.2f%20s", &registration, name, &num1, &num2, &amount, movie);
   								if(registration == REG)
   								{
   									break;
								}
   							}
   							rewind(fp);
   							int check = 0;
   							printf("------------------------------------------------------------------------------------------------------------------\n");
   							printf("      REG NO	     NAME	   TICKETS    PARKING	  AMOUNT		MOVIE\n");
   							printf("------------------------------------------------------------------------------------------------------------------");
   							while(fgets(str2, sizeof(str2), fp) != NULL)
   							{
   								check++;
   								if(check == line)
   								{
   								printf("\n%s", str2);	
								}
							}	
							fclose(fp);
							break;							
						}
					default:
						{
							printf("Error 404! selection not found");
							break;
						}							
				}
			   break;	
			}
		case 2:
			{
				system("cls");
				printf("You entered in bollywood");
				printf("\nmake your slection \n1)Monday \n2)Tuesday \n3)Wednesday \n4)Thursday \n5)Friday \n6)Saturday \n7)Sunday");
				
				int make;
				printf("\nenter your selection : ");
				scanf("%d", &make);
				
				switch(make)
				{
					case 1:
						{
							int REG;
							printf("Enter your registeration no : ");
							scanf("%d", &REG);
							int registration, num1, num2;
							float amount;
							char name[25], movie[35], str1[110], str2[110];
							FILE *fp;

   							fp = fopen("Booking_Bolly_mon_movies.txt","r");
   							if(fp==NULL)
   							{
   	 							exit(1);
   							}
   							int line = 1;
   							while(fgets(str1, sizeof(str1), fp)!=NULL)
   							{
   								++line;
   								fscanf(fp, "%10d%20s%10d%10d%10.2f%20s", &registration, name, &num1, &num2, &amount, movie);
   								if(registration == REG)
   								{
   									break;
								}
   							}
   							rewind(fp);
   							int check = 0;
   							printf("------------------------------------------------------------------------------------------------------------------\n");
   							printf("      REG NO	     NAME	   TICKETS    PARKING	  AMOUNT		MOVIE\n");
   							printf("------------------------------------------------------------------------------------------------------------------");
   							while(fgets(str2, sizeof(str2), fp) != NULL)
   							{
   								check++;
   								if(check == line)
   								{
   								printf("\n%s", str2);	
								}
							}	
							fclose(fp);
							break;
						}
					case 2:
						{
							int REG;
							printf("Enter your registeration no : ");
							scanf("%d", &REG);
							int registration, num1, num2;
							float amount;
							char name[25], movie[35], str1[110], str2[110];
							FILE *fp;

   							fp = fopen("Booking_Bolly_tue_movies.txt","r");
   							if(fp==NULL)
   							{
   	 							exit(1);
   							}
   							int line = 1;
   							while(fgets(str1, sizeof(str1), fp)!=NULL)
   							{
   								++line;
   								fscanf(fp, "%10d%20s%10d%10d%10.2f%20s", &registration, name, &num1, &num2, &amount, movie);
   								if(registration == REG)
   								{
   									break;
								}
   							}
   							rewind(fp);
   							int check = 0;
   							printf("------------------------------------------------------------------------------------------------------------------\n");
   							printf("      REG NO	     NAME	   TICKETS    PARKING	  AMOUNT		MOVIE\n");
   							printf("------------------------------------------------------------------------------------------------------------------");
   							while(fgets(str2, sizeof(str2), fp) != NULL)
   							{
   								check++;
   								if(check == line)
   								{
   								printf("\n%s", str2);	
								}
							}	
							fclose(fp);
							break;						
						}
					case 3:
					    {
							int REG;
							printf("Enter your registeration no : ");
							scanf("%d", &REG);
							int registration, num1, num2;
							float amount;
							char name[25], movie[35], str1[110], str2[110];
							FILE *fp;

   							fp = fopen("Booking_Bolly_wed_movies.txt","r");
   							if(fp==NULL)
   							{
   	 							exit(1);
   							}
   							int line = 1;
   							while(fgets(str1, sizeof(str1), fp)!=NULL)
   							{
   								++line;
   								fscanf(fp, "%10d%20s%10d%10d%10.2f%20s", &registration, name, &num1, &num2, &amount, movie);
   								if(registration == REG)
   								{
   									break;
								}
   							}
   							rewind(fp);
   							int check = 0;
   							printf("------------------------------------------------------------------------------------------------------------------\n");
   							printf("      REG NO	     NAME	   TICKETS    PARKING	  AMOUNT		MOVIE\n");
   							printf("------------------------------------------------------------------------------------------------------------------");
   							while(fgets(str2, sizeof(str2), fp) != NULL)
   							{
   								check++;
   								if(check == line)
   								{
   								printf("\n%s", str2);	
								}
							}	
							fclose(fp);
							break;					    	
						}
					case 4:
						{
							int REG;
							printf("Enter your registeration no : ");
							scanf("%d", &REG);
							int registration, num1, num2;
							float amount;
							char name[25], movie[35], str1[110], str2[110];
							FILE *fp;

   							fp = fopen("Booking_Bolly_thu_movies.txt","r");
   							if(fp==NULL)
   							{
   	 							exit(1);
   							}
   							int line = 1;
   							while(fgets(str1, sizeof(str1), fp)!=NULL)
   							{
   								++line;
   								fscanf(fp, "%10d%20s%10d%10d%10.2f%20s", &registration, name, &num1, &num2, &amount, movie);
   								if(registration == REG)
   								{
   									break;
								}
   							}
   							rewind(fp);
   							int check = 0;
   							printf("------------------------------------------------------------------------------------------------------------------\n");
   							printf("      REG NO	     NAME	   TICKETS    PARKING	  AMOUNT		MOVIE\n");
   							printf("------------------------------------------------------------------------------------------------------------------");
   							while(fgets(str2, sizeof(str2), fp) != NULL)
   							{
   								check++;
   								if(check == line)
   								{
   								printf("\n%s", str2);	
								}
							}	
							fclose(fp);
							break;							
						}
					case 5:
						{
							int REG;
							printf("Enter your registeration no : ");
							scanf("%d", &REG);
							int registration, num1, num2;
							float amount;
							char name[25], movie[35], str1[110], str2[110];
							FILE *fp;

   							fp = fopen("Booking_Bolly_fri_movies.txt","r");
   							if(fp==NULL)
   							{
   	 							exit(1);
   							}
   							int line = 1;
   							while(fgets(str1, sizeof(str1), fp)!=NULL)
   							{
   								++line;
   								fscanf(fp, "%10d%20s%10d%10d%10.2f%20s", &registration, name, &num1, &num2, &amount, movie);
   								if(registration == REG)
   								{
   									break;
								}
   							}
   							rewind(fp);
   							int check = 0;
   							printf("------------------------------------------------------------------------------------------------------------------\n");
   							printf("      REG NO	     NAME	   TICKETS    PARKING	  AMOUNT		MOVIE\n");
   							printf("------------------------------------------------------------------------------------------------------------------");
   							while(fgets(str2, sizeof(str2), fp) != NULL)
   							{
   								check++;
   								if(check == line)
   								{
   								printf("\n%s", str2);	
								}
							}	
							fclose(fp);
							break;							
						}
					case 6:
						{
							int REG;
							printf("Enter your registeration no : ");
							scanf("%d", &REG);
							int registration, num1, num2;
							float amount;
							char name[25], movie[35], str1[110], str2[110];
							FILE *fp;

   							fp = fopen("Booking_Bolly_sat_movies.txt","r");
   							if(fp==NULL)
   							{
   	 							exit(1);
   							}
   							int line = 1;
   							while(fgets(str1, sizeof(str1), fp)!=NULL)
   							{
   								++line;
   								fscanf(fp, "%10d%20s%10d%10d%10.2f%20s", &registration, name, &num1, &num2, &amount, movie);
   								if(registration == REG)
   								{
   									break;
								}
   							}
   							rewind(fp);
   							int check = 0;
   							printf("------------------------------------------------------------------------------------------------------------------\n");
   							printf("      REG NO	     NAME	   TICKETS    PARKING	  AMOUNT		MOVIE\n");
   							printf("------------------------------------------------------------------------------------------------------------------");
   							while(fgets(str2, sizeof(str2), fp) != NULL)
   							{
   								check++;
   								if(check == line)
   								{
   								printf("\n%s", str2);	
								}
							}	
							fclose(fp);
							break;							
						}
					case 7:
						{
							int REG;
							printf("Enter your registeration no : ");
							scanf("%d", &REG);
							int registration, num1, num2;
							float amount;
							char name[25], movie[35], str1[110], str2[110];
							FILE *fp;

   							fp = fopen("Booking_Bolly_sun_movies.txt","r");
   							if(fp==NULL)
   							{
   	 							exit(1);
   							}
   							int line = 1;
   							while(fgets(str1, sizeof(str1), fp)!=NULL)
   							{
   								++line;
   								fscanf(fp, "%10d%20s%10d%10d%10.2f%20s", &registration, name, &num1, &num2, &amount, movie);
   								if(registration == REG)
   								{
   									break;
								}
   							}
   							rewind(fp);
   							int check = 0;
   							printf("------------------------------------------------------------------------------------------------------------------\n");
   							printf("      REG NO	     NAME	   TICKETS    PARKING	  AMOUNT		MOVIE\n");
   							printf("------------------------------------------------------------------------------------------------------------------");
   							while(fgets(str2, sizeof(str2), fp) != NULL)
   							{
   								check++;
   								if(check == line)
   								{
   								printf("\n%s", str2);	
								}
							}	
							fclose(fp);
							break;							
						}
					default:
						{
							printf("Error 404! selection not found");
							break;
						}							
				}
			   break;	
			}			
	}
}


void Delete()
{
	system("cls");
	printf("You entered in Deleting");
	printf("\nSelect your category \n1)Hollywood \n2)Bollywood");
	
	int select;
	printf("\nEnter your selection : ");
	scanf("%d", &select);
	
	switch(select)
	{
		case 1:
			{
				system("cls");
				printf("You entered in hollywood");
				printf("\nmake your slection \n1)Monday \n2)Tuesday \n3)Wednesday \n4)Thursday \n5)Friday \n6)Saturday \n7)Sunday");
				
				int make;
				printf("\nenter your selection : ");
				scanf("%d", &make);
				
				switch(make)
				{
					case 1:
						{
							int REG;
							printf("Enter your registeration no : ");
							scanf("%d", &REG);
							int registration, num1, num2;
							float amount;
							char name[25], movie[35], str1[110], str2[110];
							FILE *fp;

							char temp[] = "Booking_Holly_mon_movies.txt";

   							fp = fopen(temp,"r");
   							if(fp==NULL)
   							{
   	 							exit(1);
   							}
   							int line = 1;
   							while(fgets(str1, sizeof(str1), fp)!=NULL)
   							{
   								++line;
   								fscanf(fp, "%10d%20s%10d%10d%10f%s", &registration, name, &num1, &num2, &amount, movie);
   								if(registration == REG)
   								{
   									break;
								}
   							}
   							rewind(fp);
   							int check = 0;
   							printf("------------------------------------------------------------------------------------------------------------------\n");
   							printf("      REG NO	     NAME	   TICKETS    PARKING	  AMOUNT		MOVIE\n");
   							printf("------------------------------------------------------------------------------------------------------------------");
   							while(fgets(str2, sizeof(str2), fp) != NULL)
   							{
   								check++;
   								if(check == line)
   								{
   								printf("\n%s", str2);	
								}
							}
							
							int wish;
							printf("\ndo you wish to continue ? 1)yes 0) no : ");
							scanf("%d", &wish);
							if(wish != 1)
							{
								exit(1);
							}							
							
							rewind(fp);
							
							char temp1[] = "new.txt";
							char str3[110], str4[110];
							FILE *fp1 = fopen(temp1, "w");
							if(fp1 == NULL)
							{
								printf("error");
							}
							int line1 = 0;
							while(fgets(str3, sizeof(str3), fp) != NULL)
							{
								line1++;
								if(line1 != line)
								{
									strcpy(str4, str3);
									fprintf(fp1,"%s", str4);
								}
								else
								{
									FILE *CAL = fopen("CancelledRegistrations_Holly.txt", "a");
									fprintf(CAL,"\tMonday\t%s", str3);
									fclose(CAL);
								}
							}
							fclose(fp1);
							fclose(fp);
							remove(temp);
							rename(temp1, temp);

   							
   							char read[35];
   							int checker = 0;
   							int checker1;
   							int take;
   							char name1[] = "Book_Holly_mon_movies.txt";
   							char name2[] = "new1.txt";
   							FILE *FP1 = fopen(name1,"r");
   							FILE *FP2 = fopen(name2,"w");
   							while(!feof(FP1))
   							{
   								checker++;
   								fscanf(FP1, "%s\n", read);
   								if(checker>=1 && checker<=3 && strcmp(read,movie)==0)
   								{
									checker1 = checker;
								//	printf("%d", checker1);
									fprintf(FP2 ,"%s\n", read);	
								}
								else if(checker>=4 && checker<=6 && checker == checker1+3)
								{
	
									take = atoi(&read);
									num1 += take;
									fprintf(FP2 ,"%d\n", num1);
								}
								else
								{
									fprintf(FP2, "%s\n", read);
								}
							}
							fclose(FP2);
							fclose(FP1);
							remove(name1);
							rename(name2,name1);
							
	
							FILE *rem = fopen("Remaining_parking_slot.txt","a");
							rewind(rem);
							//fprintf(rem, "%d", num2);
							fprintf(rem,"%d\n",num2);
							fclose(rem);
							
							char revenue[] = "HollywoodRevenue.txt";
							char revenue1[] = "new2.txt";
							
							FILE *REV = fopen(revenue, "r");
							FILE *REV1 = fopen(revenue1, "w");
							
							float rev;
							int amount_checker = 0;
							char extract[10], extract1[10];
							while(fgets(extract, sizeof(extract), REV) != NULL)
							{
								amount_checker++;
								if(amount_checker==1)
								{
									rev = atoi(&extract);
									rev -= amount;				
									fprintf(REV1,"%.2f\n", rev);
								}
								else
								{
									strcpy(extract1, extract);
									fprintf(REV1, "%s", extract1);
								}
							}
							fclose(REV1);
							fclose(REV);
							remove(revenue);
							rename(revenue1, revenue);
							gotoxy(15,20);
							printf("*************** YOUR REGISTRATION HAS BEEN CANCELLED :( ***************");							
							break;							
						}
						
						
						
					case 2:
						{
							int REG;
							printf("Enter your registeration no : ");
							scanf("%d", &REG);
							int registration, num1, num2;
							float amount;
							char name[25], movie[35], str1[110], str2[110];
							FILE *fp;

							char temp[] = "Booking_Holly_tue_movies.txt";

   							fp = fopen(temp,"r");
   							if(fp==NULL)
   							{
   	 							exit(1);
   							}
   							int line = 1;
   							while(fgets(str1, sizeof(str1), fp)!=NULL)
   							{
   								++line;
   								fscanf(fp, "%10d%20s%10d%10d%10f%s", &registration, name, &num1, &num2, &amount, movie);
   								if(registration == REG)
   								{
   									break;
								}
   							}
   							rewind(fp);
   							int check = 0;
   							printf("------------------------------------------------------------------------------------------------------------------\n");
   							printf("      REG NO	     NAME	   TICKETS    PARKING	  AMOUNT		MOVIE\n");
   							printf("------------------------------------------------------------------------------------------------------------------");
   							while(fgets(str2, sizeof(str2), fp) != NULL)
   							{
   								check++;
   								if(check == line)
   								{
   								printf("\n%s", str2);	
								}
							}
							
							int wish;
							printf("\ndo you wish to continue ? 1)yes 0) no : ");
							scanf("%d", &wish);
							if(wish != 1)
							{
								exit(1);
							}							
							
							rewind(fp);
							
							char temp1[] = "new.txt";
							char str3[110], str4[110];
							FILE *fp1 = fopen(temp1, "w");
							if(fp1 == NULL)
							{
								printf("error");
							}
							int line1 = 0;
							while(fgets(str3, sizeof(str3), fp) != NULL)
							{
								line1++;
								if(line1 != line)
								{
									strcpy(str4, str3);
									fprintf(fp1,"%s", str4);
								}
								else
								{
									FILE *CAL = fopen("CancelledRegistrations_Holly.txt", "a");
									fprintf(CAL,"\tTuesday\t%s", str3);
									fclose(CAL);
								}								
							}
							fclose(fp1);
							fclose(fp);
							remove(temp);
							rename(temp1, temp);

   							
   							char read[35];
   							int checker = 0;
   							int checker1;
   							int take;
   							char name1[] = "Book_Holly_tue_movies.txt";
   							char name2[] = "new1.txt";
   							FILE *FP1 = fopen(name1,"r");
   							FILE *FP2 = fopen(name2,"w");
   							while(!feof(FP1))
   							{
   								checker++;
   								fscanf(FP1, "%s\n", read);
   								if(checker>=1 && checker<=3 && strcmp(read,movie)==0)
   								{
									checker1 = checker;
								//	printf("%d", checker1);
									fprintf(FP2 ,"%s\n", read);	
								}
								else if(checker>=4 && checker<=6 && checker == checker1+3)
								{
	
									take = atoi(&read);
									num1 += take;
									fprintf(FP2 ,"%d\n", num1);
								}
								else
								{
									fprintf(FP2, "%s\n", read);
								}
							}
							fclose(FP2);
							fclose(FP1);
							remove(name1);
							rename(name2,name1);
							
							char remain[] = "Remaining_parking_slot.txt";
	
							FILE *rem = fopen(remain,"a");
							fprintf(rem, "%d\n", num2);
							fclose(rem);
							
							char revenue[] = "HollywoodRevenue.txt";
							char revenue1[] = "new2.txt";
							
							FILE *REV = fopen(revenue, "r");
							FILE *REV1 = fopen(revenue1, "w");
							
							float rev;
							int amount_checker = 0;
							char extract[10], extract1[10];
							while(fgets(extract, sizeof(extract), REV) != NULL)
							{
								amount_checker++;
								if(amount_checker==2)
								{
									rev = atoi(&extract);
									rev -= amount;				
									fprintf(REV1,"%.2f\n", rev);
								}
								else
								{
									strcpy(extract1, extract);
									fprintf(REV1, "%s", extract1);
								}
							}
							fclose(REV1);
							fclose(REV);
							remove(revenue);
							rename(revenue1, revenue);
							gotoxy(15,20);
							printf("*************** YOUR REGISTRATION HAS BEEN CANCELLED :( ***************");							
							break;							
						}
					case 3:
						{
							int REG;
							printf("Enter your registeration no : ");
							scanf("%d", &REG);
							int registration, num1, num2;
							float amount;
							char name[25], movie[35], str1[110], str2[110];
							FILE *fp;

							char temp[] = "Booking_Holly_wed_movies.txt";

   							fp = fopen(temp,"r");
   							if(fp==NULL)
   							{
   	 							exit(1);
   							}
   							int line = 1;
   							while(fgets(str1, sizeof(str1), fp)!=NULL)
   							{
   								++line;
   								fscanf(fp, "%10d%20s%10d%10d%10f%s", &registration, name, &num1, &num2, &amount, movie);
   								if(registration == REG)
   								{
   									break;
								}
   							}
   							rewind(fp);
   							int check = 0;
   							printf("------------------------------------------------------------------------------------------------------------------\n");
   							printf("      REG NO	     NAME	   TICKETS    PARKING	  AMOUNT		MOVIE\n");
   							printf("------------------------------------------------------------------------------------------------------------------");
   							while(fgets(str2, sizeof(str2), fp) != NULL)
   							{
   								check++;
   								if(check == line)
   								{
   								printf("\n%s", str2);	
								}
							}
							
							int wish;
							printf("\ndo you wish to continue ? 1)yes 0) no : ");
							scanf("%d", &wish);
							if(wish != 1)
							{
								exit(1);
							}							
							
							rewind(fp);
							
							char temp1[] = "new.txt";
							char str3[110], str4[110];
							FILE *fp1 = fopen(temp1, "w");
							if(fp1 == NULL)
							{
								printf("error");
							}
							int line1 = 0;
							while(fgets(str3, sizeof(str3), fp) != NULL)
							{
								line1++;
								if(line1 != line)
								{
									strcpy(str4, str3);
									fprintf(fp1,"%s", str4);
								}
								else
								{
									FILE *CAL = fopen("CancelledRegistrations_Holly.txt", "a");
									fprintf(CAL,"\tWednesday\t%s", str3);
									fclose(CAL);
								}								
							}
							fclose(fp1);
							fclose(fp);
							remove(temp);
							rename(temp1, temp);

   							
   							char read[35];
   							int checker = 0;
   							int checker1;
   							int take;
   							char name1[] = "Book_Holly_wed_movies.txt";
   							char name2[] = "new1.txt";
   							FILE *FP1 = fopen(name1,"r");
   							FILE *FP2 = fopen(name2,"w");
   							while(!feof(FP1))
   							{
   								checker++;
   								fscanf(FP1, "%s\n", read);
   								if(checker>=1 && checker<=3 && strcmp(read,movie)==0)
   								{
									checker1 = checker;
								//	printf("%d", checker1);
									fprintf(FP2 ,"%s\n", read);	
								}
								else if(checker>=4 && checker<=6 && checker == checker1+3)
								{
	
									take = atoi(&read);
									num1 += take;
									fprintf(FP2 ,"%d\n", num1);
								}
								else
								{
									fprintf(FP2, "%s\n", read);
								}
							}
							fclose(FP2);
							fclose(FP1);
							remove(name1);
							rename(name2,name1);
							
							char remain[] = "Remaining_parking_slot.txt";
	
							FILE *rem = fopen(remain,"a");
							fprintf(rem, "%d\n", num2);
							fclose(rem);
							
							char revenue[] = "HollywoodRevenue.txt";
							char revenue1[] = "new2.txt";
							
							FILE *REV = fopen(revenue, "r");
							FILE *REV1 = fopen(revenue1, "w");
							
							float rev;
							int amount_checker = 0;
							char extract[10], extract1[10];
							while(fgets(extract, sizeof(extract), REV) != NULL)
							{
								amount_checker++;
								if(amount_checker==3)
								{
									rev = atoi(&extract);
									rev -= amount;				
									fprintf(REV1,"%.2f\n", rev);
								}
								else
								{
									strcpy(extract1, extract);
									fprintf(REV1, "%s", extract1);
								}
							}
							fclose(REV1);
							fclose(REV);
							remove(revenue);
							rename(revenue1, revenue);
							gotoxy(15,20);
							printf("*************** YOUR REGISTRATION HAS BEEN CANCELLED :( ***************");							
							break;							
							
						}
					
					case 4:
						{
							int REG;
							printf("Enter your registeration no : ");
							scanf("%d", &REG);
							int registration, num1, num2;
							float amount;
							char name[25], movie[35], str1[110], str2[110];
							FILE *fp;

							char temp[] = "Booking_Holly_thu_movies.txt";

   							fp = fopen(temp,"r");
   							if(fp==NULL)
   							{
   	 							exit(1);
   							}
   							int line = 1;
   							while(fgets(str1, sizeof(str1), fp)!=NULL)
   							{
   								++line;
   								fscanf(fp, "%10d%20s%10d%10d%10f%s", &registration, name, &num1, &num2, &amount, movie);
   								if(registration == REG)
   								{
   									break;
								}
   							}
   							rewind(fp);
   							int check = 0;
   							printf("------------------------------------------------------------------------------------------------------------------\n");
   							printf("      REG NO	     NAME	   TICKETS    PARKING	  AMOUNT		MOVIE\n");
   							printf("------------------------------------------------------------------------------------------------------------------");
   							while(fgets(str2, sizeof(str2), fp) != NULL)
   							{
   								check++;
   								if(check == line)
   								{
   								printf("\n%s", str2);	
								}
							}
							
							int wish;
							printf("\ndo you wish to continue ? 1)yes 0) no : ");
							scanf("%d", &wish);
							if(wish != 1)
							{
								exit(1);
							}							
							
							rewind(fp);
							
							char temp1[] = "new.txt";
							char str3[110], str4[110];
							FILE *fp1 = fopen(temp1, "w");
							if(fp1 == NULL)
							{
								printf("error");
							}
							int line1 = 0;
							while(fgets(str3, sizeof(str3), fp) != NULL)
							{
								line1++;
								if(line1 != line)
								{
									strcpy(str4, str3);
									fprintf(fp1,"%s", str4);
								}
								else
								{
									FILE *CAL = fopen("CancelledRegistrations_Holly.txt", "a");
									fprintf(CAL,"\tThursday\t%s", str3);
									fclose(CAL);
								}								
							}
							fclose(fp1);
							fclose(fp);
							remove(temp);
							rename(temp1, temp);

   							
   							char read[35];
   							int checker = 0;
   							int checker1;
   							int take;
   							char name1[] = "Book_Holly_thu_movies.txt";
   							char name2[] = "new1.txt";
   							FILE *FP1 = fopen(name1,"r");
   							FILE *FP2 = fopen(name2,"w");
   							while(!feof(FP1))
   							{
   								checker++;
   								fscanf(FP1, "%s\n", read);
   								if(checker>=1 && checker<=3 && strcmp(read,movie)==0)
   								{
									checker1 = checker;
								//	printf("%d", checker1);
									fprintf(FP2 ,"%s\n", read);	
								}
								else if(checker>=4 && checker<=6 && checker == checker1+3)
								{
	
									take = atoi(&read);
									num1 += take;
									fprintf(FP2 ,"%d\n", num1);
								}
								else
								{
									fprintf(FP2, "%s\n", read);
								}
							}
							fclose(FP2);
							fclose(FP1);
							remove(name1);
							rename(name2,name1);
							
							char remain[] = "Remaining_parking_slot.txt";
	
							FILE *rem = fopen(remain,"a");
							fprintf(rem, "%d\n", num2);
							fclose(rem);
							
							char revenue[] = "HollywoodRevenue.txt";
							char revenue1[] = "new2.txt";
							
							FILE *REV = fopen(revenue, "r");
							FILE *REV1 = fopen(revenue1, "w");
							
							float rev;
							int amount_checker = 0;
							char extract[10], extract1[10];
							while(fgets(extract, sizeof(extract), REV) != NULL)
							{
								amount_checker++;
								if(amount_checker==4)
								{
									rev = atoi(&extract);
									rev -= amount;				
									fprintf(REV1,"%.2f\n", rev);
								}
								else
								{
									strcpy(extract1, extract);
									fprintf(REV1, "%s", extract1);
								}
							}
							fclose(REV1);
							fclose(REV);
							remove(revenue);
							rename(revenue1, revenue);
							gotoxy(15,20);
							printf("*************** YOUR REGISTRATION HAS BEEN CANCELLED :( ***************");							
							break;							
						}
					case 5:
						{
							int REG;
							printf("Enter your registeration no : ");
							scanf("%d", &REG);
							int registration, num1, num2;
							float amount;
							char name[25], movie[35], str1[110], str2[110];
							FILE *fp;

							char temp[] = "Booking_Holly_fri_movies.txt";

   							fp = fopen(temp,"r");
   							if(fp==NULL)
   							{
   	 							exit(1);
   							}
   							int line = 1;
   							while(fgets(str1, sizeof(str1), fp)!=NULL)
   							{
   								++line;
   								fscanf(fp, "%10d%20s%10d%10d%10f%s", &registration, name, &num1, &num2, &amount, movie);
   								if(registration == REG)
   								{
   									break;
								}
   							}
   							rewind(fp);
   							int check = 0;
   							printf("------------------------------------------------------------------------------------------------------------------\n");
   							printf("      REG NO	     NAME	   TICKETS    PARKING	  AMOUNT		MOVIE\n");
   							printf("------------------------------------------------------------------------------------------------------------------");
   							while(fgets(str2, sizeof(str2), fp) != NULL)
   							{
   								check++;
   								if(check == line)
   								{
   								printf("\n%s", str2);	
								}
							}
							
							int wish;
							printf("\ndo you wish to continue ? 1)yes 0) no : ");
							scanf("%d", &wish);
							if(wish != 1)
							{
								exit(1);
							}							
							
							rewind(fp);
							
							char temp1[] = "new.txt";
							char str3[110], str4[110];
							FILE *fp1 = fopen(temp1, "w");
							if(fp1 == NULL)
							{
								printf("error");
							}
							int line1 = 0;
							while(fgets(str3, sizeof(str3), fp) != NULL)
							{
								line1++;
								if(line1 != line)
								{
									strcpy(str4, str3);
									fprintf(fp1,"%s", str4);
								}
								else
								{
									FILE *CAL = fopen("CancelledRegistrations_Holly.txt", "a");
									fprintf(CAL,"\tFriday\t%s", str3);
									fclose(CAL);
								}								
							}
							fclose(fp1);
							fclose(fp);
							remove(temp);
							rename(temp1, temp);

   							
   							char read[35];
   							int checker = 0;
   							int checker1;
   							int take;
   							char name1[] = "Book_Holly_fri_movies.txt";
   							char name2[] = "new1.txt";
   							FILE *FP1 = fopen(name1,"r");
   							FILE *FP2 = fopen(name2,"w");
   							while(!feof(FP1))
   							{
   								checker++;
   								fscanf(FP1, "%s\n", read);
   								if(checker>=1 && checker<=3 && strcmp(read,movie)==0)
   								{
									checker1 = checker;
								//	printf("%d", checker1);
									fprintf(FP2 ,"%s\n", read);	
								}
								else if(checker>=4 && checker<=6 && checker == checker1+3)
								{
	
									take = atoi(&read);
									num1 += take;
									fprintf(FP2 ,"%d\n", num1);
								}
								else
								{
									fprintf(FP2, "%s\n", read);
								}
							}
							fclose(FP2);
							fclose(FP1);
							remove(name1);
							rename(name2,name1);
							
							char remain[] = "Remaining_parking_slot.txt";
	
							FILE *rem = fopen(remain,"a");
							fprintf(rem, "%d\n", num2);
							fclose(rem);
							
							char revenue[] = "HollywoodRevenue.txt";
							char revenue1[] = "new2.txt";
							
							FILE *REV = fopen(revenue, "r");
							FILE *REV1 = fopen(revenue1, "w");
							
							float rev;
							int amount_checker = 0;
							char extract[10], extract1[10];
							while(fgets(extract, sizeof(extract), REV) != NULL)
							{
								amount_checker++;
								if(amount_checker==5)
								{
									rev = atoi(&extract);
									rev -= amount;				
									fprintf(REV1,"%.2f\n", rev);
								}
								else
								{
									strcpy(extract1, extract);
									fprintf(REV1, "%s", extract1);
								}
							}
							fclose(REV1);
							fclose(REV);
							remove(revenue);
							rename(revenue1, revenue);
							gotoxy(15,20);
							printf("*************** YOUR REGISTRATION HAS BEEN CANCELLED :( ***************");							
							break;							
							
						}
	
					case 6:
						{
							int REG;
							printf("Enter your registeration no : ");
							scanf("%d", &REG);
							int registration, num1, num2;
							float amount;
							char name[25], movie[35], str1[110], str2[110];
							FILE *fp;

							char temp[] = "Booking_Holly_sat_movies.txt";

   							fp = fopen(temp,"r");
   							if(fp==NULL)
   							{
   	 							exit(1);
   							}
   							int line = 1;
   							while(fgets(str1, sizeof(str1), fp)!=NULL)
   							{
   								++line;
   								fscanf(fp, "%10d%20s%10d%10d%10f%s", &registration, name, &num1, &num2, &amount, movie);
   								if(registration == REG)
   								{
   									break;
								}
   							}
   							rewind(fp);
   							int check = 0;
   							printf("------------------------------------------------------------------------------------------------------------------\n");
   							printf("      REG NO	     NAME	   TICKETS    PARKING	  AMOUNT		MOVIE\n");
   							printf("------------------------------------------------------------------------------------------------------------------");
   							while(fgets(str2, sizeof(str2), fp) != NULL)
   							{
   								check++;
   								if(check == line)
   								{
   								printf("\n%s", str2);	
								}
							}
							
							int wish;
							printf("\ndo you wish to continue ? 1)yes 0) no : ");
							scanf("%d", &wish);
							if(wish != 1)
							{
								exit(1);
							}							
							
							rewind(fp);
							
							char temp1[] = "new.txt";
							char str3[110], str4[110];
							FILE *fp1 = fopen(temp1, "w");
							if(fp1 == NULL)
							{
								printf("error");
							}
							int line1 = 0;
							while(fgets(str3, sizeof(str3), fp) != NULL)
							{
								line1++;
								if(line1 != line)
								{
									strcpy(str4, str3);
									fprintf(fp1,"%s", str4);
								}
								else
								{
									FILE *CAL = fopen("CancelledRegistrations_Holly.txt", "a");
									fprintf(CAL,"\tSaturday\t%s", str3);
									fclose(CAL);
								}								
							}
							fclose(fp1);
							fclose(fp);
							remove(temp);
							rename(temp1, temp);

   							
   							char read[35];
   							int checker = 0;
   							int checker1;
   							int take;
   							char name1[] = "Book_Holly_sat_movies.txt";
   							char name2[] = "new1.txt";
   							FILE *FP1 = fopen(name1,"r");
   							FILE *FP2 = fopen(name2,"w");
   							while(!feof(FP1))
   							{
   								checker++;
   								fscanf(FP1, "%s\n", read);
   								if(checker>=1 && checker<=3 && strcmp(read,movie)==0)
   								{
									checker1 = checker;
								//	printf("%d", checker1);
									fprintf(FP2 ,"%s\n", read);	
								}
								else if(checker>=4 && checker<=6 && checker == checker1+3)
								{
	
									take = atoi(&read);
									num1 += take;
									fprintf(FP2 ,"%d\n", num1);
								}
								else
								{
									fprintf(FP2, "%s\n", read);
								}
							}
							fclose(FP2);
							fclose(FP1);
							remove(name1);
							rename(name2,name1);
							
							char remain[] = "Remaining_parking_slot.txt";
	
							FILE *rem = fopen(remain,"a");
							fprintf(rem, "%d\n", num2);
							fclose(rem);
							
							char revenue[] = "HollywoodRevenue.txt";
							char revenue1[] = "new2.txt";
							
							FILE *REV = fopen(revenue, "r");
							FILE *REV1 = fopen(revenue1, "w");
							
							float rev;
							int amount_checker = 0;
							char extract[10], extract1[10];
							while(fgets(extract, sizeof(extract), REV) != NULL)
							{
								amount_checker++;
								if(amount_checker==6)
								{
									rev = atoi(&extract);
									rev -= amount;				
									fprintf(REV1,"%.2f\n", rev);
								}
								else
								{
									strcpy(extract1, extract);
									fprintf(REV1, "%s", extract1);
								}
							}
							fclose(REV1);
							fclose(REV);
							remove(revenue);
							rename(revenue1, revenue);
							gotoxy(15,20);
							printf("*************** YOUR REGISTRATION HAS BEEN CANCELLED :( ***************");							
							break;							
						}
					
					case 7:
						{
							int REG;
							printf("Enter your registeration no : ");
							scanf("%d", &REG);
							int registration, num1, num2;
							float amount;
							char name[25], movie[35], str1[110], str2[110];
							FILE *fp;

							char temp[] = "Booking_Holly_sun_movies.txt";

   							fp = fopen(temp,"r");
   							if(fp==NULL)
   							{
   	 							exit(1);
   							}
   							int line = 1;
   							while(fgets(str1, sizeof(str1), fp)!=NULL)
   							{
   								++line;
   								fscanf(fp, "%10d%20s%10d%10d%10f%s", &registration, name, &num1, &num2, &amount, movie);
   								if(registration == REG)
   								{
   									break;
								}
   							}
   							rewind(fp);
   							int check = 0;
   							printf("------------------------------------------------------------------------------------------------------------------\n");
   							printf("      REG NO	     NAME	   TICKETS    PARKING	  AMOUNT		MOVIE\n");
   							printf("------------------------------------------------------------------------------------------------------------------");
   							while(fgets(str2, sizeof(str2), fp) != NULL)
   							{
   								check++;
   								if(check == line)
   								{
   								printf("\n%s", str2);	
								}
							}
							
							int wish;
							printf("\ndo you wish to continue ? 1)yes 0) no : ");
							scanf("%d", &wish);
							if(wish != 1)
							{
								exit(1);
							}							
							
							rewind(fp);
							
							char temp1[] = "new.txt";
							char str3[110], str4[110];
							FILE *fp1 = fopen(temp1, "w");
							if(fp1 == NULL)
							{
								printf("error");
							}
							int line1 = 0;
							while(fgets(str3, sizeof(str3), fp) != NULL)
							{
								line1++;
								if(line1 != line)
								{
									strcpy(str4, str3);
									fprintf(fp1,"%s", str4);
								}
								else
								{
									FILE *CAL = fopen("CancelledRegistrations_Holly.txt", "a");
									fprintf(CAL,"\tSunday\t%s", str3);
									fclose(CAL);
								}								
							}
							fclose(fp1);
							fclose(fp);
							remove(temp);
							rename(temp1, temp);

   							
   							char read[35];
   							int checker = 0;
   							int checker1;
   							int take;
   							char name1[] = "Book_Holly_sun_movies.txt";
   							char name2[] = "new1.txt";
   							FILE *FP1 = fopen(name1,"r");
   							FILE *FP2 = fopen(name2,"w");
   							while(!feof(FP1))
   							{
   								checker++;
   								fscanf(FP1, "%s\n", read);
   								if(checker>=1 && checker<=3 && strcmp(read,movie)==0)
   								{
									checker1 = checker;
								//	printf("%d", checker1);
									fprintf(FP2 ,"%s\n", read);	
								}
								else if(checker>=4 && checker<=6 && checker == checker1+3)
								{
	
									take = atoi(&read);
									num1 += take;
									fprintf(FP2 ,"%d\n", num1);
								}
								else
								{
									fprintf(FP2, "%s\n", read);
								}
							}
							fclose(FP2);
							fclose(FP1);
							remove(name1);
							rename(name2,name1);
							
							char remain[] = "Remaining_parking_slot.txt";
	
							FILE *rem = fopen(remain,"a");
							fprintf(rem, "%d\n", num2);
							fclose(rem);
							
							char revenue[] = "HollywoodRevenue.txt";
							char revenue1[] = "new2.txt";
							
							FILE *REV = fopen(revenue, "r");
							FILE *REV1 = fopen(revenue1, "w");
							
							float rev;
							int amount_checker = 0;
							char extract[10], extract1[10];
							while(fgets(extract, sizeof(extract), REV) != NULL)
							{
								amount_checker++;
								if(amount_checker==7)
								{
									rev = atoi(&extract);
									rev -= amount;				
									fprintf(REV1,"%.2f\n", rev);
								}
								else
								{
									strcpy(extract1, extract);
									fprintf(REV1, "%s", extract1);
								}
							}
							fclose(REV1);
							fclose(REV);
							remove(revenue);
							rename(revenue1, revenue);
							gotoxy(15,20);
							printf("*************** YOUR REGISTRATION HAS BEEN CANCELLED :( ***************");							
							break;							
						}
					default:
						{
							printf("Error 404! selection not found");
							break;
						}
				}
			break;	
		    }
		case 2:
			{
				system("cls");
				printf("You entered in bollywood");
				printf("\nmake your slection \n1)Monday \n2)Tuesday \n3)Wednesday \n4)Thursday \n5)Friday \n6)Saturday \n7)Sunday");
				
				int make;
				printf("\nenter your selection : ");
				scanf("%d", &make);
				
				switch(make)
				{
					case 1:
						{
							int REG;
							printf("Enter your registeration no : ");
							scanf("%d", &REG);
							int registration, num1, num2;
							float amount;
							char name[25], movie[35], str1[110], str2[110];
							FILE *fp;

							char temp[] = "Booking_Bolly_mon_movies.txt";

   							fp = fopen(temp,"r");
   							if(fp==NULL)
   							{
   	 							exit(1);
   							}
   							int line = 1;
   							while(fgets(str1, sizeof(str1), fp)!=NULL)
   							{
   								++line;
   								fscanf(fp, "%10d%20s%10d%10d%10f%s", &registration, name, &num1, &num2, &amount, movie);
   								if(registration == REG)
   								{
   									break;
								}
   							}
   							rewind(fp);
   							int check = 0;
   							printf("------------------------------------------------------------------------------------------------------------------\n");
   							printf("      REG NO	     NAME	   TICKETS    PARKING	  AMOUNT		MOVIE\n");
   							printf("------------------------------------------------------------------------------------------------------------------");
   							while(fgets(str2, sizeof(str2), fp) != NULL)
   							{
   								check++;
   								if(check == line)
   								{
   								printf("\n%s", str2);	
								}
							}
							
							int wish;
							printf("\ndo you wish to continue ? 1)yes 0) no : ");
							scanf("%d", &wish);
							if(wish != 1)
							{
								exit(1);
							}							
							
							rewind(fp);
							
							char temp1[] = "new.txt";
							char str3[110], str4[110];
							FILE *fp1 = fopen(temp1, "w");
							if(fp1 == NULL)
							{
								printf("error");
							}
							int line1 = 0;
							while(fgets(str3, sizeof(str3), fp) != NULL)
							{
								line1++;
								if(line1 != line)
								{
									strcpy(str4, str3);
									fprintf(fp1,"%s", str4);
								}
								else
								{
									FILE *CAL = fopen("CancelledRegistrations_Bolly.txt", "a");
									fprintf(CAL,"\tMonday\t%s", str3);
									fclose(CAL);
								}								
							}
							fclose(fp1);
							fclose(fp);
							remove(temp);
							rename(temp1, temp);

   							
   							char read[35];
   							int checker = 0;
   							int checker1;
   							int take;
   							char name1[] = "Book_Bolly_mon_movies.txt";
   							char name2[] = "new1.txt";
   							FILE *FP1 = fopen(name1,"r");
   							FILE *FP2 = fopen(name2,"w");
   							while(!feof(FP1))
   							{
   								checker++;
   								fscanf(FP1, "%s\n", read);
   								if(checker>=1 && checker<=3 && strcmp(read,movie)==0)
   								{
									checker1 = checker;
								//	printf("%d", checker1);
									fprintf(FP2 ,"%s\n", read);	
								}
								else if(checker>=4 && checker<=6 && checker == checker1+3)
								{
	
									take = atoi(&read);
									num1 += take;
									fprintf(FP2 ,"%d\n", num1);
								}
								else
								{
									fprintf(FP2, "%s\n", read);
								}
							}
							fclose(FP2);
							fclose(FP1);
							remove(name1);
							rename(name2,name1);
							
							char remain[] = "Remaining_parking_slot.txt";
	
							FILE *rem = fopen(remain,"a");
							fprintf(rem, "%d\n", num2);
							fclose(rem);
							
							char revenue[] = "BollywoodRevenue.txt";
							char revenue1[] = "new2.txt";
							
							FILE *REV = fopen(revenue, "r");
							FILE *REV1 = fopen(revenue1, "w");
							
							float rev;
							int amount_checker = 0;
							char extract[10], extract1[10];
							while(fgets(extract, sizeof(extract), REV) != NULL)
							{
								amount_checker++;
								if(amount_checker==1)
								{
									rev = atoi(&extract);
									rev -= amount;				
									fprintf(REV1,"%.2f\n", rev);
								}
								else
								{
									strcpy(extract1, extract);
									fprintf(REV1, "%s", extract1);
								}
							}
							fclose(REV1);
							fclose(REV);
							remove(revenue);
							rename(revenue1, revenue);
							gotoxy(15,20);
							printf("*************** YOUR REGISTRATION HAS BEEN CANCELLED :( ***************");							
							break;							
						}
						
						
						
					case 2:
						{
							int REG;
							printf("Enter your registeration no : ");
							scanf("%d", &REG);
							int registration, num1, num2;
							float amount;
							char name[25], movie[35], str1[110], str2[110];
							FILE *fp;

							char temp[] = "Booking_Bolly_tue_movies.txt";

   							fp = fopen(temp,"r");
   							if(fp==NULL)
   							{
   	 							exit(1);
   							}
   							int line = 1;
   							while(fgets(str1, sizeof(str1), fp)!=NULL)
   							{
   								++line;
   								fscanf(fp, "%10d%20s%10d%10d%10f%s", &registration, name, &num1, &num2, &amount, movie);
   								if(registration == REG)
   								{
   									break;
								}
   							}
   							rewind(fp);
   							int check = 0;
   							printf("------------------------------------------------------------------------------------------------------------------\n");
   							printf("      REG NO	     NAME	   TICKETS    PARKING	  AMOUNT		MOVIE\n");
   							printf("------------------------------------------------------------------------------------------------------------------");
   							while(fgets(str2, sizeof(str2), fp) != NULL)
   							{
   								check++;
   								if(check == line)
   								{
   								printf("\n%s", str2);	
								}
							}
							
							int wish;
							printf("\ndo you wish to continue ? 1)yes 0) no : ");
							scanf("%d", &wish);
							if(wish != 1)
							{
								exit(1);
							}							
							
							rewind(fp);
							
							char temp1[] = "new.txt";
							char str3[110], str4[110];
							FILE *fp1 = fopen(temp1, "w");
							if(fp1 == NULL)
							{
								printf("error");
							}
							int line1 = 0;
							while(fgets(str3, sizeof(str3), fp) != NULL)
							{
								line1++;
								if(line1 != line)
								{
									strcpy(str4, str3);
									fprintf(fp1,"%s", str4);
								}
								else
								{
									FILE *CAL = fopen("CancelledRegistrations_Bolly.txt", "a");
									fprintf(CAL,"\tTuesday\t%s", str3);
									fclose(CAL);
								}								
							}
							fclose(fp1);
							fclose(fp);
							remove(temp);
							rename(temp1, temp);

   							
   							char read[35];
   							int checker = 0;
   							int checker1;
   							int take;
   							char name1[] = "Book_Bolly_tue_movies.txt";
   							char name2[] = "new1.txt";
   							FILE *FP1 = fopen(name1,"r");
   							FILE *FP2 = fopen(name2,"w");
   							while(!feof(FP1))
   							{
   								checker++;
   								fscanf(FP1, "%s\n", read);
   								if(checker>=1 && checker<=3 && strcmp(read,movie)==0)
   								{
									checker1 = checker;
								//	printf("%d", checker1);
									fprintf(FP2 ,"%s\n", read);	
								}
								else if(checker>=4 && checker<=6 && checker == checker1+3)
								{
	
									take = atoi(&read);
									num1 += take;
									fprintf(FP2 ,"%d\n", num1);
								}
								else
								{
									fprintf(FP2, "%s\n", read);
								}
							}
							fclose(FP2);
							fclose(FP1);
							remove(name1);
							rename(name2,name1);
							
							char remain[] = "Remaining_parking_slot.txt";
	
							FILE *rem = fopen(remain,"a");
							fprintf(rem, "%d\n", num2);
							fclose(rem);
							
							char revenue[] = "BollywoodRevenue.txt";
							char revenue1[] = "new2.txt";
							
							FILE *REV = fopen(revenue, "r");
							FILE *REV1 = fopen(revenue1, "w");
							
							float rev;
							int amount_checker = 0;
							char extract[10], extract1[10];
							while(fgets(extract, sizeof(extract), REV) != NULL)
							{
								amount_checker++;
								if(amount_checker==2)
								{
									rev = atoi(&extract);
									rev -= amount;				
									fprintf(REV1,"%.2f\n", rev);
								}
								else
								{
									strcpy(extract1, extract);
									fprintf(REV1, "%s", extract1);
								}
							}
							fclose(REV1);
							fclose(REV);
							remove(revenue);
							rename(revenue1, revenue);
							gotoxy(15,20);
							printf("*************** YOUR REGISTRATION HAS BEEN CANCELLED :( ***************");							
							break;							
						}
					case 3:
						{
							int REG;
							printf("Enter your registeration no : ");
							scanf("%d", &REG);
							int registration, num1, num2;
							float amount;
							char name[25], movie[35], str1[110], str2[110];
							FILE *fp;

							char temp[] = "Booking_Bolly_wed_movies.txt";

   							fp = fopen(temp,"r");
   							if(fp==NULL)
   							{
   	 							exit(1);
   							}
   							int line = 1;
   							while(fgets(str1, sizeof(str1), fp)!=NULL)
   							{
   								++line;
   								fscanf(fp, "%10d%20s%10d%10d%10f%s", &registration, name, &num1, &num2, &amount, movie);
   								if(registration == REG)
   								{
   									break;
								}
   							}
   							rewind(fp);
   							int check = 0;
   							printf("------------------------------------------------------------------------------------------------------------------\n");
   							printf("      REG NO	     NAME	   TICKETS    PARKING	  AMOUNT		MOVIE\n");
   							printf("------------------------------------------------------------------------------------------------------------------");
   							while(fgets(str2, sizeof(str2), fp) != NULL)
   							{
   								check++;
   								if(check == line)
   								{
   								printf("\n%s", str2);	
								}
							}
							
							int wish;
							printf("\ndo you wish to continue ? 1)yes 0) no : ");
							scanf("%d", &wish);
							if(wish != 1)
							{
								exit(1);
							}							
							
							rewind(fp);
							
							char temp1[] = "new.txt";
							char str3[110], str4[110];
							FILE *fp1 = fopen(temp1, "w");
							if(fp1 == NULL)
							{
								printf("error");
							}
							int line1 = 0;
							while(fgets(str3, sizeof(str3), fp) != NULL)
							{
								line1++;
								if(line1 != line)
								{
									strcpy(str4, str3);
									fprintf(fp1,"%s", str4);
								}
								else
								{
									FILE *CAL = fopen("CancelledRegistrations_Bolly.txt", "a");
									fprintf(CAL,"\tWednesday\t%s", str3);
									fclose(CAL);
								}								
							}
							fclose(fp1);
							fclose(fp);
							remove(temp);
							rename(temp1, temp);

   							
   							char read[35];
   							int checker = 0;
   							int checker1;
   							int take;
   							char name1[] = "Book_Bolly_wed_movies.txt";
   							char name2[] = "new1.txt";
   							FILE *FP1 = fopen(name1,"r");
   							FILE *FP2 = fopen(name2,"w");
   							while(!feof(FP1))
   							{
   								checker++;
   								fscanf(FP1, "%s\n", read);
   								if(checker>=1 && checker<=3 && strcmp(read,movie)==0)
   								{
									checker1 = checker;
								//	printf("%d", checker1);
									fprintf(FP2 ,"%s\n", read);	
								}
								else if(checker>=4 && checker<=6 && checker == checker1+3)
								{
	
									take = atoi(&read);
									num1 += take;
									fprintf(FP2 ,"%d\n", num1);
								}
								else
								{
									fprintf(FP2, "%s\n", read);
								}
							}
							fclose(FP2);
							fclose(FP1);
							remove(name1);
							rename(name2,name1);
							
							char remain[] = "Remaining_parking_slot.txt";
	
							FILE *rem = fopen(remain,"a");
							fprintf(rem, "%d\n", num2);
							fclose(rem);
							
							char revenue[] = "BollywoodRevenue.txt";
							char revenue1[] = "new2.txt";
							
							FILE *REV = fopen(revenue, "r");
							FILE *REV1 = fopen(revenue1, "w");
							
							float rev;
							int amount_checker = 0;
							char extract[10], extract1[10];
							while(fgets(extract, sizeof(extract), REV) != NULL)
							{
								amount_checker++;
								if(amount_checker==3)
								{
									rev = atoi(&extract);
									rev -= amount;				
									fprintf(REV1,"%.2f\n", rev);
								}
								else
								{
									strcpy(extract1, extract);
									fprintf(REV1, "%s", extract1);
								}
							}
							fclose(REV1);
							fclose(REV);
							remove(revenue);
							rename(revenue1, revenue);
							gotoxy(15,20);
							printf("*************** YOUR REGISTRATION HAS BEEN CANCELLED :( ***************");							
							break;							
							
						}
					
					case 4:
						{
							int REG;
							printf("Enter your registeration no : ");
							scanf("%d", &REG);
							int registration, num1, num2;
							float amount;
							char name[25], movie[35], str1[110], str2[110];
							FILE *fp;

							char temp[] = "Booking_Bolly_thu_movies.txt";

   							fp = fopen(temp,"r");
   							if(fp==NULL)
   							{
   	 							exit(1);
   							}
   							int line = 1;
   							while(fgets(str1, sizeof(str1), fp)!=NULL)
   							{
   								++line;
   								fscanf(fp, "%10d%20s%10d%10d%10f%s", &registration, name, &num1, &num2, &amount, movie);
   								if(registration == REG)
   								{
   									break;
								}
   							}
   							rewind(fp);
   							int check = 0;
   							printf("------------------------------------------------------------------------------------------------------------------\n");
   							printf("      REG NO	     NAME	   TICKETS    PARKING	  AMOUNT		MOVIE\n");
   							printf("------------------------------------------------------------------------------------------------------------------");
   							while(fgets(str2, sizeof(str2), fp) != NULL)
   							{
   								check++;
   								if(check == line)
   								{
   								printf("\n%s", str2);	
								}
							}
							
							int wish;
							printf("\ndo you wish to continue ? 1)yes 0) no : ");
							scanf("%d", &wish);
							if(wish != 1)
							{
								exit(1);
							}							
							
							rewind(fp);
							
							char temp1[] = "new.txt";
							char str3[110], str4[110];
							FILE *fp1 = fopen(temp1, "w");
							if(fp1 == NULL)
							{
								printf("error");
							}
							int line1 = 0;
							while(fgets(str3, sizeof(str3), fp) != NULL)
							{
								line1++;
								if(line1 != line)
								{
									strcpy(str4, str3);
									fprintf(fp1,"%s", str4);
								}
								else
								{
									FILE *CAL = fopen("CancelledRegistrations_Bolly.txt", "a");
									fprintf(CAL,"\tThursday\t%s", str3);
									fclose(CAL);
								}								
							}
							fclose(fp1);
							fclose(fp);
							remove(temp);
							rename(temp1, temp);

   							
   							char read[35];
   							int checker = 0;
   							int checker1;
   							int take;
   							char name1[] = "Book_Bolly_thu_movies.txt";
   							char name2[] = "new1.txt";
   							FILE *FP1 = fopen(name1,"r");
   							FILE *FP2 = fopen(name2,"w");
   							while(!feof(FP1))
   							{
   								checker++;
   								fscanf(FP1, "%s\n", read);
   								if(checker>=1 && checker<=3 && strcmp(read,movie)==0)
   								{
									checker1 = checker;
								//	printf("%d", checker1);
									fprintf(FP2 ,"%s\n", read);	
								}
								else if(checker>=4 && checker<=6 && checker == checker1+3)
								{
	
									take = atoi(&read);
									num1 += take;
									fprintf(FP2 ,"%d\n", num1);
								}
								else
								{
									fprintf(FP2, "%s\n", read);
								}
							}
							fclose(FP2);
							fclose(FP1);
							remove(name1);
							rename(name2,name1);
							
							char remain[] = "Remaining_parking_slot.txt";
	
							FILE *rem = fopen(remain,"a");
							fprintf(rem, "%d\n", num2);
							fclose(rem);
							
							char revenue[] = "BollywoodRevenue.txt";
							char revenue1[] = "new2.txt";
							
							FILE *REV = fopen(revenue, "r");
							FILE *REV1 = fopen(revenue1, "w");
							
							float rev;
							int amount_checker = 0;
							char extract[10], extract1[10];
							while(fgets(extract, sizeof(extract), REV) != NULL)
							{
								amount_checker++;
								if(amount_checker==4)
								{
									rev = atoi(&extract);
									rev -= amount;				
									fprintf(REV1,"%.2f\n", rev);
								}
								else
								{
									strcpy(extract1, extract);
									fprintf(REV1, "%s", extract1);
								}
							}
							fclose(REV1);
							fclose(REV);
							remove(revenue);
							rename(revenue1, revenue);
							gotoxy(15,20);
							printf("*************** YOUR REGISTRATION HAS BEEN CANCELLED :( ***************");							
							break;							
						}
					case 5:
						{
							int REG;
							printf("Enter your registeration no : ");
							scanf("%d", &REG);
							int registration, num1, num2;
							float amount;
							char name[25], movie[35], str1[110], str2[110];
							FILE *fp;

							char temp[] = "Booking_Bolly_fri_movies.txt";

   							fp = fopen(temp,"r");
   							if(fp==NULL)
   							{
   	 							exit(1);
   							}
   							int line = 1;
   							while(fgets(str1, sizeof(str1), fp)!=NULL)
   							{
   								++line;
   								fscanf(fp, "%10d%20s%10d%10d%10f%s", &registration, name, &num1, &num2, &amount, movie);
   								if(registration == REG)
   								{
   									break;
								}
   							}
   							rewind(fp);
   							int check = 0;
   							printf("------------------------------------------------------------------------------------------------------------------\n");
   							printf("      REG NO	     NAME	   TICKETS    PARKING	  AMOUNT		MOVIE\n");
   							printf("------------------------------------------------------------------------------------------------------------------");
   							while(fgets(str2, sizeof(str2), fp) != NULL)
   							{
   								check++;
   								if(check == line)
   								{
   								printf("\n%s", str2);	
								}
							}
							
							int wish;
							printf("\ndo you wish to continue ? 1)yes 0) no : ");
							scanf("%d", &wish);
							if(wish != 1)
							{
								exit(1);
							}							
							
							rewind(fp);
							
							char temp1[] = "new.txt";
							char str3[110], str4[110];
							FILE *fp1 = fopen(temp1, "w");
							if(fp1 == NULL)
							{
								printf("error");
							}
							int line1 = 0;
							while(fgets(str3, sizeof(str3), fp) != NULL)
							{
								line1++;
								if(line1 != line)
								{
									strcpy(str4, str3);
									fprintf(fp1,"%s", str4);
								}
								else
								{
									FILE *CAL = fopen("CancelledRegistrations_Bolly.txt", "a");
									fprintf(CAL,"\tFriday\t%s", str3);
									fclose(CAL);
								}								
							}
							fclose(fp1);
							fclose(fp);
							remove(temp);
							rename(temp1, temp);

   							
   							char read[35];
   							int checker = 0;
   							int checker1;
   							int take;
   							char name1[] = "Book_Bolly_fri_movies.txt";
   							char name2[] = "new1.txt";
   							FILE *FP1 = fopen(name1,"r");
   							FILE *FP2 = fopen(name2,"w");
   							while(!feof(FP1))
   							{
   								checker++;
   								fscanf(FP1, "%s\n", read);
   								if(checker>=1 && checker<=3 && strcmp(read,movie)==0)
   								{
									checker1 = checker;
								//	printf("%d", checker1);
									fprintf(FP2 ,"%s\n", read);	
								}
								else if(checker>=4 && checker<=6 && checker == checker1+3)
								{
	
									take = atoi(&read);
									num1 += take;
									fprintf(FP2 ,"%d\n", num1);
								}
								else
								{
									fprintf(FP2, "%s\n", read);
								}
							}
							fclose(FP2);
							fclose(FP1);
							remove(name1);
							rename(name2,name1);
							
							char remain[] = "Remaining_parking_slot.txt";
	
							FILE *rem = fopen(remain,"a");
							fprintf(rem, "%d\n", num2);
							fclose(rem);
							
							char revenue[] = "BollywoodRevenue.txt";
							char revenue1[] = "new2.txt";
							
							FILE *REV = fopen(revenue, "r");
							FILE *REV1 = fopen(revenue1, "w");
							
							float rev;
							int amount_checker = 0;
							char extract[10], extract1[10];
							while(fgets(extract, sizeof(extract), REV) != NULL)
							{
								amount_checker++;
								if(amount_checker==5)
								{
									rev = atoi(&extract);
									rev -= amount;				
									fprintf(REV1,"%.2f\n", rev);
								}
								else
								{
									strcpy(extract1, extract);
									fprintf(REV1, "%s", extract1);
								}
							}
							fclose(REV1);
							fclose(REV);
							remove(revenue);
							rename(revenue1, revenue);
							gotoxy(15,20);
							printf("*************** YOUR REGISTRATION HAS BEEN CANCELLED :( ***************");							
							break;							
							
						}
	
					case 6:
						{
							int REG;
							printf("Enter your registeration no : ");
							scanf("%d", &REG);
							int registration, num1, num2;
							float amount;
							char name[25], movie[35], str1[110], str2[110];
							FILE *fp;

							char temp[] = "Booking_Bolly_sat_movies.txt";

   							fp = fopen(temp,"r");
   							if(fp==NULL)
   							{
   	 							exit(1);
   							}
   							int line = 1;
   							while(fgets(str1, sizeof(str1), fp)!=NULL)
   							{
   								++line;
   								fscanf(fp, "%10d%20s%10d%10d%10f%s", &registration, name, &num1, &num2, &amount, movie);
   								if(registration == REG)
   								{
   									break;
								}
   							}
   							rewind(fp);
   							int check = 0;
   							printf("------------------------------------------------------------------------------------------------------------------\n");
   							printf("      REG NO	     NAME	   TICKETS    PARKING	  AMOUNT		MOVIE\n");
   							printf("------------------------------------------------------------------------------------------------------------------");
   							while(fgets(str2, sizeof(str2), fp) != NULL)
   							{
   								check++;
   								if(check == line)
   								{
   								printf("\n%s", str2);	
								}
							}
							
							int wish;
							printf("\ndo you wish to continue ? 1)yes 0) no : ");
							scanf("%d", &wish);
							if(wish != 1)
							{
								exit(1);
							}							
							
							rewind(fp);
							
							char temp1[] = "new.txt";
							char str3[110], str4[110];
							FILE *fp1 = fopen(temp1, "w");
							if(fp1 == NULL)
							{
								printf("error");
							}
							int line1 = 0;
							while(fgets(str3, sizeof(str3), fp) != NULL)
							{
								line1++;
								if(line1 != line)
								{
									strcpy(str4, str3);
									fprintf(fp1,"%s", str4);
								}
								else
								{
									FILE *CAL = fopen("CancelledRegistrations_Bolly.txt", "a");
									fprintf(CAL,"\tSaturday\t%s", str3);
									fclose(CAL);
								}								
							}
							fclose(fp1);
							fclose(fp);
							remove(temp);
							rename(temp1, temp);

   							
   							char read[35];
   							int checker = 0;
   							int checker1;
   							int take;
   							char name1[] = "Book_Bolly_sat_movies.txt";
   							char name2[] = "new1.txt";
   							FILE *FP1 = fopen(name1,"r");
   							FILE *FP2 = fopen(name2,"w");
   							while(!feof(FP1))
   							{
   								checker++;
   								fscanf(FP1, "%s\n", read);
   								if(checker>=1 && checker<=3 && strcmp(read,movie)==0)
   								{
									checker1 = checker;
								//	printf("%d", checker1);
									fprintf(FP2 ,"%s\n", read);	
								}
								else if(checker>=4 && checker<=6 && checker == checker1+3)
								{
	
									take = atoi(&read);
									num1 += take;
									fprintf(FP2 ,"%d\n", num1);
								}
								else
								{
									fprintf(FP2, "%s\n", read);
								}
							}
							fclose(FP2);
							fclose(FP1);
							remove(name1);
							rename(name2,name1);
							
							char remain[] = "Remaining_parking_slot.txt";
	
							FILE *rem = fopen(remain,"a");
							fprintf(rem, "%d\n", num2);
							fclose(rem);
							
							char revenue[] = "BollywoodRevenue.txt";
							char revenue1[] = "new2.txt";
							
							FILE *REV = fopen(revenue, "r");
							FILE *REV1 = fopen(revenue1, "w");
							
							float rev;
							int amount_checker = 0;
							char extract[10], extract1[10];
							while(fgets(extract, sizeof(extract), REV) != NULL)
							{
								amount_checker++;
								if(amount_checker==6)
								{
									rev = atoi(&extract);
									rev -= amount;				
									fprintf(REV1,"%.2f\n", rev);
								}
								else
								{
									strcpy(extract1, extract);
									fprintf(REV1, "%s", extract1);
								}
							}
							fclose(REV1);
							fclose(REV);
							remove(revenue);
							rename(revenue1, revenue);
							gotoxy(15,20);
							printf("*************** YOUR REGISTRATION HAS BEEN CANCELLED :( ***************");							
							break;							
						}
					
					case 7:
						{
							int REG;
							printf("Enter your registeration no : ");
							scanf("%d", &REG);
							int registration, num1, num2;
							float amount;
							char name[25], movie[35], str1[110], str2[110];
							FILE *fp;

							char temp[] = "Booking_Bolly_sun_movies.txt";

   							fp = fopen(temp,"r");
   							if(fp==NULL)
   							{
   	 							exit(1);
   							}
   							int line = 1;
   							while(fgets(str1, sizeof(str1), fp)!=NULL)
   							{
   								++line;
   								fscanf(fp, "%10d%20s%10d%10d%10f%s", &registration, name, &num1, &num2, &amount, movie);
   								if(registration == REG)
   								{
   									break;
								}
   							}
   							rewind(fp);
   							int check = 0;
   							printf("------------------------------------------------------------------------------------------------------------------\n");
   							printf("      REG NO	     NAME	   TICKETS    PARKING	  AMOUNT		MOVIE\n");
   							printf("------------------------------------------------------------------------------------------------------------------");
   							while(fgets(str2, sizeof(str2), fp) != NULL)
   							{
   								check++;
   								if(check == line)
   								{
   								printf("\n%s", str2);	
								}
							}
							
							int wish;
							printf("\ndo you wish to continue ? 1)yes 0) no : ");
							scanf("%d", &wish);
							if(wish != 1)
							{
								exit(1);
							}							
							
							rewind(fp);
							
							char temp1[] = "new.txt";
							char str3[110], str4[110];
							FILE *fp1 = fopen(temp1, "w");
							if(fp1 == NULL)
							{
								printf("error");
							}
							int line1 = 0;
							while(fgets(str3, sizeof(str3), fp) != NULL)
							{
								line1++;
								if(line1 != line)
								{
									strcpy(str4, str3);
									fprintf(fp1,"%s", str4);
								}
								else
								{
									FILE *CAL = fopen("CancelledRegistrations_Bolly.txt", "a");
									fprintf(CAL,"\tSunday\t%s", str3);
									fclose(CAL);
								}								
							}
							fclose(fp1);
							fclose(fp);
							remove(temp);
							rename(temp1, temp);

   							
   							char read[35];
   							int checker = 0;
   							int checker1;
   							int take;
   							char name1[] = "Book_Bolly_sun_movies.txt";
   							char name2[] = "new1.txt";
   							FILE *FP1 = fopen(name1,"r");
   							FILE *FP2 = fopen(name2,"w");
   							while(!feof(FP1))
   							{
   								checker++;
   								fscanf(FP1, "%s\n", read);
   								if(checker>=1 && checker<=3 && strcmp(read,movie)==0)
   								{
									checker1 = checker;
								//	printf("%d", checker1);
									fprintf(FP2 ,"%s\n", read);	
								}
								else if(checker>=4 && checker<=6 && checker == checker1+3)
								{
	
									take = atoi(&read);
									num1 += take;
									fprintf(FP2 ,"%d\n", num1);
								}
								else
								{
									fprintf(FP2, "%s\n", read);
								}
							}
							fclose(FP2);
							fclose(FP1);
							remove(name1);
							rename(name2,name1);
							
							char remain[] = "Remaining_parking_slot.txt";
	
							FILE *rem = fopen(remain,"a");
							fprintf(rem, "%d\n", num2);
							fclose(rem);
							
							char revenue[] = "BollywoodRevenue.txt";
							char revenue1[] = "new2.txt";
							
							FILE *REV = fopen(revenue, "r");
							FILE *REV1 = fopen(revenue1, "w");
							
							float rev;
							int amount_checker = 0;
							char extract[10], extract1[10];
							while(fgets(extract, sizeof(extract), REV) != NULL)
							{
								amount_checker++;
								if(amount_checker==7)
								{
									rev = atoi(&extract);
									rev -= amount;				
									fprintf(REV1,"%.2f\n", rev);
								}
								else
								{
									strcpy(extract1, extract);
									fprintf(REV1, "%s", extract1);
								}
							}
							fclose(REV1);
							fclose(REV);
							remove(revenue);
							rename(revenue1, revenue);
							gotoxy(15,20);
							printf("*************** YOUR REGISTRATION HAS BEEN CANCELLED :( ***************");							
							break;							
						}
					default:
						{
							printf("Error 404! selection not found");
							break;
						}
				}
			break;	
		    }
			default:
			{
				printf("Error 404!");
				break;
			}
    }
}


void Rating()
{
	system("cls");
	printf("You entered in Rating");
	printf("\nSelect your category \n1)Hollywood \n2)Bollywood");
	
	int select;
	printf("\nEnter your selection : ");
	scanf("%d", &select);
	
	switch(select)
	{
		case 1:
			{
				system("cls");
				printf("You entered in hollywood");
				printf("\nmake your slection \n1)Monday \n2)Tuesday \n3)Wednesday \n4)Thursday \n5)Friday \n6)Saturday \n7)Sunday");
				
				int make;
				printf("\nenter your selection : ");
				scanf("%d", &make);
				
				switch(make)
				{
					case 1:
						{
							system("cls");
							printf("\nMovie -> Tickets -> Price -> Ratings -> No.of ratings\n\n");
							Book_Holly_mon_movies();
							int wish;
							printf("Would you like to proceed to rating ? 1)yes & 0) no : ");
							scanf("%d", &wish);
							if(wish == 0)
							{
								exit(1);
							}
							system("cls");							
							Book_Holly_mon_movies();
							
							int Cust;
							printf("Have you ever been our customer ? 1)yes & 0)no :  ");
							scanf("%d", &Cust);
							
								if(Cust == 1)
								{
									int REG;
									printf("Enter your Registrations ");
									scanf("%d", &REG);
									
									int get;
									FILE *CH = fopen("RegistrationNo.txt","r");
									fscanf(CH, "%d", &get);
									fclose(CH);
									
									if(REG>get)
									{
										printf("Invalid registration no!");
									}
									
									int movie_no; 
									float RATING;
									printf("Enter The movie no : ");
									scanf("%d", &movie_no);
									
									printf("Rate movie from 1.0 to 7.0 : ");
									scanf("%f", &RATING);
									
									char file[] = "Book_Holly_mon_movies.txt";
									char file1[] = "new.txt";
									
									FILE *Bo = fopen(file,"r");
									FILE *Bo1 = fopen(file1,"w");
									
									char extract[35];
									char extract1[35];
									char extract2[35];
									float rating, rating1;
									int counter = 0, ratingCount, ratingCount1, counter1 = 0;
									int counter2 = 0; 
									while(fgets(extract, sizeof(extract), Bo) != NULL)
									{
										counter++;
										if(counter>=1 && counter<=3 && counter == movie_no)
										{
											strcpy(extract2,extract);
										}
										if(counter>8 && counter<12)
										{
											fscanf(Bo, "%f", &rating);
											counter1++;
											if(counter1 == movie_no)
											{
												rating1 = rating + RATING;
											}
										}
										
										if(counter>11 && counter<15)
										{
											fscanf(Bo, "%d", &ratingCount);
											counter2++;
											if(counter2 == movie_no)
											{
												ratingCount1 = ratingCount + 1;
											}																						
										}
									}
									rewind(Bo);
									float rating2;
									
									rating1 = rating1/ratingCount1;
									
									int check = 0;
									while(fgets(extract1, sizeof(extract1), Bo) != NULL)
									{
										check++;
										if(check == movie_no+9)
										{
											fprintf(Bo1,"%.1f\n",rating1);
										}
										else if(check == movie_no+12)
										{
											fprintf(Bo1,"%d\n",ratingCount1);
										}
										else
										{
											fprintf(Bo1,"%s",extract1);
										}
									}
									
									char day[] = "Monday";
									FILE *ratdet = fopen("RatingDetails_Holly.txt","a");
									fprintf(ratdet,"%10s%30d%20.1f%40s", day, REG, RATING, extract2);
									fclose(ratdet); 
									
									
									fclose(Bo1);
									fclose(Bo);
									remove(file);
									rename(file1,file);
								}
								else
								{
									system("cls");
									printf("Thanks for contributing to us remotely!!!\n\n");
									
								    Book_Holly_mon_movies();
								
									int movie_no; 
									float RATING;
									printf("Enter The movie no : ");
									scanf("%d", &movie_no);
									
									printf("Rate movie from 1.0 to 7.0 : ");
									scanf("%f", &RATING);
									
									fflush(stdin);
									char name[35];
									printf("Example:- \nBasit:0343---- \nEnter your name : ");
									gets(name);
									
									char file[] = "Book_Holly_mon_movies.txt";
									char file1[] = "new.txt";
									
									FILE *Bo = fopen(file,"r");
									FILE *Bo1 = fopen(file1,"w");
									
									char extract[35];
									char extract1[35];
									char extract2[35];
									float rating, rating1;
									int counter = 0, ratingCount, ratingCount1, counter1 = 0;
									int counter2 = 0; 
									while(fgets(extract, sizeof(extract), Bo) != NULL)
									{
										counter++;
										if(counter>=1 && counter<=3 && counter == movie_no)
										{
											strcpy(extract2,extract);
										}
										if(counter>8 && counter<12)
										{
											fscanf(Bo, "%f", &rating);
											counter1++;
											if(counter1 == movie_no)
											{
												rating1 = rating + RATING;
												printf("%f", rating1);
											}
										}
										
										if(counter>11 && counter<15)
										{
											fscanf(Bo, "%d", &ratingCount);
											counter2++;
											if(counter2 == movie_no)
											{
												ratingCount1 = ratingCount + 1;
												printf("%d", ratingCount1);
											}																						
										}
									}
									rewind(Bo);
									float rating2;
									
									rating1 = rating1/ratingCount1;
									
									int check = 0;
									while(fgets(extract1, sizeof(extract1), Bo) != NULL)
									{
										check++;
										if(check == movie_no+9)
										{
											fprintf(Bo1,"%.1f\n",rating1);
										}
										else if(check == movie_no+12)
										{
											fprintf(Bo1,"%d\n",ratingCount1);
										}
										else
										{
											fprintf(Bo1,"%s",extract1);
										}
									}
									
									int REG = NULL;
								
									char day[] = "Monday";
									FILE *ratdet = fopen("RatingDetails_Holly.txt","a");
									fprintf(ratdet,"%10s%30s%20.1f%40s", day, name, RATING, extract2);
									fclose(ratdet); 
 
									
									
									fclose(Bo1);
									fclose(Bo);
									remove(file);
									rename(file1,file);							
							}
							gotoxy(15,25);
							printf("*************** YOUR RATING HAS BEEN RECEIVED :) ***************");							
							break;
						}
						
					case 2:
						{
							system("cls");
							printf("\nMovie -> Tickets -> Price -> Ratings -> No.of ratings\n\n");
							Book_Holly_tue_movies();
							int wish;
							printf("Would you like to proceed to rating ? 1)yes & 0) no : ");
							scanf("%d", &wish);
							if(wish == 0)
							{
								exit(1);
							}
							system("cls");							
							Book_Holly_tue_movies();
							
							int Cust;
							printf("Have you ever been our customer ? 1)yes & 0)no :  ");
							scanf("%d", &Cust);
							
								if(Cust == 1)
								{
									int REG;
									printf("Enter your Registrations ");
									scanf("%d", &REG);
									
									int get;
									FILE *CH = fopen("RegistrationNo.txt","r");
									fscanf(CH, "%d", &get);
									fclose(CH);
									
									if(REG>get)
									{
										printf("Invalid registration no!");
									}
									
									int movie_no; 
									float RATING;
									printf("Enter The movie no : ");
									scanf("%d", &movie_no);
									
									printf("Rate movie from 1.0 to 7.0 : ");
									scanf("%f", &RATING);
									
									char file[] = "Book_Holly_tue_movies.txt";
									char file1[] = "new.txt";
									
									FILE *Bo = fopen(file,"r");
									FILE *Bo1 = fopen(file1,"w");
									
									char extract[35];
									char extract1[35];
									char extract2[35];
									float rating, rating1;
									int counter = 0, ratingCount, ratingCount1, counter1 = 0;
									int counter2 = 0; 
									while(fgets(extract, sizeof(extract), Bo) != NULL)
									{
										counter++;
										if(counter>=1 && counter<=3 && counter == movie_no)
										{
											strcpy(extract2,extract);
										}
										if(counter>8 && counter<12)
										{
											fscanf(Bo, "%f", &rating);
											counter1++;
											if(counter1 == movie_no)
											{
												rating1 = rating + RATING;
											}
										}
										
										if(counter>11 && counter<15)
										{
											fscanf(Bo, "%d", &ratingCount);
											counter2++;
											if(counter2 == movie_no)
											{
												ratingCount1 = ratingCount + 1;
											}																						
										}
									}
									rewind(Bo);
									float rating2;
									
									rating1 = rating1/ratingCount1;
									
									int check = 0;
									while(fgets(extract1, sizeof(extract1), Bo) != NULL)
									{
										check++;
										if(check == movie_no+9)
										{
											fprintf(Bo1,"%.1f\n",rating1);
										}
										else if(check == movie_no+12)
										{
											fprintf(Bo1,"%d\n",ratingCount1);
										}
										else
										{
											fprintf(Bo1,"%s",extract1);
										}
									}
									
									char day[] = "Tuesday";
									FILE *ratdet = fopen("RatingDetails_Holly.txt","a");
									fprintf(ratdet,"%10s%30d%20.1f%40s", day, REG, RATING, extract2);
									fclose(ratdet); 
									
									
									fclose(Bo1);
									fclose(Bo);
									remove(file);
									rename(file1,file);
								}
								else
								{
									system("cls");
									printf("Thanks for contributing to us remotely!!!\n\n");
									
								    Book_Holly_tue_movies();
								
									int movie_no; 
									float RATING;
									printf("Enter The movie no : ");
									scanf("%d", &movie_no);
									
									printf("Rate movie from 1.0 to 7.0 : ");
									scanf("%f", &RATING);
									
									fflush(stdin);
									char name[35];
									printf("Example:- \nBasit:0343---- \nEnter your name : ");
									gets(name);
									
									char file[] = "Book_Holly_tue_movies.txt";
									char file1[] = "new.txt";
									
									FILE *Bo = fopen(file,"r");
									FILE *Bo1 = fopen(file1,"w");
									
									char extract[35];
									char extract1[35];
									char extract2[35];
									float rating, rating1;
									int counter = 0, ratingCount, ratingCount1, counter1 = 0;
									int counter2 = 0; 
									while(fgets(extract, sizeof(extract), Bo) != NULL)
									{
										counter++;
										if(counter>=1 && counter<=3 && counter == movie_no)
										{
											strcpy(extract2,extract);
										}
										if(counter>8 && counter<12)
										{
											fscanf(Bo, "%f", &rating);
											counter1++;
											if(counter1 == movie_no)
											{
												rating1 = rating + RATING;
												printf("%f", rating1);
											}
										}
										
										if(counter>11 && counter<15)
										{
											fscanf(Bo, "%d", &ratingCount);
											counter2++;
											if(counter2 == movie_no)
											{
												ratingCount1 = ratingCount + 1;
												printf("%d", ratingCount1);
											}																						
										}
									}
									rewind(Bo);
									float rating2;
									
									rating1 = rating1/ratingCount1;
									
									int check = 0;
									while(fgets(extract1, sizeof(extract1), Bo) != NULL)
									{
										check++;
										if(check == movie_no+9)
										{
											fprintf(Bo1,"%.1f\n",rating1);
										}
										else if(check == movie_no+12)
										{
											fprintf(Bo1,"%d\n",ratingCount1);
										}
										else
										{
											fprintf(Bo1,"%s",extract1);
										}
									}
									
									int REG = NULL;
								
									char day[] = "Monday";
									FILE *ratdet = fopen("RatingDetails_Holly.txt","a");
									fprintf(ratdet,"%10s%30s%20.1f%40s", day, name, RATING, extract2);
									fclose(ratdet);  
									
									
									fclose(Bo1);
									fclose(Bo);
									remove(file);
									rename(file1,file);		
							}
							gotoxy(15,25);
							printf("*************** YOUR RATING HAS BEEN RECEIVED :) ***************");							
							break;
						}
						
						
					case 3:
						{
							system("cls");
							printf("\nMovie -> Tickets -> Price -> Ratings -> No.of ratings\n\n");
							Book_Holly_wed_movies();
							int wish;
							printf("Would you like to proceed to rating ? 1)yes & 0) no : ");
							scanf("%d", &wish);
							if(wish == 0)
							{
								exit(1);
							}
							system("cls");							
							Book_Holly_wed_movies();
							
							int Cust;
							printf("Have you ever been our customer ? 1)yes & 0)no :  ");
							scanf("%d", &Cust);
							
								if(Cust == 1)
								{
									int REG;
									printf("Enter your Registrations ");
									scanf("%d", &REG);
									
									int get;
									FILE *CH = fopen("RegistrationNo.txt","r");
									fscanf(CH, "%d", &get);
									fclose(CH);
									
									if(REG>get)
									{
										printf("Invalid registration no!");
									}
									
									int movie_no; 
									float RATING;
									printf("Enter The movie no : ");
									scanf("%d", &movie_no);
									
									printf("Rate movie from 1.0 to 7.0 : ");
									scanf("%f", &RATING);
									
									char file[] = "Book_Holly_wed_movies.txt";
									char file1[] = "new.txt";
									
									FILE *Bo = fopen(file,"r");
									FILE *Bo1 = fopen(file1,"w");
									
									char extract[35];
									char extract1[35];
									char extract2[35];
									float rating, rating1;
									int counter = 0, ratingCount, ratingCount1, counter1 = 0;
									int counter2 = 0; 
									while(fgets(extract, sizeof(extract), Bo) != NULL)
									{
										counter++;
										if(counter>=1 && counter<=3 && counter == movie_no)
										{
											strcpy(extract2,extract);
										}
										if(counter>8 && counter<12)
										{
											fscanf(Bo, "%f", &rating);
											counter1++;
											if(counter1 == movie_no)
											{
												rating1 = rating + RATING;
											}
										}
										
										if(counter>11 && counter<15)
										{
											fscanf(Bo, "%d", &ratingCount);
											counter2++;
											if(counter2 == movie_no)
											{
												ratingCount1 = ratingCount + 1;
											}																						
										}
									}
									rewind(Bo);
									float rating2;
									
									rating1 = rating1/ratingCount1;
									
									int check = 0;
									while(fgets(extract1, sizeof(extract1), Bo) != NULL)
									{
										check++;
										if(check == movie_no+9)
										{
											fprintf(Bo1,"%.1f\n",rating1);
										}
										else if(check == movie_no+12)
										{
											fprintf(Bo1,"%d\n",ratingCount1);
										}
										else
										{
											fprintf(Bo1,"%s",extract1);
										}
									}
									
									char day[] = "Wednesday";
									FILE *ratdet = fopen("RatingDetails_Holly.txt","a");
									fprintf(ratdet,"%10s%30d%20.1f%40s", day, REG, RATING, extract2);
									fclose(ratdet); 
									
									
									fclose(Bo1);
									fclose(Bo);
									remove(file);
									rename(file1,file);
								}
								else
								{
									system("cls");
									printf("Thanks for contributing to us remotely!!!\n\n");
									
								    Book_Holly_wed_movies();
								
									int movie_no; 
									float RATING;
									printf("Enter The movie no : ");
									scanf("%d", &movie_no);
									
									printf("Rate movie from 1.0 to 7.0 : ");
									scanf("%f", &RATING);
									
									fflush(stdin);
									char name[35];
									printf("Example:- \nBasit:0343---- \nEnter your name : ");
									gets(name);
									
									char file[] = "Book_Holly_wed_movies.txt";
									char file1[] = "new.txt";
									
									FILE *Bo = fopen(file,"r");
									FILE *Bo1 = fopen(file1,"w");
									
									char extract[35];
									char extract1[35];
									char extract2[35];
									float rating, rating1;
									int counter = 0, ratingCount, ratingCount1, counter1 = 0;
									int counter2 = 0; 
									while(fgets(extract, sizeof(extract), Bo) != NULL)
									{
										counter++;
										if(counter>=1 && counter<=3 && counter == movie_no)
										{
											strcpy(extract2,extract);
										}
										if(counter>8 && counter<12)
										{
											fscanf(Bo, "%f", &rating);
											counter1++;
											if(counter1 == movie_no)
											{
												rating1 = rating + RATING;
												printf("%f", rating1);
											}
										}
										
										if(counter>11 && counter<15)
										{
											fscanf(Bo, "%d", &ratingCount);
											counter2++;
											if(counter2 == movie_no)
											{
												ratingCount1 = ratingCount + 1;
												printf("%d", ratingCount1);
											}																						
										}
									}
									rewind(Bo);
									float rating2;
									
									rating1 = rating1/ratingCount1;
									
									int check = 0;
									while(fgets(extract1, sizeof(extract1), Bo) != NULL)
									{
										check++;
										if(check == movie_no+9)
										{
											fprintf(Bo1,"%.1f\n",rating1);
										}
										else if(check == movie_no+12)
										{
											fprintf(Bo1,"%d\n",ratingCount1);
										}
										else
										{
											fprintf(Bo1,"%s",extract1);
										}
									}
									
									int REG = NULL;
								
									char day[] = "Wednesday";
									FILE *ratdet = fopen("RatingDetails_Holly.txt","a");
									fprintf(ratdet,"%10s%30s%20.1f%40s", day, name, RATING, extract2);
									fclose(ratdet);  
									
									
									fclose(Bo1);
									fclose(Bo);
									remove(file);
									rename(file1,file);		
							}
							gotoxy(15,25);
							printf("*************** YOUR RATING HAS BEEN RECEIVED :) ***************");							
							break;
						}
						
					case 4:
						{
							system("cls");
							printf("\nMovie -> Tickets -> Price -> Ratings -> No.of ratings\n\n");
							Book_Holly_thu_movies();
							int wish;
							printf("Would you like to proceed to rating ? 1)yes & 0) no : ");
							scanf("%d", &wish);
							if(wish == 0)
							{
								exit(1);
							}
							system("cls");							
							Book_Holly_thu_movies();
							
							int Cust;
							printf("Have you ever been our customer ? 1)yes & 0)no :  ");
							scanf("%d", &Cust);
							
								if(Cust == 1)
								{
									int REG;
									printf("Enter your Registrations ");
									scanf("%d", &REG);
									
									int get;
									FILE *CH = fopen("RegistrationNo.txt","r");
									fscanf(CH, "%d", &get);
									fclose(CH);
									
									if(REG>get)
									{
										printf("Invalid registration no!");
									}
									
									int movie_no; 
									float RATING;
									printf("Enter The movie no : ");
									scanf("%d", &movie_no);
									
									printf("Rate movie from 1.0 to 7.0 : ");
									scanf("%f", &RATING);
									
									char file[] = "Book_Holly_thu_movies.txt";
									char file1[] = "new.txt";
									
									FILE *Bo = fopen(file,"r");
									FILE *Bo1 = fopen(file1,"w");
									
									char extract[35];
									char extract1[35];
									char extract2[35];
									float rating, rating1;
									int counter = 0, ratingCount, ratingCount1, counter1 = 0;
									int counter2 = 0; 
									while(fgets(extract, sizeof(extract), Bo) != NULL)
									{
										counter++;
										if(counter>=1 && counter<=3 && counter == movie_no)
										{
											strcpy(extract2,extract);
										}
										if(counter>8 && counter<12)
										{
											fscanf(Bo, "%f", &rating);
											counter1++;
											if(counter1 == movie_no)
											{
												rating1 = rating + RATING;
											}
										}
										
										if(counter>11 && counter<15)
										{
											fscanf(Bo, "%d", &ratingCount);
											counter2++;
											if(counter2 == movie_no)
											{
												ratingCount1 = ratingCount + 1;
											}																						
										}
									}
									rewind(Bo);
									float rating2;
									
									rating1 = rating1/ratingCount1;
									
									int check = 0;
									while(fgets(extract1, sizeof(extract1), Bo) != NULL)
									{
										check++;
										if(check == movie_no+9)
										{
											fprintf(Bo1,"%.1f\n",rating1);
										}
										else if(check == movie_no+12)
										{
											fprintf(Bo1,"%d\n",ratingCount1);
										}
										else
										{
											fprintf(Bo1,"%s",extract1);
										}
									}
									
									char day[] = "Thursday";
									FILE *ratdet = fopen("RatingDetails_Holly.txt","a");
									fprintf(ratdet,"%10s%30d%20.1f%40s", day, REG, RATING, extract2);
									fclose(ratdet); 
									
									
									fclose(Bo1);
									fclose(Bo);
									remove(file);
									rename(file1,file);
								}
								else
								{
									system("cls");
									printf("Thanks for contributing to us remotely!!!\n\n");
									
								    Book_Holly_thu_movies();
								
									int movie_no; 
									float RATING;
									printf("Enter The movie no : ");
									scanf("%d", &movie_no);
									
									printf("Rate movie from 1.0 to 7.0 : ");
									scanf("%f", &RATING);
									
									fflush(stdin);
									char name[35];
									printf("Example:- \nBasit:0343---- \nEnter your name : ");
									gets(name);
									
									char file[] = "Book_Holly_thu_movies.txt";
									char file1[] = "new.txt";
									
									FILE *Bo = fopen(file,"r");
									FILE *Bo1 = fopen(file1,"w");
									
									char extract[35];
									char extract1[35];
									char extract2[35];
									float rating, rating1;
									int counter = 0, ratingCount, ratingCount1, counter1 = 0;
									int counter2 = 0; 
									while(fgets(extract, sizeof(extract), Bo) != NULL)
									{
										counter++;
										if(counter>=1 && counter<=3 && counter == movie_no)
										{
											strcpy(extract2,extract);
										}
										if(counter>8 && counter<12)
										{
											fscanf(Bo, "%f", &rating);
											counter1++;
											if(counter1 == movie_no)
											{
												rating1 = rating + RATING;
												printf("%f", rating1);
											}
										}
										
										if(counter>11 && counter<15)
										{
											fscanf(Bo, "%d", &ratingCount);
											counter2++;
											if(counter2 == movie_no)
											{
												ratingCount1 = ratingCount + 1;
												printf("%d", ratingCount1);
											}																						
										}
									}
									rewind(Bo);
									float rating2;
									
									rating1 = rating1/ratingCount1;
									
									int check = 0;
									while(fgets(extract1, sizeof(extract1), Bo) != NULL)
									{
										check++;
										if(check == movie_no+9)
										{
											fprintf(Bo1,"%.1f\n",rating1);
										}
										else if(check == movie_no+12)
										{
											fprintf(Bo1,"%d\n",ratingCount1);
										}
										else
										{
											fprintf(Bo1,"%s",extract1);
										}
									}
									
									int REG = NULL;
								
									char day[] = "Thursday";
									FILE *ratdet = fopen("RatingDetails_Holly.txt","a");
									fprintf(ratdet,"%10s%30s%20.1f%40s", day, name, RATING, extract2);
									fclose(ratdet);  
									
									
									fclose(Bo1);
									fclose(Bo);
									remove(file);
									rename(file1,file);		
							}
							gotoxy(15,25);
							printf("*************** YOUR RATING HAS BEEN RECEIVED :) ***************");							
							break;
						}
						
					case 5:
						{
							system("cls");
							printf("\nMovie -> Tickets -> Price -> Ratings -> No.of ratings\n\n");
							Book_Holly_fri_movies();
							int wish;
							printf("Would you like to proceed to rating ? 1)yes & 0) no : ");
							scanf("%d", &wish);
							if(wish == 0)
							{
								exit(1);
							}
							system("cls");							
							Book_Holly_fri_movies();
							
							int Cust;
							printf("Have you ever been our customer ? 1)yes & 0)no :  ");
							scanf("%d", &Cust);
							
								if(Cust == 1)
								{
									int REG;
									printf("Enter your Registrations ");
									scanf("%d", &REG);
									
									int get;
									FILE *CH = fopen("RegistrationNo.txt","r");
									fscanf(CH, "%d", &get);
									fclose(CH);
									
									if(REG>get)
									{
										printf("Invalid registration no!");
									}
									
									int movie_no; 
									float RATING;
									printf("Enter The movie no : ");
									scanf("%d", &movie_no);
									
									printf("Rate movie from 1.0 to 7.0 : ");
									scanf("%f", &RATING);
									
									char file[] = "Book_Holly_fri_movies.txt";
									char file1[] = "new.txt";
									
									FILE *Bo = fopen(file,"r");
									FILE *Bo1 = fopen(file1,"w");
									
									char extract[35];
									char extract1[35];
									char extract2[35];
									float rating, rating1;
									int counter = 0, ratingCount, ratingCount1, counter1 = 0;
									int counter2 = 0; 
									while(fgets(extract, sizeof(extract), Bo) != NULL)
									{
										counter++;
										if(counter>=1 && counter<=3 && counter == movie_no)
										{
											strcpy(extract2,extract);
										}
										if(counter>8 && counter<12)
										{
											fscanf(Bo, "%f", &rating);
											counter1++;
											if(counter1 == movie_no)
											{
												rating1 = rating + RATING;
											}
										}
										
										if(counter>11 && counter<15)
										{
											fscanf(Bo, "%d", &ratingCount);
											counter2++;
											if(counter2 == movie_no)
											{
												ratingCount1 = ratingCount + 1;
											}																						
										}
									}
									rewind(Bo);
									float rating2;
									
									rating1 = rating1/ratingCount1;
									
									int check = 0;
									while(fgets(extract1, sizeof(extract1), Bo) != NULL)
									{
										check++;
										if(check == movie_no+9)
										{
											fprintf(Bo1,"%.1f\n",rating1);
										}
										else if(check == movie_no+12)
										{
											fprintf(Bo1,"%d\n",ratingCount1);
										}
										else
										{
											fprintf(Bo1,"%s",extract1);
										}
									}
									
									char day[] = "Friday";
									FILE *ratdet = fopen("RatingDetails_Holly.txt","a");
									fprintf(ratdet,"%10s%30d%20.1f%40s", day, REG, RATING, extract2);
									fclose(ratdet); 
									
									
									fclose(Bo1);
									fclose(Bo);
									remove(file);
									rename(file1,file);
								}
								else
								{
									system("cls");
									printf("Thanks for contributing to us remotely!!!\n\n");
									
								    Book_Holly_fri_movies();
								
									int movie_no; 
									float RATING;
									printf("Enter The movie no : ");
									scanf("%d", &movie_no);
									
									printf("Rate movie from 1.0 to 7.0 : ");
									scanf("%f", &RATING);
									
									fflush(stdin);
									char name[35];
									printf("Example:- \nBasit:0343---- \nEnter your name : ");
									gets(name);
									
									char file[] = "Book_Holly_fri_movies.txt";
									char file1[] = "new.txt";
									
									FILE *Bo = fopen(file,"r");
									FILE *Bo1 = fopen(file1,"w");
									
									char extract[35];
									char extract1[35];
									char extract2[35];
									float rating, rating1;
									int counter = 0, ratingCount, ratingCount1, counter1 = 0;
									int counter2 = 0; 
									while(fgets(extract, sizeof(extract), Bo) != NULL)
									{
										counter++;
										if(counter>=1 && counter<=3 && counter == movie_no)
										{
											strcpy(extract2,extract);
										}
										if(counter>8 && counter<12)
										{
											fscanf(Bo, "%f", &rating);
											counter1++;
											if(counter1 == movie_no)
											{
												rating1 = rating + RATING;
												printf("%f", rating1);
											}
										}
										
										if(counter>11 && counter<15)
										{
											fscanf(Bo, "%d", &ratingCount);
											counter2++;
											if(counter2 == movie_no)
											{
												ratingCount1 = ratingCount + 1;
												printf("%d", ratingCount1);
											}																						
										}
									}
									rewind(Bo);
									float rating2;
									
									rating1 = rating1/ratingCount1;
									
									int check = 0;
									while(fgets(extract1, sizeof(extract1), Bo) != NULL)
									{
										check++;
										if(check == movie_no+9)
										{
											fprintf(Bo1,"%.1f\n",rating1);
										}
										else if(check == movie_no+12)
										{
											fprintf(Bo1,"%d\n",ratingCount1);
										}
										else
										{
											fprintf(Bo1,"%s",extract1);
										}
									}
									
									int REG = NULL;
								
									char day[] = "Friday";
									FILE *ratdet = fopen("RatingDetails_Holly.txt","a");
									fprintf(ratdet,"%10s%30s%20.1f%40s", day, name, RATING, extract2);
									fclose(ratdet);  
									
									
									fclose(Bo1);
									fclose(Bo);
									remove(file);
									rename(file1,file);		
							}
							gotoxy(15,25);
							printf("*************** YOUR RATING HAS BEEN RECEIVED :) ***************");							
							break;
						}
			
					case 6:
						{
							system("cls");
							printf("\nMovie -> Tickets -> Price -> Ratings -> No.of ratings\n\n");
							Book_Holly_sat_movies();
							int wish;
							printf("Would you like to proceed to rating ? 1)yes & 0) no : ");
							scanf("%d", &wish);
							if(wish == 0)
							{
								exit(1);
							}
							system("cls");							
							Book_Holly_sat_movies();
							
							int Cust;
							printf("Have you ever been our customer ? 1)yes & 0)no :  ");
							scanf("%d", &Cust);
							
								if(Cust == 1)
								{
									int REG;
									printf("Enter your Registrations ");
									scanf("%d", &REG);
									
									int get;
									FILE *CH = fopen("RegistrationNo.txt","r");
									fscanf(CH, "%d", &get);
									fclose(CH);
									
									if(REG>get)
									{
										printf("Invalid registration no!");
									}
									
									int movie_no; 
									float RATING;
									printf("Enter The movie no : ");
									scanf("%d", &movie_no);
									
									printf("Rate movie from 1.0 to 7.0 : ");
									scanf("%f", &RATING);
									
									char file[] = "Book_Holly_sat_movies.txt";
									char file1[] = "new.txt";
									
									FILE *Bo = fopen(file,"r");
									FILE *Bo1 = fopen(file1,"w");
									
									char extract[35];
									char extract1[35];
									char extract2[35];
									float rating, rating1;
									int counter = 0, ratingCount, ratingCount1, counter1 = 0;
									int counter2 = 0; 
									while(fgets(extract, sizeof(extract), Bo) != NULL)
									{
										counter++;
										if(counter>=1 && counter<=3 && counter == movie_no)
										{
											strcpy(extract2,extract);
										}
										if(counter>8 && counter<12)
										{
											fscanf(Bo, "%f", &rating);
											counter1++;
											if(counter1 == movie_no)
											{
												rating1 = rating + RATING;
											}
										}
										
										if(counter>11 && counter<15)
										{
											fscanf(Bo, "%d", &ratingCount);
											counter2++;
											if(counter2 == movie_no)
											{
												ratingCount1 = ratingCount + 1;
											}																						
										}
									}
									rewind(Bo);
									float rating2;
									
									rating1 = rating1/ratingCount1;
									
									int check = 0;
									while(fgets(extract1, sizeof(extract1), Bo) != NULL)
									{
										check++;
										if(check == movie_no+9)
										{
											fprintf(Bo1,"%.1f\n",rating1);
										}
										else if(check == movie_no+12)
										{
											fprintf(Bo1,"%d\n",ratingCount1);
										}
										else
										{
											fprintf(Bo1,"%s",extract1);
										}
									}
									
									char day[] = "Saturday";
									FILE *ratdet = fopen("RatingDetails_Holly.txt","a");
									fprintf(ratdet,"%10s%30d%20.1f%40s", day, REG, RATING, extract2);
									fclose(ratdet); 
									
									
									fclose(Bo1);
									fclose(Bo);
									remove(file);
									rename(file1,file);
								}
								else
								{
									system("cls");
									printf("Thanks for contributing to us remotely!!!\n\n");
									
								    Book_Holly_sat_movies();
								
									int movie_no; 
									float RATING;
									printf("Enter The movie no : ");
									scanf("%d", &movie_no);
									
									printf("Rate movie from 1.0 to 7.0 : ");
									scanf("%f", &RATING);
									
									fflush(stdin);
									char name[35];
									printf("Example:- \nBasit:0343---- \nEnter your name : ");
									gets(name);
									
									char file[] = "Book_Holly_sat_movies.txt";
									char file1[] = "new.txt";
									
									FILE *Bo = fopen(file,"r");
									FILE *Bo1 = fopen(file1,"w");
									
									char extract[35];
									char extract1[35];
									char extract2[35];
									float rating, rating1;
									int counter = 0, ratingCount, ratingCount1, counter1 = 0;
									int counter2 = 0; 
									while(fgets(extract, sizeof(extract), Bo) != NULL)
									{
										counter++;
										if(counter>=1 && counter<=3 && counter == movie_no)
										{
											strcpy(extract2,extract);
										}
										if(counter>8 && counter<12)
										{
											fscanf(Bo, "%f", &rating);
											counter1++;
											if(counter1 == movie_no)
											{
												rating1 = rating + RATING;
												printf("%f", rating1);
											}
										}
										
										if(counter>11 && counter<15)
										{
											fscanf(Bo, "%d", &ratingCount);
											counter2++;
											if(counter2 == movie_no)
											{
												ratingCount1 = ratingCount + 1;
												printf("%d", ratingCount1);
											}																						
										}
									}
									rewind(Bo);
									float rating2;
									
									rating1 = rating1/ratingCount1;
									
									int check = 0;
									while(fgets(extract1, sizeof(extract1), Bo) != NULL)
									{
										check++;
										if(check == movie_no+9)
										{
											fprintf(Bo1,"%.1f\n",rating1);
										}
										else if(check == movie_no+12)
										{
											fprintf(Bo1,"%d\n",ratingCount1);
										}
										else
										{
											fprintf(Bo1,"%s",extract1);
										}
									}
									
									int REG = NULL;
								
									char day[] = "Saturday";
									FILE *ratdet = fopen("RatingDetails_Holly.txt","a");
									fprintf(ratdet,"%10s%30s%20.1f%40s", day, name, RATING, extract2);
									fclose(ratdet);  
									
									
									fclose(Bo1);
									fclose(Bo);
									remove(file);
									rename(file1,file);		
							}
							gotoxy(15,25);
							printf("*************** YOUR RATING HAS BEEN RECEIVED :) ***************");							
							break;
						}
						
					case 7:
						{
							system("cls");
							printf("\nMovie -> Tickets -> Price -> Ratings -> No.of ratings\n\n");
							Book_Holly_sun_movies();
							int wish;
							printf("Would you like to proceed to rating ? 1)yes & 0) no : ");
							scanf("%d", &wish);
							if(wish == 0)
							{
								exit(1);
							}
							system("cls");							
							Book_Holly_sun_movies();
							
							int Cust;
							printf("Have you ever been our customer ? 1)yes & 0)no :  ");
							scanf("%d", &Cust);
							
								if(Cust == 1)
								{
									int REG;
									printf("Enter your Registrations ");
									scanf("%d", &REG);
									
									int get;
									FILE *CH = fopen("RegistrationNo.txt","r");
									fscanf(CH, "%d", &get);
									fclose(CH);
									
									if(REG>get)
									{
										printf("Invalid registration no!");
									}
									
									int movie_no; 
									float RATING;
									printf("Enter The movie no : ");
									scanf("%d", &movie_no);
									
									printf("Rate movie from 1.0 to 7.0 : ");
									scanf("%f", &RATING);
									
									char file[] = "Book_Holly_sun_movies.txt";
									char file1[] = "new.txt";
									
									FILE *Bo = fopen(file,"r");
									FILE *Bo1 = fopen(file1,"w");
									
									char extract[35];
									char extract1[35];
									char extract2[35];
									float rating, rating1;
									int counter = 0, ratingCount, ratingCount1, counter1 = 0;
									int counter2 = 0; 
									while(fgets(extract, sizeof(extract), Bo) != NULL)
									{
										counter++;
										if(counter>=1 && counter<=3 && counter == movie_no)
										{
											strcpy(extract2,extract);
										}
										if(counter>8 && counter<12)
										{
											fscanf(Bo, "%f", &rating);
											counter1++;
											if(counter1 == movie_no)
											{
												rating1 = rating + RATING;
											}
										}
										
										if(counter>11 && counter<15)
										{
											fscanf(Bo, "%d", &ratingCount);
											counter2++;
											if(counter2 == movie_no)
											{
												ratingCount1 = ratingCount + 1;
											}																						
										}
									}
									rewind(Bo);
									float rating2;
									
									rating1 = rating1/ratingCount1;
									
									int check = 0;
									while(fgets(extract1, sizeof(extract1), Bo) != NULL)
									{
										check++;
										if(check == movie_no+9)
										{
											fprintf(Bo1,"%.1f\n",rating1);
										}
										else if(check == movie_no+12)
										{
											fprintf(Bo1,"%d\n",ratingCount1);
										}
										else
										{
											fprintf(Bo1,"%s",extract1);
										}
									}
									
									char day[] = "Sunday";
									FILE *ratdet = fopen("RatingDetails_Holly.txt","a");
									fprintf(ratdet,"%10s%30d%20.1f%40s", day, REG, RATING, extract2);
									fclose(ratdet); 
									
									
									fclose(Bo1);
									fclose(Bo);
									remove(file);
									rename(file1,file);
								}
								else
								{
									system("cls");
									printf("Thanks for contributing to us remotely!!!\n\n");
									
								    Book_Holly_sun_movies();
								
									int movie_no; 
									float RATING;
									printf("Enter The movie no : ");
									scanf("%d", &movie_no);
									
									printf("Rate movie from 1.0 to 7.0 : ");
									scanf("%f", &RATING);
									
									fflush(stdin);
									char name[35];
									printf("Example:- \nBasit:0343---- \nEnter your name : ");
									gets(name);
									
									char file[] = "Book_Holly_sun_movies.txt";
									char file1[] = "new.txt";
									
									FILE *Bo = fopen(file,"r");
									FILE *Bo1 = fopen(file1,"w");
									
									char extract[35];
									char extract1[35];
									char extract2[35];
									float rating, rating1;
									int counter = 0, ratingCount, ratingCount1, counter1 = 0;
									int counter2 = 0; 
									while(fgets(extract, sizeof(extract), Bo) != NULL)
									{
										counter++;
										if(counter>=1 && counter<=3 && counter == movie_no)
										{
											strcpy(extract2,extract);
										}
										if(counter>8 && counter<12)
										{
											fscanf(Bo, "%f", &rating);
											counter1++;
											if(counter1 == movie_no)
											{
												rating1 = rating + RATING;
												printf("%f", rating1);
											}
										}
										
										if(counter>11 && counter<15)
										{
											fscanf(Bo, "%d", &ratingCount);
											counter2++;
											if(counter2 == movie_no)
											{
												ratingCount1 = ratingCount + 1;
												printf("%d", ratingCount1);
											}																						
										}
									}
									rewind(Bo);
									float rating2;
									
									rating1 = rating1/ratingCount1;
									
									int check = 0;
									while(fgets(extract1, sizeof(extract1), Bo) != NULL)
									{
										check++;
										if(check == movie_no+9)
										{
											fprintf(Bo1,"%.1f\n",rating1);
										}
										else if(check == movie_no+12)
										{
											fprintf(Bo1,"%d\n",ratingCount1);
										}
										else
										{
											fprintf(Bo1,"%s",extract1);
										}
									}
									
									int REG = NULL;
								
									char day[] = "Sunday";
									FILE *ratdet = fopen("RatingDetails_Holly.txt","a");
									fprintf(ratdet,"%10s%30s%20.1f%40s", day, name, RATING, extract2);
									fclose(ratdet);  
									
									
									fclose(Bo1);
									fclose(Bo);
									remove(file);
									rename(file1,file);		
							}
							gotoxy(15,25);
							printf("*************** YOUR RATING HAS BEEN RECEIVED :) ***************");							
							break;
						}
																																				
				default:
					{
							printf("Error 404! selection not found");
							break;
					}							
						
					}
					break;						
			}	
		case 2:
			{
				system("cls");
				printf("You entered in bollywood");
				printf("\nmake your slection \n1)Monday \n2)Tuesday \n3)Wednesday \n4)Thursday \n5)Friday \n6)Saturday \n7)Sunday");
				
				int make;
				printf("\nenter your selection : ");
				scanf("%d", &make);
				
				switch(make)
				{
					case 1:
						{
							system("cls");
							printf("\nMovie -> Tickets -> Price -> Ratings -> No.of ratings\n\n");
							Book_Bolly_mon_movies();
							int wish;
							printf("Would you like to proceed to rating ? 1)yes & 0) no : ");
							scanf("%d", &wish);
							if(wish == 0)
							{
								exit(1);
							}
							system("cls");							
							Book_Bolly_mon_movies();
							
							int Cust;
							printf("Have you ever been our customer ? 1)yes & 0)no :  ");
							scanf("%d", &Cust);
							
								if(Cust == 1)
								{
									int REG;
									printf("Enter your Registrations ");
									scanf("%d", &REG);
									
									int get;
									FILE *CH = fopen("RegistrationNo.txt","r");
									fscanf(CH, "%d", &get);
									fclose(CH);
									
									if(REG>get)
									{
										printf("Invalid registration no!");
									}
									
									int movie_no; 
									float RATING;
									printf("Enter The movie no : ");
									scanf("%d", &movie_no);
									
									printf("Rate movie from 1.0 to 7.0 : ");
									scanf("%f", &RATING);
									
									char file[] = "Book_Bolly_mon_movies.txt";
									char file1[] = "new.txt";
									
									FILE *Bo = fopen(file,"r");
									FILE *Bo1 = fopen(file1,"w");
									
									char extract[35];
									char extract1[35];
									char extract2[35];
									float rating, rating1;
									int counter = 0, ratingCount, ratingCount1, counter1 = 0;
									int counter2 = 0; 
									while(fgets(extract, sizeof(extract), Bo) != NULL)
									{
										counter++;
										if(counter>=1 && counter<=3 && counter == movie_no)
										{
											strcpy(extract2,extract);
										}
										if(counter>8 && counter<12)
										{
											fscanf(Bo, "%f", &rating);
											counter1++;
											if(counter1 == movie_no)
											{
												rating1 = rating + RATING;
											}
										}
										
										if(counter>11 && counter<15)
										{
											fscanf(Bo, "%d", &ratingCount);
											counter2++;
											if(counter2 == movie_no)
											{
												ratingCount1 = ratingCount + 1;
											}																						
										}
									}
									rewind(Bo);
									float rating2;
									
									rating1 = rating1/ratingCount1;
									
									int check = 0;
									while(fgets(extract1, sizeof(extract1), Bo) != NULL)
									{
										check++;
										if(check == movie_no+9)
										{
											fprintf(Bo1,"%.1f\n",rating1);
										}
										else if(check == movie_no+12)
										{
											fprintf(Bo1,"%d\n",ratingCount1);
										}
										else
										{
											fprintf(Bo1,"%s",extract1);
										}
									}
									
									char day[] = "Monday";
									FILE *ratdet = fopen("RatingDetails_Bolly.txt","a");
									fprintf(ratdet,"%10s%30d%20.1f%40s", day, REG, RATING, extract2);
									fclose(ratdet); 
									
									
									fclose(Bo1);
									fclose(Bo);
									remove(file);
									rename(file1,file);
								}
								else
								{
									system("cls");
									printf("Thanks for contributing to us remotely!!!\n\n");
									
								    Book_Bolly_mon_movies();
								
									int movie_no; 
									float RATING;
									printf("Enter The movie no : ");
									scanf("%d", &movie_no);
									
									printf("Rate movie from 1.0 to 7.0 : ");
									scanf("%f", &RATING);
									
									fflush(stdin);
									char name[35];
									printf("Example:- \nBasit:0343---- \nEnter your name : ");
									gets(name);
									
									char file[] = "Book_Holly_mon_movies.txt";
									char file1[] = "new.txt";
									
									FILE *Bo = fopen(file,"r");
									FILE *Bo1 = fopen(file1,"w");
									
									char extract[35];
									char extract1[35];
									char extract2[35];
									float rating, rating1;
									int counter = 0, ratingCount, ratingCount1, counter1 = 0;
									int counter2 = 0; 
									while(fgets(extract, sizeof(extract), Bo) != NULL)
									{
										counter++;
										if(counter>=1 && counter<=3 && counter == movie_no)
										{
											strcpy(extract2,extract);
										}
										if(counter>8 && counter<12)
										{
											fscanf(Bo, "%f", &rating);
											counter1++;
											if(counter1 == movie_no)
											{
												rating1 = rating + RATING;
												printf("%f", rating1);
											}
										}
										
										if(counter>11 && counter<15)
										{
											fscanf(Bo, "%d", &ratingCount);
											counter2++;
											if(counter2 == movie_no)
											{
												ratingCount1 = ratingCount + 1;
												printf("%d", ratingCount1);
											}																						
										}
									}
									rewind(Bo);
									float rating2;
									
									rating1 = rating1/ratingCount1;
									
									int check = 0;
									while(fgets(extract1, sizeof(extract1), Bo) != NULL)
									{
										check++;
										if(check == movie_no+9)
										{
											fprintf(Bo1,"%.1f\n",rating1);
										}
										else if(check == movie_no+12)
										{
											fprintf(Bo1,"%d\n",ratingCount1);
										}
										else
										{
											fprintf(Bo1,"%s",extract1);
										}
									}
									
									int REG = NULL;
								
									char day[] = "Monday";
									FILE *ratdet = fopen("RatingDetails_Bolly.txt","a");
									fprintf(ratdet,"%10s%30s%20.1f%40s", day, name, RATING, extract2);
									fclose(ratdet); 
 
									
									
									fclose(Bo1);
									fclose(Bo);
									remove(file);
									rename(file1,file);							
							}
							gotoxy(15,25);
							printf("*************** YOUR RATING HAS BEEN RECEIVED :) ***************");							
							break;
						}
						
					case 2:
						{
							system("cls");
							printf("\nMovie -> Tickets -> Price -> Ratings -> No.of ratings\n\n");
							Book_Bolly_tue_movies();
							int wish;
							printf("Would you like to proceed to rating ? 1)yes & 0) no : ");
							scanf("%d", &wish);
							if(wish == 0)
							{
								exit(1);
							}
							system("cls");							
							Book_Bolly_tue_movies();
							
							int Cust;
							printf("Have you ever been our customer ? 1)yes & 0)no :  ");
							scanf("%d", &Cust);
							
								if(Cust == 1)
								{
									int REG;
									printf("Enter your Registrations ");
									scanf("%d", &REG);
									
									int get;
									FILE *CH = fopen("RegistrationNo.txt","r");
									fscanf(CH, "%d", &get);
									fclose(CH);
									
									if(REG>get)
									{
										printf("Invalid registration no!");
									}
									
									int movie_no; 
									float RATING;
									printf("Enter The movie no : ");
									scanf("%d", &movie_no);
									
									printf("Rate movie from 1.0 to 7.0 : ");
									scanf("%f", &RATING);
									
									char file[] = "Book_Bolly_tue_movies.txt";
									char file1[] = "new.txt";
									
									FILE *Bo = fopen(file,"r");
									FILE *Bo1 = fopen(file1,"w");
									
									char extract[35];
									char extract1[35];
									char extract2[35];
									float rating, rating1;
									int counter = 0, ratingCount, ratingCount1, counter1 = 0;
									int counter2 = 0; 
									while(fgets(extract, sizeof(extract), Bo) != NULL)
									{
										counter++;
										if(counter>=1 && counter<=3 && counter == movie_no)
										{
											strcpy(extract2,extract);
										}
										if(counter>8 && counter<12)
										{
											fscanf(Bo, "%f", &rating);
											counter1++;
											if(counter1 == movie_no)
											{
												rating1 = rating + RATING;
											}
										}
										
										if(counter>11 && counter<15)
										{
											fscanf(Bo, "%d", &ratingCount);
											counter2++;
											if(counter2 == movie_no)
											{
												ratingCount1 = ratingCount + 1;
											}																						
										}
									}
									rewind(Bo);
									float rating2;
									
									rating1 = rating1/ratingCount1;
									
									int check = 0;
									while(fgets(extract1, sizeof(extract1), Bo) != NULL)
									{
										check++;
										if(check == movie_no+9)
										{
											fprintf(Bo1,"%.1f\n",rating1);
										}
										else if(check == movie_no+12)
										{
											fprintf(Bo1,"%d\n",ratingCount1);
										}
										else
										{
											fprintf(Bo1,"%s",extract1);
										}
									}
									
									char day[] = "Tuesday";
									FILE *ratdet = fopen("RatingDetails_Bolly.txt","a");
									fprintf(ratdet,"%10s%30d%20.1f%40s", day, REG, RATING, extract2);
									fclose(ratdet); 
									
									
									fclose(Bo1);
									fclose(Bo);
									remove(file);
									rename(file1,file);
								}
								else
								{
									system("cls");
									printf("Thanks for contributing to us remotely!!!\n\n");
									
								    Book_Holly_tue_movies();
								
									int movie_no; 
									float RATING;
									printf("Enter The movie no : ");
									scanf("%d", &movie_no);
									
									printf("Rate movie from 1.0 to 7.0 : ");
									scanf("%f", &RATING);
									
									fflush(stdin);
									char name[35];
									printf("Example:- \nBasit:0343---- \nEnter your name : ");
									gets(name);
									
									char file[] = "Book_Bolly_tue_movies.txt";
									char file1[] = "new.txt";
									
									FILE *Bo = fopen(file,"r");
									FILE *Bo1 = fopen(file1,"w");
									
									char extract[35];
									char extract1[35];
									char extract2[35];
									float rating, rating1;
									int counter = 0, ratingCount, ratingCount1, counter1 = 0;
									int counter2 = 0; 
									while(fgets(extract, sizeof(extract), Bo) != NULL)
									{
										counter++;
										if(counter>=1 && counter<=3 && counter == movie_no)
										{
											strcpy(extract2,extract);
										}
										if(counter>8 && counter<12)
										{
											fscanf(Bo, "%f", &rating);
											counter1++;
											if(counter1 == movie_no)
											{
												rating1 = rating + RATING;
												printf("%f", rating1);
											}
										}
										
										if(counter>11 && counter<15)
										{
											fscanf(Bo, "%d", &ratingCount);
											counter2++;
											if(counter2 == movie_no)
											{
												ratingCount1 = ratingCount + 1;
												printf("%d", ratingCount1);
											}																						
										}
									}
									rewind(Bo);
									float rating2;
									
									rating1 = rating1/ratingCount1;
									
									int check = 0;
									while(fgets(extract1, sizeof(extract1), Bo) != NULL)
									{
										check++;
										if(check == movie_no+9)
										{
											fprintf(Bo1,"%.1f\n",rating1);
										}
										else if(check == movie_no+12)
										{
											fprintf(Bo1,"%d\n",ratingCount1);
										}
										else
										{
											fprintf(Bo1,"%s",extract1);
										}
									}
									
									int REG = NULL;
								
									char day[] = "Monday";
									FILE *ratdet = fopen("RatingDetails_Bolly.txt","a");
									fprintf(ratdet,"%10s%30s%20.1f%40s", day, name, RATING, extract2);
									fclose(ratdet);  
									
									
									fclose(Bo1);
									fclose(Bo);
									remove(file);
									rename(file1,file);		
							}
							gotoxy(15,25);
							printf("*************** YOUR RATING HAS BEEN RECEIVED :) ***************");							
							break;
						}
						
						
					case 3:
						{
							system("cls");
							printf("\nMovie -> Tickets -> Price -> Ratings -> No.of ratings\n\n");
							Book_Bolly_wed_movies();
							int wish;
							printf("Would you like to proceed to rating ? 1)yes & 0) no : ");
							scanf("%d", &wish);
							if(wish == 0)
							{
								exit(1);
							}
							system("cls");							
							Book_Bolly_wed_movies();
							
							int Cust;
							printf("Have you ever been our customer ? 1)yes & 0)no :  ");
							scanf("%d", &Cust);
							
								if(Cust == 1)
								{
									int REG;
									printf("Enter your Registrations ");
									scanf("%d", &REG);
									
									int get;
									FILE *CH = fopen("RegistrationNo.txt","r");
									fscanf(CH, "%d", &get);
									fclose(CH);
									
									if(REG>get)
									{
										printf("Invalid registration no!");
									}
									
									int movie_no; 
									float RATING;
									printf("Enter The movie no : ");
									scanf("%d", &movie_no);
									
									printf("Rate movie from 1.0 to 7.0 : ");
									scanf("%f", &RATING);
									
									char file[] = "Book_Bolly_wed_movies.txt";
									char file1[] = "new.txt";
									
									FILE *Bo = fopen(file,"r");
									FILE *Bo1 = fopen(file1,"w");
									
									char extract[35];
									char extract1[35];
									char extract2[35];
									float rating, rating1;
									int counter = 0, ratingCount, ratingCount1, counter1 = 0;
									int counter2 = 0; 
									while(fgets(extract, sizeof(extract), Bo) != NULL)
									{
										counter++;
										if(counter>=1 && counter<=3 && counter == movie_no)
										{
											strcpy(extract2,extract);
										}
										if(counter>8 && counter<12)
										{
											fscanf(Bo, "%f", &rating);
											counter1++;
											if(counter1 == movie_no)
											{
												rating1 = rating + RATING;
											}
										}
										
										if(counter>11 && counter<15)
										{
											fscanf(Bo, "%d", &ratingCount);
											counter2++;
											if(counter2 == movie_no)
											{
												ratingCount1 = ratingCount + 1;
											}																						
										}
									}
									rewind(Bo);
									float rating2;
									
									rating1 = rating1/ratingCount1;
									
									int check = 0;
									while(fgets(extract1, sizeof(extract1), Bo) != NULL)
									{
										check++;
										if(check == movie_no+9)
										{
											fprintf(Bo1,"%.1f\n",rating1);
										}
										else if(check == movie_no+12)
										{
											fprintf(Bo1,"%d\n",ratingCount1);
										}
										else
										{
											fprintf(Bo1,"%s",extract1);
										}
									}
									
									char day[] = "Wednesday";
									FILE *ratdet = fopen("RatingDetails_Bolly.txt","a");
									fprintf(ratdet,"%10s%30d%20.1f%40s", day, REG, RATING, extract2);
									fclose(ratdet); 
									
									
									fclose(Bo1);
									fclose(Bo);
									remove(file);
									rename(file1,file);
								}
								else
								{
									system("cls");
									printf("Thanks for contributing to us remotely!!!\n\n");
									
								    Book_Bolly_wed_movies();
								
									int movie_no; 
									float RATING;
									printf("Enter The movie no : ");
									scanf("%d", &movie_no);
									
									printf("Rate movie from 1.0 to 7.0 : ");
									scanf("%f", &RATING);
									
									fflush(stdin);
									char name[35];
									printf("Example:- \nBasit:0343---- \nEnter your name : ");
									gets(name);
									
									char file[] = "Book_Bolly_wed_movies.txt";
									char file1[] = "new.txt";
									
									FILE *Bo = fopen(file,"r");
									FILE *Bo1 = fopen(file1,"w");
									
									char extract[35];
									char extract1[35];
									char extract2[35];
									float rating, rating1;
									int counter = 0, ratingCount, ratingCount1, counter1 = 0;
									int counter2 = 0; 
									while(fgets(extract, sizeof(extract), Bo) != NULL)
									{
										counter++;
										if(counter>=1 && counter<=3 && counter == movie_no)
										{
											strcpy(extract2,extract);
										}
										if(counter>8 && counter<12)
										{
											fscanf(Bo, "%f", &rating);
											counter1++;
											if(counter1 == movie_no)
											{
												rating1 = rating + RATING;
												printf("%f", rating1);
											}
										}
										
										if(counter>11 && counter<15)
										{
											fscanf(Bo, "%d", &ratingCount);
											counter2++;
											if(counter2 == movie_no)
											{
												ratingCount1 = ratingCount + 1;
												printf("%d", ratingCount1);
											}																						
										}
									}
									rewind(Bo);
									float rating2;
									
									rating1 = rating1/ratingCount1;
									
									int check = 0;
									while(fgets(extract1, sizeof(extract1), Bo) != NULL)
									{
										check++;
										if(check == movie_no+9)
										{
											fprintf(Bo1,"%.1f\n",rating1);
										}
										else if(check == movie_no+12)
										{
											fprintf(Bo1,"%d\n",ratingCount1);
										}
										else
										{
											fprintf(Bo1,"%s",extract1);
										}
									}
									
									int REG = NULL;
								
									char day[] = "Wednesday";
									FILE *ratdet = fopen("RatingDetails_Bolly.txt","a");
									fprintf(ratdet,"%10s%30s%20.1f%40s", day, name, RATING, extract2);
									fclose(ratdet);  
									
									
									fclose(Bo1);
									fclose(Bo);
									remove(file);
									rename(file1,file);		
							}
							gotoxy(15,25);
							printf("*************** YOUR RATING HAS BEEN RECEIVED :) ***************");							
							break;
						}
						
					case 4:
						{
							system("cls");
							printf("\nMovie -> Tickets -> Price -> Ratings -> No.of ratings\n\n");
							Book_Bolly_thu_movies();
							int wish;
							printf("Would you like to proceed to rating ? 1)yes & 0) no : ");
							scanf("%d", &wish);
							if(wish == 0)
							{
								exit(1);
							}
							system("cls");							
							Book_Bolly_thu_movies();
							
							int Cust;
							printf("Have you ever been our customer ? 1)yes & 0)no :  ");
							scanf("%d", &Cust);
							
								if(Cust == 1)
								{
									int REG;
									printf("Enter your Registrations ");
									scanf("%d", &REG);
									
									int get;
									FILE *CH = fopen("RegistrationNo.txt","r");
									fscanf(CH, "%d", &get);
									fclose(CH);
									
									if(REG>get)
									{
										printf("Invalid registration no!");
									}
									
									int movie_no; 
									float RATING;
									printf("Enter The movie no : ");
									scanf("%d", &movie_no);
									
									printf("Rate movie from 1.0 to 7.0 : ");
									scanf("%f", &RATING);
									
									char file[] = "Book_Bolly_thu_movies.txt";
									char file1[] = "new.txt";
									
									FILE *Bo = fopen(file,"r");
									FILE *Bo1 = fopen(file1,"w");
									
									char extract[35];
									char extract1[35];
									char extract2[35];
									float rating, rating1;
									int counter = 0, ratingCount, ratingCount1, counter1 = 0;
									int counter2 = 0; 
									while(fgets(extract, sizeof(extract), Bo) != NULL)
									{
										counter++;
										if(counter>=1 && counter<=3 && counter == movie_no)
										{
											strcpy(extract2,extract);
										}
										if(counter>8 && counter<12)
										{
											fscanf(Bo, "%f", &rating);
											counter1++;
											if(counter1 == movie_no)
											{
												rating1 = rating + RATING;
											}
										}
										
										if(counter>11 && counter<15)
										{
											fscanf(Bo, "%d", &ratingCount);
											counter2++;
											if(counter2 == movie_no)
											{
												ratingCount1 = ratingCount + 1;
											}																						
										}
									}
									rewind(Bo);
									float rating2;
									
									rating1 = rating1/ratingCount1;
									
									int check = 0;
									while(fgets(extract1, sizeof(extract1), Bo) != NULL)
									{
										check++;
										if(check == movie_no+9)
										{
											fprintf(Bo1,"%.1f\n",rating1);
										}
										else if(check == movie_no+12)
										{
											fprintf(Bo1,"%d\n",ratingCount1);
										}
										else
										{
											fprintf(Bo1,"%s",extract1);
										}
									}
									
									char day[] = "Thursday";
									FILE *ratdet = fopen("RatingDetails_Bolly.txt","a");
									fprintf(ratdet,"%10s%30d%20.1f%40s", day, REG, RATING, extract2);
									fclose(ratdet); 
									
									
									fclose(Bo1);
									fclose(Bo);
									remove(file);
									rename(file1,file);
								}
								else
								{
									system("cls");
									printf("Thanks for contributing to us remotely!!!\n\n");
									
								    Book_Bolly_thu_movies();
								
									int movie_no; 
									float RATING;
									printf("Enter The movie no : ");
									scanf("%d", &movie_no);
									
									printf("Rate movie from 1.0 to 7.0 : ");
									scanf("%f", &RATING);
									
									fflush(stdin);
									char name[35];
									printf("Example:- \nBasit:0343---- \nEnter your name : ");
									gets(name);
									
									char file[] = "Book_Bolly_thu_movies.txt";
									char file1[] = "new.txt";
									
									FILE *Bo = fopen(file,"r");
									FILE *Bo1 = fopen(file1,"w");
									
									char extract[35];
									char extract1[35];
									char extract2[35];
									float rating, rating1;
									int counter = 0, ratingCount, ratingCount1, counter1 = 0;
									int counter2 = 0; 
									while(fgets(extract, sizeof(extract), Bo) != NULL)
									{
										counter++;
										if(counter>=1 && counter<=3 && counter == movie_no)
										{
											strcpy(extract2,extract);
										}
										if(counter>8 && counter<12)
										{
											fscanf(Bo, "%f", &rating);
											counter1++;
											if(counter1 == movie_no)
											{
												rating1 = rating + RATING;
												printf("%f", rating1);
											}
										}
										
										if(counter>11 && counter<15)
										{
											fscanf(Bo, "%d", &ratingCount);
											counter2++;
											if(counter2 == movie_no)
											{
												ratingCount1 = ratingCount + 1;
												printf("%d", ratingCount1);
											}																						
										}
									}
									rewind(Bo);
									float rating2;
									
									rating1 = rating1/ratingCount1;
									
									int check = 0;
									while(fgets(extract1, sizeof(extract1), Bo) != NULL)
									{
										check++;
										if(check == movie_no+9)
										{
											fprintf(Bo1,"%.1f\n",rating1);
										}
										else if(check == movie_no+12)
										{
											fprintf(Bo1,"%d\n",ratingCount1);
										}
										else
										{
											fprintf(Bo1,"%s",extract1);
										}
									}
									
									int REG = NULL;
								
									char day[] = "Thursday";
									FILE *ratdet = fopen("RatingDetails_Bolly.txt","a");
									fprintf(ratdet,"%10s%30s%20.1f%40s", day, name, RATING, extract2);
									fclose(ratdet);  
									
									
									fclose(Bo1);
									fclose(Bo);
									remove(file);
									rename(file1,file);		
							}
							gotoxy(15,25);
							printf("*************** YOUR RATING HAS BEEN RECEIVED :) ***************");							
							break;
						}
						
					case 5:
						{
							system("cls");
							printf("\nMovie -> Tickets -> Price -> Ratings -> No.of ratings\n\n");
							Book_Bolly_fri_movies();
							int wish;
							printf("Would you like to proceed to rating ? 1)yes & 0) no : ");
							scanf("%d", &wish);
							if(wish == 0)
							{
								exit(1);
							}
							system("cls");							
							Book_Bolly_fri_movies();
							
							int Cust;
							printf("Have you ever been our customer ? 1)yes & 0)no :  ");
							scanf("%d", &Cust);
							
								if(Cust == 1)
								{
									int REG;
									printf("Enter your Registrations ");
									scanf("%d", &REG);
									
									int get;
									FILE *CH = fopen("RegistrationNo.txt","r");
									fscanf(CH, "%d", &get);
									fclose(CH);
									
									if(REG>get)
									{
										printf("Invalid registration no!");
									}
									
									int movie_no; 
									float RATING;
									printf("Enter The movie no : ");
									scanf("%d", &movie_no);
									
									printf("Rate movie from 1.0 to 7.0 : ");
									scanf("%f", &RATING);
									
									char file[] = "Book_Bolly_fri_movies.txt";
									char file1[] = "new.txt";
									
									FILE *Bo = fopen(file,"r");
									FILE *Bo1 = fopen(file1,"w");
									
									char extract[35];
									char extract1[35];
									char extract2[35];
									float rating, rating1;
									int counter = 0, ratingCount, ratingCount1, counter1 = 0;
									int counter2 = 0; 
									while(fgets(extract, sizeof(extract), Bo) != NULL)
									{
										counter++;
										if(counter>=1 && counter<=3 && counter == movie_no)
										{
											strcpy(extract2,extract);
										}
										if(counter>8 && counter<12)
										{
											fscanf(Bo, "%f", &rating);
											counter1++;
											if(counter1 == movie_no)
											{
												rating1 = rating + RATING;
											}
										}
										
										if(counter>11 && counter<15)
										{
											fscanf(Bo, "%d", &ratingCount);
											counter2++;
											if(counter2 == movie_no)
											{
												ratingCount1 = ratingCount + 1;
											}																						
										}
									}
									rewind(Bo);
									float rating2;
									
									rating1 = rating1/ratingCount1;
									
									int check = 0;
									while(fgets(extract1, sizeof(extract1), Bo) != NULL)
									{
										check++;
										if(check == movie_no+9)
										{
											fprintf(Bo1,"%.1f\n",rating1);
										}
										else if(check == movie_no+12)
										{
											fprintf(Bo1,"%d\n",ratingCount1);
										}
										else
										{
											fprintf(Bo1,"%s",extract1);
										}
									}
									
									char day[] = "Friday";
									FILE *ratdet = fopen("RatingDetails_Bolly.txt","a");
									fprintf(ratdet,"%10s%30d%20.1f%40s", day, REG, RATING, extract2);
									fclose(ratdet); 
									
									
									fclose(Bo1);
									fclose(Bo);
									remove(file);
									rename(file1,file);
								}
								else
								{
									system("cls");
									printf("Thanks for contributing to us remotely!!!\n\n");
									
								    Book_Bolly_fri_movies();
								
									int movie_no; 
									float RATING;
									printf("Enter The movie no : ");
									scanf("%d", &movie_no);
									
									printf("Rate movie from 1.0 to 7.0 : ");
									scanf("%f", &RATING);
									
									fflush(stdin);
									char name[35];
									printf("Example:- \nBasit:0343---- \nEnter your name : ");
									gets(name);
									
									char file[] = "Book_Bolly_fri_movies.txt";
									char file1[] = "new.txt";
									
									FILE *Bo = fopen(file,"r");
									FILE *Bo1 = fopen(file1,"w");
									
									char extract[35];
									char extract1[35];
									char extract2[35];
									float rating, rating1;
									int counter = 0, ratingCount, ratingCount1, counter1 = 0;
									int counter2 = 0; 
									while(fgets(extract, sizeof(extract), Bo) != NULL)
									{
										counter++;
										if(counter>=1 && counter<=3 && counter == movie_no)
										{
											strcpy(extract2,extract);
										}
										if(counter>8 && counter<12)
										{
											fscanf(Bo, "%f", &rating);
											counter1++;
											if(counter1 == movie_no)
											{
												rating1 = rating + RATING;
												printf("%f", rating1);
											}
										}
										
										if(counter>11 && counter<15)
										{
											fscanf(Bo, "%d", &ratingCount);
											counter2++;
											if(counter2 == movie_no)
											{
												ratingCount1 = ratingCount + 1;
												printf("%d", ratingCount1);
											}																						
										}
									}
									rewind(Bo);
									float rating2;
									
									rating1 = rating1/ratingCount1;
									
									int check = 0;
									while(fgets(extract1, sizeof(extract1), Bo) != NULL)
									{
										check++;
										if(check == movie_no+9)
										{
											fprintf(Bo1,"%.1f\n",rating1);
										}
										else if(check == movie_no+12)
										{
											fprintf(Bo1,"%d\n",ratingCount1);
										}
										else
										{
											fprintf(Bo1,"%s",extract1);
										}
									}
									
									int REG = NULL;
								
									char day[] = "Friday";
									FILE *ratdet = fopen("RatingDetails_Bolly.txt","a");
									fprintf(ratdet,"%10s%30s%20.1f%40s", day, name, RATING, extract2);
									fclose(ratdet);  
									
									
									fclose(Bo1);
									fclose(Bo);
									remove(file);
									rename(file1,file);		
							}
							gotoxy(15,25);
							printf("*************** YOUR RATING HAS BEEN RECEIVED :) ***************");							
							break;
						}
			
					case 6:
						{
							system("cls");
							printf("\nMovie -> Tickets -> Price -> Ratings -> No.of ratings\n\n");
							Book_Bolly_sat_movies();
							int wish;
							printf("Would you like to proceed to rating ? 1)yes & 0) no : ");
							scanf("%d", &wish);
							if(wish == 0)
							{
								exit(1);
							}
							system("cls");							
							Book_Bolly_sat_movies();
							
							int Cust;
							printf("Have you ever been our customer ? 1)yes & 0)no :  ");
							scanf("%d", &Cust);
							
								if(Cust == 1)
								{
									int REG;
									printf("Enter your Registrations ");
									scanf("%d", &REG);
									
									int get;
									FILE *CH = fopen("RegistrationNo.txt","r");
									fscanf(CH, "%d", &get);
									fclose(CH);
									
									if(REG>get)
									{
										printf("Invalid registration no!");
									}
									
									int movie_no; 
									float RATING;
									printf("Enter The movie no : ");
									scanf("%d", &movie_no);
									
									printf("Rate movie from 1.0 to 7.0 : ");
									scanf("%f", &RATING);
									
									char file[] = "Book_Holly_sat_movies.txt";
									char file1[] = "new.txt";
									
									FILE *Bo = fopen(file,"r");
									FILE *Bo1 = fopen(file1,"w");
									
									char extract[35];
									char extract1[35];
									char extract2[35];
									float rating, rating1;
									int counter = 0, ratingCount, ratingCount1, counter1 = 0;
									int counter2 = 0; 
									while(fgets(extract, sizeof(extract), Bo) != NULL)
									{
										counter++;
										if(counter>=1 && counter<=3 && counter == movie_no)
										{
											strcpy(extract2,extract);
										}
										if(counter>8 && counter<12)
										{
											fscanf(Bo, "%f", &rating);
											counter1++;
											if(counter1 == movie_no)
											{
												rating1 = rating + RATING;
											}
										}
										
										if(counter>11 && counter<15)
										{
											fscanf(Bo, "%d", &ratingCount);
											counter2++;
											if(counter2 == movie_no)
											{
												ratingCount1 = ratingCount + 1;
											}																						
										}
									}
									rewind(Bo);
									float rating2;
									
									rating1 = rating1/ratingCount1;
									
									int check = 0;
									while(fgets(extract1, sizeof(extract1), Bo) != NULL)
									{
										check++;
										if(check == movie_no+9)
										{
											fprintf(Bo1,"%.1f\n",rating1);
										}
										else if(check == movie_no+12)
										{
											fprintf(Bo1,"%d\n",ratingCount1);
										}
										else
										{
											fprintf(Bo1,"%s",extract1);
										}
									}
									
									char day[] = "Saturday";
									FILE *ratdet = fopen("RatingDetails_Bolly.txt","a");
									fprintf(ratdet,"%10s%30d%20.1f%40s", day, REG, RATING, extract2);
									fclose(ratdet); 
									
									
									fclose(Bo1);
									fclose(Bo);
									remove(file);
									rename(file1,file);
								}
								else
								{
									system("cls");
									printf("Thanks for contributing to us remotely!!!\n\n");
									
								    Book_Bolly_sat_movies();
								
									int movie_no; 
									float RATING;
									printf("Enter The movie no : ");
									scanf("%d", &movie_no);
									
									printf("Rate movie from 1.0 to 7.0 : ");
									scanf("%f", &RATING);
									
									fflush(stdin);
									char name[35];
									printf("Example:- \nBasit:0343---- \nEnter your name : ");
									gets(name);
									
									char file[] = "Book_Bolly_sat_movies.txt";
									char file1[] = "new.txt";
									
									FILE *Bo = fopen(file,"r");
									FILE *Bo1 = fopen(file1,"w");
									
									char extract[35];
									char extract1[35];
									char extract2[35];
									float rating, rating1;
									int counter = 0, ratingCount, ratingCount1, counter1 = 0;
									int counter2 = 0; 
									while(fgets(extract, sizeof(extract), Bo) != NULL)
									{
										counter++;
										if(counter>=1 && counter<=3 && counter == movie_no)
										{
											strcpy(extract2,extract);
										}
										if(counter>8 && counter<12)
										{
											fscanf(Bo, "%f", &rating);
											counter1++;
											if(counter1 == movie_no)
											{
												rating1 = rating + RATING;
												printf("%f", rating1);
											}
										}
										
										if(counter>11 && counter<15)
										{
											fscanf(Bo, "%d", &ratingCount);
											counter2++;
											if(counter2 == movie_no)
											{
												ratingCount1 = ratingCount + 1;
												printf("%d", ratingCount1);
											}																						
										}
									}
									rewind(Bo);
									float rating2;
									
									rating1 = rating1/ratingCount1;
									
									int check = 0;
									while(fgets(extract1, sizeof(extract1), Bo) != NULL)
									{
										check++;
										if(check == movie_no+9)
										{
											fprintf(Bo1,"%.1f\n",rating1);
										}
										else if(check == movie_no+12)
										{
											fprintf(Bo1,"%d\n",ratingCount1);
										}
										else
										{
											fprintf(Bo1,"%s",extract1);
										}
									}
									
									int REG = NULL;
								
									char day[] = "Saturday";
									FILE *ratdet = fopen("RatingDetails_Bolly.txt","a");
									fprintf(ratdet,"%10s%30s%20.1f%40s", day, name, RATING, extract2);
									fclose(ratdet);  
									
									
									fclose(Bo1);
									fclose(Bo);
									remove(file);
									rename(file1,file);		
							}
							gotoxy(15,25);
							printf("*************** YOUR RATING HAS BEEN RECEIVED :) ***************");							
							break;
						}
						
					case 7:
						{
							system("cls");
							printf("\nMovie -> Tickets -> Price -> Ratings -> No.of ratings\n\n");
							Book_Bolly_sun_movies();
							int wish;
							printf("Would you like to proceed to rating ? 1)yes & 0) no : ");
							scanf("%d", &wish);
							if(wish == 0)
							{
								exit(1);
							}
							system("cls");							
							Book_Bolly_sun_movies();
							
							int Cust;
							printf("Have you ever been our customer ? 1)yes & 0)no :  ");
							scanf("%d", &Cust);
							
								if(Cust == 1)
								{
									int REG;
									printf("Enter your Registrations ");
									scanf("%d", &REG);
									
									int get;
									FILE *CH = fopen("RegistrationNo.txt","r");
									fscanf(CH, "%d", &get);
									fclose(CH);
									
									if(REG>get)
									{
										printf("Invalid registration no!");
									}
									
									int movie_no; 
									float RATING;
									printf("Enter The movie no : ");
									scanf("%d", &movie_no);
									
									printf("Rate movie from 1.0 to 7.0 : ");
									scanf("%f", &RATING);
									
									char file[] = "Book_Holly_sun_movies.txt";
									char file1[] = "new.txt";
									
									FILE *Bo = fopen(file,"r");
									FILE *Bo1 = fopen(file1,"w");
									
									char extract[35];
									char extract1[35];
									char extract2[35];
									float rating, rating1;
									int counter = 0, ratingCount, ratingCount1, counter1 = 0;
									int counter2 = 0; 
									while(fgets(extract, sizeof(extract), Bo) != NULL)
									{
										counter++;
										if(counter>=1 && counter<=3 && counter == movie_no)
										{
											strcpy(extract2,extract);
										}
										if(counter>8 && counter<12)
										{
											fscanf(Bo, "%f", &rating);
											counter1++;
											if(counter1 == movie_no)
											{
												rating1 = rating + RATING;
											}
										}
										
										if(counter>11 && counter<15)
										{
											fscanf(Bo, "%d", &ratingCount);
											counter2++;
											if(counter2 == movie_no)
											{
												ratingCount1 = ratingCount + 1;
											}																						
										}
									}
									rewind(Bo);
									float rating2;
									
									rating1 = rating1/ratingCount1;
									
									int check = 0;
									while(fgets(extract1, sizeof(extract1), Bo) != NULL)
									{
										check++;
										if(check == movie_no+9)
										{
											fprintf(Bo1,"%.1f\n",rating1);
										}
										else if(check == movie_no+12)
										{
											fprintf(Bo1,"%d\n",ratingCount1);
										}
										else
										{
											fprintf(Bo1,"%s",extract1);
										}
									}
									
									char day[] = "Sunday";
									FILE *ratdet = fopen("RatingDetails_Bolly.txt","a");
									fprintf(ratdet,"%10s%30d%20.1f%40s", day, REG, RATING, extract2);
									fclose(ratdet); 
									
									
									fclose(Bo1);
									fclose(Bo);
									remove(file);
									rename(file1,file);
								}
								else
								{
									system("cls");
									printf("Thanks for contributing to us remotely!!!\n\n");
									
								    Book_Bolly_sun_movies();
								
									int movie_no; 
									float RATING;
									printf("Enter The movie no : ");
									scanf("%d", &movie_no);
									
									printf("Rate movie from 1.0 to 7.0 : ");
									scanf("%f", &RATING);
									
									fflush(stdin);
									char name[35];
									printf("Example:- \nBasit:0343---- \nEnter your name : ");
									gets(name);
									
									char file[] = "Book_Bolly_sun_movies.txt";
									char file1[] = "new.txt";
									
									FILE *Bo = fopen(file,"r");
									FILE *Bo1 = fopen(file1,"w");
									
									char extract[35];
									char extract1[35];
									char extract2[35];
									float rating, rating1;
									int counter = 0, ratingCount, ratingCount1, counter1 = 0;
									int counter2 = 0; 
									while(fgets(extract, sizeof(extract), Bo) != NULL)
									{
										counter++;
										if(counter>=1 && counter<=3 && counter == movie_no)
										{
											strcpy(extract2,extract);
										}
										if(counter>8 && counter<12)
										{
											fscanf(Bo, "%f", &rating);
											counter1++;
											if(counter1 == movie_no)
											{
												rating1 = rating + RATING;
												printf("%f", rating1);
											}
										}
										
										if(counter>11 && counter<15)
										{
											fscanf(Bo, "%d", &ratingCount);
											counter2++;
											if(counter2 == movie_no)
											{
												ratingCount1 = ratingCount + 1;
												printf("%d", ratingCount1);
											}																						
										}
									}
									rewind(Bo);
									float rating2;
									
									rating1 = rating1/ratingCount1;
									
									int check = 0;
									while(fgets(extract1, sizeof(extract1), Bo) != NULL)
									{
										check++;
										if(check == movie_no+9)
										{
											fprintf(Bo1,"%.1f\n",rating1);
										}
										else if(check == movie_no+12)
										{
											fprintf(Bo1,"%d\n",ratingCount1);
										}
										else
										{
											fprintf(Bo1,"%s",extract1);
										}
									}
									
									int REG = NULL;
								
									char day[] = "Sunday";
									FILE *ratdet = fopen("RatingDetails_Bolly.txt","a");
									fprintf(ratdet,"%10s%30s%20.1f%40s", day, name, RATING, extract2);
									fclose(ratdet);  
									
									
									fclose(Bo1);
									fclose(Bo);
									remove(file);
									rename(file1,file);		
							}
							gotoxy(15,25);
							printf("*************** YOUR RATING HAS BEEN RECEIVED :) ***************");							
							break;
						}
																																				
				default:
					{
							printf("Error 404! selection not found");
							break;
					}							
						
					}
				break;							
			}	
	}
}
		


void Management()
{
	system("cls");
	printf("Welcome to management");
	
	printf("\n\nKindly Identify yourself\n");
	
	char user[] = "admin12@gmail.com";
	char pass[] = "Admin123";
	char user1[sizeof(user)];
	char pass1[sizeof(pass)], ch;
	int i;
	
	repeat:
	fflush(stdin);
	printf("Enter username : ");
	gets(user1);
	
	printf("Enter Password : ");
	gets(pass1);
	

		if((strcmp(user,user1) == 0) && (strcmp(pass,pass1) == 0))
		{
				void (*ptr[3])() = {Analytics, CheckAdmin, DelAdmin};
	
	
				int enter;
				printf(" What do you want to do \n 1)Analytics \n 2)Checking \n 3)Delete");
				printf("\n Enter your selection : ");
				scanf("%d", &enter);
	
				(*ptr[enter-1])();
	
				printf("\n");
			
		}
		else
		{
			printf("username or password is incorrect");
			goto repeat;
		}
	
}

void Analytics()
{
	system("cls");
	printf("Welcome to analysis");
	printf("What you want to analyze 1 \n1)Basic \n2)Hollywood \n3)Bollywood \n4)Between Hollywood and Bollywood");
	
	int analyze;
	printf("\nMake your selection : ");
	scanf("%d", &analyze);
	int round1 = 0, round2 = 0, round3 = 0, round4 = 0, round5 = 0, round6 = 0, round7 = 0;
	switch(analyze)
	{
		case 1:
			{
				system("cls");
				printf("welcome to basic Analysis");
				
				printf("\nTotal registrations : ");
				
				int reg;
				FILE *fp = fopen("RegistrationNo.txt", "r");
				fscanf(fp, "%d", &reg);
				fclose(fp);
				printf("%d", reg);
			
				printf("\nBooked parking slots : ");
				
				int par;
				FILE *fp1 = fopen("PARKING.txt", "r");
				fscanf(fp1, "%d", &par);
				fclose(fp1);
				printf("%d", par);
				
				printf("\nleft parking slots : ");
				
				int count = 0, size = 0;
				char ch[5];
				FILE *fp2 = fopen("Remaining_parking_slot.txt", "r");
				rewind(fp2);
				fseek(fp2, 0, SEEK_END);
				size = ftell(fp2);
				if(size == 0)
				{
					count = 0;
					fclose(fp2);
					remove("Remaining_parking_slot.txt");
				}
				else
				{
					int faltu;
					rewind(fp2);
					while(fgets(ch, sizeof(ch), fp2) != NULL)
					{
						count++;
					}
					fclose(fp2);		
				}
				
				printf("%d", count);
				
				printf("\nCancelled registrations in Hollywood : ");
				
				int count1 = 0;
				FILE *fp3 = fopen("CancelledRegistrations_Holly.txt", "r");
				int count2 = 0;
				char read[125];
				while(fgets(read, sizeof(read), fp3) != NULL)
				{
					count1++;
			
					if(count1 > 3)
					{
						count2++;
					}
				}
				printf("%d", count2);
				fclose(fp3);
				
				printf("\nCancelled registrations in Bollywood : ");
				
				int count3 = 0;
				FILE *fp4 = fopen("CancelledRegistrations_Bolly.txt", "r");
				int count4 = 0;
				char read1[125];
				while(fgets(read1, sizeof(read1), fp4) != NULL)
				{
					count3++;
			
					if(count3 > 3)
					{
						count4++;
					}
				}
				printf("%d", count4);
				fclose(fp4);
				
				float take, take1 = 0;
				printf("\nRevenue of Hollywood : ");
				FILE *fp5 = fopen("HollywoodRevenue.txt", "r");
				while(!feof(fp5))
				{
					fscanf(fp5, "%f", &take);
					take1 += take;
				}
				fclose(fp5);
				printf("%.2f", take1);
				
				float TAKE, TAKE1 = 0;
				printf("\nRevenue of Bollywood : ");
				FILE *FP5 = fopen("BollywoodRevenue.txt", "r");
				while(!feof(FP5))
				{
					fscanf(FP5, "%f", &TAKE);
					TAKE1 += TAKE;
				}
				fclose(FP5);
				printf("%.2f", TAKE1);
				
				float Total;
				Total = take1 + TAKE1;
				printf("\nTotal Revenue = %.2f", Total);
				break;																			
			}
		case 2:
			{
				int i, count, count1, CHECK;
				count = 0;
				count1 = 0;
				printf("0");
				for(i=0; i<14; i++)
				{
					count++;
					printf("_________");
					printf("%d", count);
				}

				count = 0;
				count1 = 0;
				FILE *fp = fopen("Booking_Holly_mon_movies.txt", "r");
				char read[125];
				while(fgets(read, sizeof(read), fp) != NULL)
				{
					count++;
			
					if(count > 3)
					{
						count1++;
					}
				}
				fclose(fp);
				printf("\n\nMonday\n*");
				CHECK = 0;
				for(i=0; i<count1; i++)
				{
					CHECK++;
					if(CHECK>=10)
					{
						printf("*");
					}
					printf("**********");
				}
				
				count = 0;
				count1 = 0;
				FILE *fp1 = fopen("Booking_Holly_tue_movies.txt", "r");
				char read1[125];
				while(fgets(read, sizeof(read), fp) != NULL)
				{
					count++;
			
					if(count > 3)
					{
						count1++;
					}
				}
				
				fclose(fp);
				printf("\n\nTuesday\n*");
				CHECK = 0;
				for(i=0; i<count1; i++)
				{
					CHECK++;
					if(CHECK>=10)
					{
						printf("*");
					}
					printf("**********");
				}
				
				count = 0;
				count1 = 0;
				FILE *fp2 = fopen("Booking_Holly_wed_movies.txt", "r");
				char read2[125];
				while(fgets(read2, sizeof(read2), fp2) != NULL)
				{
					count++;
			
					if(count > 3)
					{
						count1++;
					}
				}
				
				fclose(fp2);
				printf("\n\nWednesday\n*");
				CHECK = 0;
				for(i=0; i<count1; i++)
				{
					CHECK++;
					if(CHECK>=10)
					{
						printf("*");
					}
					printf("**********");
				}								
				
				
				count = 0;
				count1 = 0;
				FILE *fp3 = fopen("Booking_Holly_thu_movies.txt", "r");
				char read3[125];
				while(fgets(read3, sizeof(read2), fp3) != NULL)
				{
					count++;
			
					if(count > 3)
					{
						count1++;
					}
				}
				
				fclose(fp3);
				printf("\n\nThursday\n*");
				CHECK = 0;
				for(i=0; i<count1; i++)
				{
					CHECK++;
					if(CHECK>=10)
					{
						printf("*");
					}
					printf("**********");
				}
				
				count = 0;
				count1 = 0;
				FILE *fp4 = fopen("Booking_Holly_fri_movies.txt", "r");
				char read4[125];
				while(fgets(read4, sizeof(read4), fp4) != NULL)
				{
					count++;
			
					if(count > 3)
					{
						count1++;
					}
				}
				
				fclose(fp4);
				printf("\n\nFriday\n*");
				CHECK = 0;
				for(i=0; i<count1; i++)
				{
					CHECK++;
					if(CHECK>=10)
					{
						printf("*");
					}
					printf("**********");
				}
				
				count = 0;
				count1 = 0;
				FILE *fp5 = fopen("Booking_Holly_sat_movies.txt", "r");
				char read5[125];
				while(fgets(read5, sizeof(read5), fp5) != NULL)
				{
					count++;
			
					if(count > 3)
					{
						count1++;
					}
				}
				
				fclose(fp5);
				printf("\n\nSaturday\n*");
				CHECK = 0;
				for(i=0; i<count1; i++)
				{
					CHECK++;
					if(CHECK>=10)
					{
						printf("*");
					}
					printf("**********");
				}
				
				count = 0;
				count1 = 0;
				FILE *fp6 = fopen("Booking_Holly_sun_movies.txt", "r");
				char read6[125];
				while(fgets(read6, sizeof(read6), fp6) != NULL)
				{
					count++;
			
					if(count > 3)
					{
						count1++;
					}
				}
				
				fclose(fp6);
				printf("\n\nSunday\n*");
				CHECK = 0;
				for(i=0; i<count1; i++)
				{
					CHECK++;
					if(CHECK>=10)
					{
						printf("*");
					}
					printf("**********");
				}																
				
				break;									
			}
		case 3:
			{
				int i, count, count1, CHECK;
				count = 0;
				count1 = 0;
				printf("0");
				for(i=0; i<14; i++)
				{
					count++;
					printf("_________");
					printf("%d", count);
				}

				count = 0;
				count1 = 0;
				FILE *fp = fopen("Booking_Bolly_mon_movies.txt", "r");
				char read[125];
				while(fgets(read, sizeof(read), fp) != NULL)
				{
					count++;
			
					if(count > 3)
					{
						count1++;
					}
				}
				
				fclose(fp);
				printf("\n\nMonday\n*");
				CHECK = 0;
				for(i=0; i<count1; i++)
				{
					CHECK++;
					if(CHECK>=10)
					{
						printf("*");
					}
					printf("**********");
				}
				
				count = 0;
				count1 = 0;
				FILE *fp1 = fopen("Booking_Bolly_tue_movies.txt", "r");
				char read1[125];
				while(fgets(read, sizeof(read), fp) != NULL)
				{
					count++;
			
					if(count > 3)
					{
						count1++;
					}
				}
				
				fclose(fp);
				printf("\n\nTueday\n*");
				CHECK = 0;
				for(i=0; i<count1; i++)
				{
					CHECK++;
					if(CHECK>=10)
					{
						printf("*");
					}
					printf("**********");
				}
				
				count = 0;
				count1 = 0;
				FILE *fp2 = fopen("Booking_Bolly_wed_movies.txt", "r");
				char read2[125];
				while(fgets(read2, sizeof(read2), fp2) != NULL)
				{
					count++;
			
					if(count > 3)
					{
						count1++;
					}
				}
				
				fclose(fp2);
				printf("\n\nWednesday\n*");
				CHECK = 0;
				for(i=0; i<count1; i++)
				{
					CHECK++;
					if(CHECK>=10)
					{
						printf("*");
					}
					printf("**********");
				}								
				
				
				count = 0;
				count1 = 0;
				FILE *fp3 = fopen("Booking_Bolly_thu_movies.txt", "r");
				char read3[125];
				while(fgets(read3, sizeof(read2), fp3) != NULL)
				{
					count++;
			
					if(count > 3)
					{
						count1++;
					}
				}
				
				fclose(fp3);
				printf("\n\nThursday\n*");
				CHECK = 0;
				for(i=0; i<count1; i++)
				{
					CHECK++;
					if(CHECK>=10)
					{
						printf("*");
					}
					printf("**********");
				}
				
				count = 0;
				count1 = 0;
				FILE *fp4 = fopen("Booking_Bolly_fri_movies.txt", "r");
				char read4[125];
				while(fgets(read4, sizeof(read4), fp4) != NULL)
				{
					count++;
			
					if(count > 3)
					{
						count1++;
					}
				}
				
				fclose(fp4);
				printf("\n\nFriday\n*");
				CHECK = 0;
				for(i=0; i<count1; i++)
				{
					CHECK++;
					if(CHECK>=10)
					{
						printf("*");
					}
					printf("**********");
				}
				
				count = 0;
				count1 = 0;
				FILE *fp5 = fopen("Booking_Bolly_sat_movies.txt", "r");
				char read5[125];
				while(fgets(read5, sizeof(read5), fp5) != NULL)
				{
					count++;
			
					if(count > 3)
					{
						count1++;
					}
				}
				
				fclose(fp5);
				printf("\n\nSaturday\n*");
				CHECK = 0;
				for(i=0; i<count1; i++)
				{
					CHECK++;
					if(CHECK>=10)
					{
						printf("*");
					}
					printf("**********");
				}
				
				count = 0;
				count1 = 0;
				FILE *fp6 = fopen("Booking_Bolly_sun_movies.txt", "r");
				char read6[125];
				while(fgets(read6, sizeof(read6), fp6) != NULL)
				{
					count++;
			
					if(count > 3)
					{
						count1++;
					}
				}
				
				fclose(fp6);
				printf("\n\nSunday\n*");
				CHECK = 0;
				for(i=0; i<count1; i++)
				{
					CHECK++;
					if(CHECK>=10)
					{
						printf("*");
					}
					printf("**********");
				}																
				
				break;									
			}
		case 4:
		{
			
				int i, count, count1, CHECK;
				count = 0;
				count1 = 0;
				printf("0");
				for(i=0; i<14; i++)
				{
					count++;
					printf("_________");
					printf("%d", count);
				}			
				int round1 = 0, round2 = 0, round3 = 0, round4 = 0, round5 = 0, round6 = 0, round7 = 0;			
				count = 0;
				count1 = 0;
				FILE *fp = fopen("Booking_Holly_mon_movies.txt", "r");
				char read[125];
				while(fgets(read, sizeof(read), fp) != NULL)
				{
					count++;
			
					if(count > 3)
					{
						round1++;
					}
				}
				
				fclose(fp);
				
				count = 0;
				count1 = 0;
				FILE *fp1 = fopen("Booking_Holly_tue_movies.txt", "r");
				char read1[125];
				while(fgets(read1, sizeof(read1), fp) != NULL)
				{
					count++;
			
					if(count > 3)
					{
						round2++;
					}
				}
				
				fclose(fp);
				
				count = 0;
				count1 = 0;
				FILE *fp2 = fopen("Booking_Holly_wed_movies.txt", "r");
				char read2[125];
				while(fgets(read2, sizeof(read2), fp2) != NULL)
				{
					count++;
			
					if(count > 3)
					{
						round3++;
					}
				}
				
				fclose(fp2);								
				
				count = 0;
				count1 = 0;
				FILE *fp3 = fopen("Booking_Holly_thu_movies.txt", "r");
				char read3[125];
				while(fgets(read3, sizeof(read2), fp3) != NULL)
				{
					count++;
			
					if(count > 3)
					{
						round4++;
					}
				}
				
				fclose(fp3);
				
				count = 0;
				count1 = 0;
				FILE *fp4 = fopen("Booking_Holly_fri_movies.txt", "r");
				char read4[125];
				while(fgets(read4, sizeof(read4), fp4) != NULL)
				{
					count++;
			
					if(count > 3)
					{
						round5++;
					}
				}
				
				fclose(fp4);

				
				count = 0;
				count1 = 0;
				FILE *fp5 = fopen("Booking_Holly_sat_movies.txt", "r");
				char read5[125];
				while(fgets(read5, sizeof(read5), fp5) != NULL)
				{
					count++;
			
					if(count > 3)
					{
						round6++;
						
					}
				}
				
				fclose(fp5);
				
				count = 0;
				count1 = 0;
				FILE *fp6 = fopen("Booking_Holly_sun_movies.txt", "r");
				char read6[125];
				while(fgets(read6, sizeof(read6), fp6) != NULL)
				{
					count++;
			
					if(count > 3)
					{
						round7++;
					}
				}
				
				fclose(fp6);																
				
				float average;
				average = (round1 + round2 + round3 + round4 + round5 + round6 + round7) / 7;
				int average1;
				average1 = round(average);
				
				printf("\n\nHollywood\n*");
				CHECK = 0;
				for(i=0; i<average1; i++)
				{
					CHECK++;
					if(CHECK>=10)
					{
						printf("*");
					}
					printf("**********");
				}
				
				round1 = 0; round2 = 0; round3 = 0; round4 = 0; round5 = 0; round6 = 0; round7 = 0;			
				count = 0;
				count1 = 0;
				FILE *FP = fopen("Booking_Bolly_mon_movies.txt", "r");
				char Read[125];
				while(fgets(Read, sizeof(Read), FP) != NULL)
				{
					count++;
			
					if(count > 3)
					{
						round1++;
					}
				}
				
				fclose(FP);
				
				count = 0;
				count1 = 0;
				FILE *FP1 = fopen("Booking_Bolly_tue_movies.txt", "r");
				char Read1[125];
				while(fgets(Read1, sizeof(Read1), FP) != NULL)
				{
					count++;
			
					if(count > 3)
					{
						round2++;
					}
				}
				
				fclose(FP);
				
				count = 0;
				count1 = 0;
				FILE *FP2 = fopen("Booking_Bolly_wed_movies.txt", "r");
				char Read2[125];
				while(fgets(Read2, sizeof(Read2), FP2) != NULL)
				{
					count++;
			
					if(count > 3)
					{
						round3++;
					}
				}
				
				fclose(FP2);								
				
				count = 0;
				count1 = 0;
				FILE *FP3 = fopen("Booking_Bolly_thu_movies.txt", "r");
				char Read3[125];
				while(fgets(Read3, sizeof(Read2), FP3) != NULL)
				{
					count++;
			
					if(count > 3)
					{
						round4++;
					}
				}
				
				fclose(FP3);
				
				count = 0;
				count1 = 0;
				FILE *FP4 = fopen("Booking_Bolly_fri_movies.txt", "r");
				char Read4[125];
				while(fgets(Read4, sizeof(Read4), FP4) != NULL)
				{
					count++;
			
					if(count > 3)
					{
						round5++;
					}
				}
				
				fclose(FP4);

				
				count = 0;
				count1 = 0;
				FILE *FP5 = fopen("Booking_Bolly_sat_movies.txt", "r");
				char Read5[125];
				while(fgets(Read5, sizeof(Read5), FP5) != NULL)
				{
					count++;
			
					if(count > 3)
					{
						round6++;
						
					}
				}
				
				fclose(FP5);
				
				count = 0;
				count1 = 0;
				FILE *FP6 = fopen("Booking_Bolly_sun_movies.txt", "r");
				char Read6[125];
				while(fgets(Read6, sizeof(Read6), FP6) != NULL)
				{
					count++;
			
					if(count > 3)
					{
						round7++;
					}
				}
				
				fclose(FP6);																
				
				float Average;
				Average = (round1 + round2 + round3 + round4 + round5 + round6 + round7) / 7;
				int Average1;
				Average1 = round(Average);
				
				printf("\n\nBollywood\n*");
				CHECK = 0;
				for(i=0; i<average1; i++)
				{
					CHECK++;
					if(CHECK>=10)
					{
						printf("*");
					}
					printf("**********");
				}				
				
				break;			
		}				
					
	}
	
}

void CheckAdmin()
{
	system("cls");
	printf("Welcome to checking \n\n1)Hollywood \n2)Bollywood \n3)Deleted Hollywood \n4)Deleted Bollywood \n5)Hollywood Ratings \n6)Bollywood Ratings");
	int sel;
	printf("\nEnter your selection : ");
	scanf("%d", &sel);
	
	switch(sel)
	{
		case 1:
			{
				system("cls");
				printf("Welcome to Hollywood \n1)Monday \n2)Tuesday \n3)Wednesday \n4)Thursday \n5)Friday \n6)Saturday \nSunday");
				int make;
				printf("\nMake your selection : ");
				scanf("%d", &make);
				
				switch(make)
				{
					case 1:
						{
							system("cls");
							char read[125];
							FILE *fp = fopen("Booking_Holly_mon_movies.txt","r");
							while(fgets(read, sizeof(read), fp) != NULL)
							{
								printf("%s", read);
							}
							fclose(fp);
							break;
						}
					case 2:
						{
							system("cls");
							char read[125];
							FILE *fp = fopen("Booking_Holly_tue_movies.txt","r");
							while(fgets(read, sizeof(read), fp) != NULL)
							{
								printf("%s", read);
							}
							fclose(fp);
							break;
						}
					case 3:
						{
							system("cls");
							char read[125];
							FILE *fp = fopen("Booking_Holly_wed_movies.txt","r");
							while(fgets(read, sizeof(read), fp) != NULL)
							{
								printf("%s", read);
							}
							fclose(fp);
							break;
						}
					case 4:
						{
							system("cls");
							char read[125];
							FILE *fp = fopen("Booking_Holly_thu_movies.txt","r");
							while(fgets(read, sizeof(read), fp) != NULL)
							{
								printf("%s", read);
							}
							fclose(fp);
							break;
						}
					case 5:
						{
							system("cls");
							char read[125];
							FILE *fp = fopen("Booking_Holly_fri_movies.txt","r");
							while(fgets(read, sizeof(read), fp) != NULL)
							{
								printf("%s", read);
							}
							fclose(fp);
							break;
						}
					case 6:
						{
							system("cls");
							char read[125];
							FILE *fp = fopen("Booking_Holly_sat_movies.txt","r");
							while(fgets(read, sizeof(read), fp) != NULL)
							{
								printf("%s", read);
							}
							fclose(fp);
							break;
						}
					case 7:
						{
							system("cls");
							char read[125];
							FILE *fp = fopen("Booking_Holly_sun_movies.txt","r");
							while(fgets(read, sizeof(read), fp) != NULL)
							{
								printf("%s", read);
							}
							fclose(fp);
							break;
						}
					default:
					{
						printf("Error");
					}																																					
				}
				break;
			}
		case 2:
			{
				system("cls");
				printf("Welcome to Bollywood \n1)Monday \n2)Tuesday \n3)Wednesday \n4)Thursday \n5)Friday \n6)Saturday \nSunday");
				int make;
				printf("\nMake your selection : ");
				scanf("%d", &make);
				
				switch(make)
				{
					case 1:
						{
							system("cls");
							char read[125];
							FILE *fp = fopen("Booking_Bolly_mon_movies.txt","r");
							while(fgets(read, sizeof(read), fp) != NULL)
							{
								printf("%s", read);
							}
							fclose(fp);
							break;
						}
					case 2:
						{
							system("cls");
							char read[125];
							FILE *fp = fopen("Booking_Bolly_tue_movies.txt","r");
							while(fgets(read, sizeof(read), fp) != NULL)
							{
								printf("%s", read);
							}
							fclose(fp);
							break;
						}
					case 3:
						{
							system("cls");
							char read[125];
							FILE *fp = fopen("Booking_Bolly_wed_movies.txt","r");
							while(fgets(read, sizeof(read), fp) != NULL)
							{
								printf("%s", read);
							}
							fclose(fp);
							break;
						}
					case 4:
						{
							system("cls");
							char read[125];
							FILE *fp = fopen("Booking_Bolly_thu_movies.txt","r");
							while(fgets(read, sizeof(read), fp) != NULL)
							{
								printf("%s", read);
							}
							fclose(fp);
							break;
						}
					case 5:
						{
							system("cls");
							char read[125];
							FILE *fp = fopen("Booking_Bolly_fri_movies.txt","r");
							while(fgets(read, sizeof(read), fp) != NULL)
							{
								printf("%s", read);
							}
							fclose(fp);
							break;
						}
					case 6:
						{
							system("cls");
							char read[125];
							FILE *fp = fopen("Booking_Bolly_sat_movies.txt","r");
							while(fgets(read, sizeof(read), fp) != NULL)
							{
								printf("%s", read);
							}
							fclose(fp);
							break;
						}
					case 7:
						{
							system("cls");
							char read[125];
							FILE *fp = fopen("Booking_Bolly_sun_movies.txt","r");
							while(fgets(read, sizeof(read), fp) != NULL)
							{
								printf("%s", read);
							}
							fclose(fp);
							break;
						}
					default:
					{
						printf("Error");
					}																																					
				}
				break;
			}
		case 3:
			{
				system("cls");
				char read[150];
				FILE *fp = fopen("CancelledRegistrations_Holly.txt","r");
				while(fgets(read, sizeof(read), fp) != NULL)
				{
					printf("%s", read);
				}
				fclose(fp);
				break;
			}
		case 4:
			{
				system("cls");
				char read[150];
				FILE *fp = fopen("CancelledRegistrations_Bolly.txt","r");
				while(fgets(read, sizeof(read), fp) != NULL)
				{
					printf("%s", read);
				}
				fclose(fp);
				break;
			}
		case 5:
			{
				system("cls");
				char read[150];
				FILE *fp = fopen("RatingDetails_Holly.txt","r");
				while(fgets(read, sizeof(read), fp) != NULL)
				{
					printf("%s", read);
				}
				fclose(fp);
				break;
			}
		case 6:
			{
				system("cls");
				char read[150];
				FILE *fp = fopen("RatingDetails_Bolly.txt","r");
				while(fgets(read, sizeof(read), fp) != NULL)
				{
					printf("%s", read);
				}
				fclose(fp);
				break;
			}						
		default:
			{
				printf("Error");
			}							
			
	}
}

void DelAdmin()
{
	system("cls");
	printf("Welcome to Deletion \n\n1)Hollywood \n2)Bollywood \n3)Deleted Hollywood \n4)Deleted Bollywood \n5)Hollywood Ratings \n6)Bollywood Ratings");
	int sel;
	printf("\nEnter your selection : ");
	scanf("%d", &sel);
	
	switch(sel)
	{
		case 1:
			{
				system("cls");
				printf("Welcome to Hollywood \n1)Monday \n2)Tuesday \n3)Wednesday \n4)Thursday \n5)Friday \n6)Saturday \nSunday");
				int make;
				printf("\nMake your selection : ");
				scanf("%d", &make);
				
				switch(make)
				{
					case 1:
						{
							system("cls");
							char read[125];
							char file[] = "Booking_Holly_mon_movies.txt";
							FILE *fp = fopen(file,"r");
							while(fgets(read, sizeof(read), fp) != NULL)
							{
								printf("%s", read);
							}
							
							int wish;
							printf("\nDo you want to delete the records ? 1)yes 0)no : ");
							scanf("%d", &wish);
							
							if(wish == 0)
							{
								exit(1);
							}
							
							rewind(fp);
							char read1[125];
							char file1[] = "new.txt";
							int count = 0;
							FILE *fp1 = fopen(file1, "w");
							while(fgets(read1, sizeof(read1), fp) != NULL)
							{
								count++;
								if(count > 3)
								{
									break;
								}
								fprintf(fp1,"%s", read1);
							}
							
							fclose(fp1);
							fclose(fp);
							remove(file);
							rename(file1, file);
							
							break;
						}
					case 2:
						{
							system("cls");
							char read[125];
							char file[] = "Booking_Holly_tue_movies.txt";
							FILE *fp = fopen(file,"r");
							while(fgets(read, sizeof(read), fp) != NULL)
							{
								printf("%s", read);
							}
							
							int wish;
							printf("\nDo you want to delete the records ? 1)yes 0)no : ");
							scanf("%d", &wish);
							
							if(wish == 0)
							{
								exit(1);
							}
							
							rewind(fp);
							char read1[125];
							char file1[] = "new.txt";
							int count = 0;
							FILE *fp1 = fopen(file1, "w");
							while(fgets(read1, sizeof(read1), fp) != NULL)
							{
								count++;
								if(count > 3)
								{
									break;
								}
								fprintf(fp1,"%s", read1);
							}
							
							fclose(fp1);
							fclose(fp);
							remove(file);
							rename(file1, file);
							
							break;
						}
					case 3:
						{
							system("cls");
							char read[125];
							char file[] = "Booking_Holly_wed_movies.txt";
							FILE *fp = fopen(file,"r");
							while(fgets(read, sizeof(read), fp) != NULL)
							{
								printf("%s", read);
							}
							
							int wish;
							printf("\nDo you want to delete the records ? 1)yes 0)no : ");
							scanf("%d", &wish);
							
							if(wish == 0)
							{
								exit(1);
							}
							
							rewind(fp);
							char read1[125];
							char file1[] = "new.txt";
							int count = 0;
							FILE *fp1 = fopen(file1, "w");
							while(fgets(read1, sizeof(read1), fp) != NULL)
							{
								count++;
								if(count > 3)
								{
									break;
								}
								fprintf(fp1,"%s", read1);
							}
							
							fclose(fp1);
							fclose(fp);
							remove(file);
							rename(file1, file);
							
							break;
						}
					case 4:
						{
							system("cls");
							char read[125];
							char file[] = "Booking_Holly_thu_movies.txt";
							FILE *fp = fopen(file,"r");
							while(fgets(read, sizeof(read), fp) != NULL)
							{
								printf("%s", read);
							}
							
							int wish;
							printf("\nDo you want to delete the records ? 1)yes 0)no : ");
							scanf("%d", &wish);
							
							if(wish == 0)
							{
								exit(1);
							}
							
							rewind(fp);
							char read1[125];
							char file1[] = "new.txt";
							int count = 0;
							FILE *fp1 = fopen(file1, "w");
							while(fgets(read1, sizeof(read1), fp) != NULL)
							{
								count++;
								if(count > 3)
								{
									break;
								}
								fprintf(fp1,"%s", read1);
							}
							
							fclose(fp1);
							fclose(fp);
							remove(file);
							rename(file1, file);
							
							break;
						}
					case 5:
						{
							system("cls");
							char read[125];
							char file[] = "Booking_Holly_fri_movies.txt";
							FILE *fp = fopen(file,"r");
							while(fgets(read, sizeof(read), fp) != NULL)
							{
								printf("%s", read);
							}
							
							int wish;
							printf("\nDo you want to delete the records ? 1)yes 0)no : ");
							scanf("%d", &wish);
							
							if(wish == 0)
							{
								exit(1);
							}
							
							rewind(fp);
							char read1[125];
							char file1[] = "new.txt";
							int count = 0;
							FILE *fp1 = fopen(file1, "w");
							while(fgets(read1, sizeof(read1), fp) != NULL)
							{
								count++;
								if(count > 3)
								{
									break;
								}
								fprintf(fp1,"%s", read1);
							}
							
							fclose(fp1);
							fclose(fp);
							remove(file);
							rename(file1, file);
							
							break;
						}
					case 6:
						{
							system("cls");
							char read[125];
							char file[] = "Booking_Holly_sat_movies.txt";
							FILE *fp = fopen(file,"r");
							while(fgets(read, sizeof(read), fp) != NULL)
							{
								printf("%s", read);
							}
							
							int wish;
							printf("\nDo you want to delete the records ? 1)yes 0)no : ");
							scanf("%d", &wish);
							
							if(wish == 0)
							{
								exit(1);
							}
							
							rewind(fp);
							char read1[125];
							char file1[] = "new.txt";
							int count = 0;
							FILE *fp1 = fopen(file1, "w");
							while(fgets(read1, sizeof(read1), fp) != NULL)
							{
								count++;
								if(count > 3)
								{
									break;
								}
								fprintf(fp1,"%s", read1);
							}
							
							fclose(fp1);
							fclose(fp);
							remove(file);
							rename(file1, file);
							
							break;
						}
					case 7:
						{
							system("cls");
							char read[125];
							char file[] = "Booking_Holly_sun_movies.txt";
							FILE *fp = fopen(file,"r");
							while(fgets(read, sizeof(read), fp) != NULL)
							{
								printf("%s", read);
							}
							
							int wish;
							printf("\nDo you want to delete the records ? 1)yes 0)no : ");
							scanf("%d", &wish);
							
							if(wish == 0)
							{
								exit(1);
							}
							
							rewind(fp);
							char read1[125];
							char file1[] = "new.txt";
							int count = 0;
							FILE *fp1 = fopen(file1, "w");
							while(fgets(read1, sizeof(read1), fp) != NULL)
							{
								count++;
								if(count > 3)
								{
									break;
								}
								fprintf(fp1,"%s", read1);
							}
							
							fclose(fp1);
							fclose(fp);
							remove(file);
							rename(file1, file);
							
							break;
						}																																				
				}
				break;
			}
			
		case 2:
			{
				system("cls");
				printf("Welcome to Bollywood \n1)Monday \n2)Tuesday \n3)Wednesday \n4)Thursday \n5)Friday \n6)Saturday \nSunday");
				int make;
				printf("\nMake your selection : ");
				scanf("%d", &make);
				
				switch(make)
				{
					case 1:
						{
							system("cls");
							char read[125];
							char file[] = "Booking_Bolly_mon_movies.txt";
							FILE *fp = fopen(file,"r");
							while(fgets(read, sizeof(read), fp) != NULL)
							{
								printf("%s", read);
							}
							
							int wish;
							printf("\nDo you want to delete the records ? 1)yes 0)no : ");
							scanf("%d", &wish);
							
							if(wish == 0)
							{
								exit(1);
							}
							
							rewind(fp);
							char read1[125];
							char file1[] = "new.txt";
							int count = 0;
							FILE *fp1 = fopen(file1, "w");
							while(fgets(read1, sizeof(read1), fp) != NULL)
							{
								count++;
								if(count > 3)
								{
									break;
								}
								fprintf(fp1,"%s", read1);
							}
							
							fclose(fp1);
							fclose(fp);
							remove(file);
							rename(file1, file);
							
							break;
						}
					case 2:
						{
							system("cls");
							char read[125];
							char file[] = "Booking_Bolly_tue_movies.txt";
							FILE *fp = fopen(file,"r");
							while(fgets(read, sizeof(read), fp) != NULL)
							{
								printf("%s", read);
							}
							
							int wish;
							printf("\nDo you want to delete the records ? 1)yes 0)no : ");
							scanf("%d", &wish);
							
							if(wish == 0)
							{
								exit(1);
							}
							
							rewind(fp);
							char read1[125];
							char file1[] = "new.txt";
							int count = 0;
							FILE *fp1 = fopen(file1, "w");
							while(fgets(read1, sizeof(read1), fp) != NULL)
							{
								count++;
								if(count > 3)
								{
									break;
								}
								fprintf(fp1,"%s", read1);
							}
							
							fclose(fp1);
							fclose(fp);
							remove(file);
							rename(file1, file);
							
							break;
						}
					case 3:
						{
							system("cls");
							char read[125];
							char file[] = "Booking_Bolly_wed_movies.txt";
							FILE *fp = fopen(file,"r");
							while(fgets(read, sizeof(read), fp) != NULL)
							{
								printf("%s", read);
							}
							
							int wish;
							printf("\nDo you want to delete the records ? 1)yes 0)no : ");
							scanf("%d", &wish);
							
							if(wish == 0)
							{
								exit(1);
							}
							
							rewind(fp);
							char read1[125];
							char file1[] = "new.txt";
							int count = 0;
							FILE *fp1 = fopen(file1, "w");
							while(fgets(read1, sizeof(read1), fp) != NULL)
							{
								count++;
								if(count > 3)
								{
									break;
								}
								fprintf(fp1,"%s", read1);
							}
							
							fclose(fp1);
							fclose(fp);
							remove(file);
							rename(file1, file);
							
							break;
						}
					case 4:
						{
							system("cls");
							char read[125];
							char file[] = "Booking_Bolly_thu_movies.txt";
							FILE *fp = fopen(file,"r");
							while(fgets(read, sizeof(read), fp) != NULL)
							{
								printf("%s", read);
							}
							
							int wish;
							printf("\nDo you want to delete the records ? 1)yes 0)no : ");
							scanf("%d", &wish);
							
							if(wish == 0)
							{
								exit(1);
							}
							
							rewind(fp);
							char read1[125];
							char file1[] = "new.txt";
							int count = 0;
							FILE *fp1 = fopen(file1, "w");
							while(fgets(read1, sizeof(read1), fp) != NULL)
							{
								count++;
								if(count > 3)
								{
									break;
								}
								fprintf(fp1,"%s", read1);
							}
							
							fclose(fp1);
							fclose(fp);
							remove(file);
							rename(file1, file);
							
							break;
						}
					case 5:
						{
							system("cls");
							char read[125];
							char file[] = "Booking_Bolly_fri_movies.txt";
							FILE *fp = fopen(file,"r");
							while(fgets(read, sizeof(read), fp) != NULL)
							{
								printf("%s", read);
							}
							
							int wish;
							printf("\nDo you want to delete the records ? 1)yes 0)no : ");
							scanf("%d", &wish);
							
							if(wish == 0)
							{
								exit(1);
							}
							
							rewind(fp);
							char read1[125];
							char file1[] = "new.txt";
							int count = 0;
							FILE *fp1 = fopen(file1, "w");
							while(fgets(read1, sizeof(read1), fp) != NULL)
							{
								count++;
								if(count > 3)
								{
									break;
								}
								fprintf(fp1,"%s", read1);
							}
							
							fclose(fp1);
							fclose(fp);
							remove(file);
							rename(file1, file);
							
							break;
						}
					case 6:
						{
							system("cls");
							char read[125];
							char file[] = "Booking_Bolly_sat_movies.txt";
							FILE *fp = fopen(file,"r");
							while(fgets(read, sizeof(read), fp) != NULL)
							{
								printf("%s", read);
							}
							
							int wish;
							printf("\nDo you want to delete the records ? 1)yes 0)no : ");
							scanf("%d", &wish);
							
							if(wish == 0)
							{
								exit(1);
							}
							
							rewind(fp);
							char read1[125];
							char file1[] = "new.txt";
							int count = 0;
							FILE *fp1 = fopen(file1, "w");
							while(fgets(read1, sizeof(read1), fp) != NULL)
							{
								count++;
								if(count > 3)
								{
									break;
								}
								fprintf(fp1,"%s", read1);
							}
							
							fclose(fp1);
							fclose(fp);
							remove(file);
							rename(file1, file);
							
							break;
						}
					case 7:
						{
							system("cls");
							char read[125];
							char file[] = "Booking_Bolly_sun_movies.txt";
							FILE *fp = fopen(file,"r");
							while(fgets(read, sizeof(read), fp) != NULL)
							{
								printf("%s", read);
							}
							
							int wish;
							printf("\nDo you want to delete the records ? 1)yes 0)no : ");
							scanf("%d", &wish);
							
							if(wish == 0)
							{
								exit(1);
							}
							
							rewind(fp);
							char read1[125];
							char file1[] = "new.txt";
							int count = 0;
							FILE *fp1 = fopen(file1, "w");
							while(fgets(read1, sizeof(read1), fp) != NULL)
							{
								count++;
								if(count > 3)
								{
									break;
								}
								fprintf(fp1,"%s", read1);
							}
							
							fclose(fp1);
							fclose(fp);
							remove(file);
							rename(file1, file);
							
							break;
						}																																				
				}
				break;
			}
		default:
		{
			printf("Error");	
		}						
	}
}


